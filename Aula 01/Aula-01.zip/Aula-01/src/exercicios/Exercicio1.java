package exercicios;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o 1� valor:");
		int n1 = scan.nextInt();
		System.out.print("Digite o 2� valor:");
		int n2 = scan.nextInt();
		
		
		int soma = n1 + n2;
		int subtracao = n1 - n2;
		int multiplicacao = n1 * n2;
		int divisao = n1 / n2;
		int resto = n1 % n2;
		
		
		System.out.println("Soma: "+ n1 + " + "+ n2 +" = " + soma);
		System.out.println("Subtra��o: "+ n1 + " - "+ n2 +" = " + subtracao);
		System.out.println("Mutiplica��o: "+ n1 + " * "+ n2 +" = " + multiplicacao);
		System.out.println("Divis�o: " +  n1 + " / "+ n2 +" = " + divisao);
		System.out.println("Resto da divis�o: " + n1 + " % "+ n2 +" = " + resto);
		
		scan.close();

	}

}
