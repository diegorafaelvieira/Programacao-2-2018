package exercicios;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		System.out.print("Informe um valor: ");
		int valor = scan.nextInt();

		if (valor % 2 == 0) {
			System.out.println("O valor " + valor + " � PAR");
		} else {
			System.out.println("O valor " + valor + " � �MPAR");
		}

		scan.close();
	}

}
