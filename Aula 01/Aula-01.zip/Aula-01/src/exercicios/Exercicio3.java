package exercicios;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o 1� valor: ");
		int v1 = scan.nextInt();
		System.out.print("Informe o 2� valor: ");
		int v2 = scan.nextInt();
		
		if(v1 != v2) {
			System.out.println("Valores diferentes!");
			
			if(v1 > v2) {
				System.out.println("Maior valor: "+v1);
			} else {
				System.out.println("Maior valor: "+v2);
			}

		} else {
			System.out.println("Valores iguais!");
		}
		
		scan.close();
	}

}
