package exercicios;

public class Exercicio4 {

	public static void main(String[] args) {
		
		int v1 = 0;
		int v2 = 1;
		int v3 = 0;
		
		System.out.println(v1);
		System.out.println(v2);
			
		while (v3 <= 500) {
			v3 = v1 + v2;
			v1 = v2;
			v2 = v3;
			
			System.out.println(v3);
		}
		

	}

}
