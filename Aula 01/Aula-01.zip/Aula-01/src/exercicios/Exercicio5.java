package exercicios;

import java.util.Scanner;

public class Exercicio5 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o valor: ");
		int valor = scan.nextInt();
		
		System.out.println("Fatorial de "+valor+"!");
		
		int fatoracao = 1;
		for (int i = valor; i > 1; i--) {
			fatoracao *= i;
			System.out.print(i + " x ");
			
		}
		
		System.out.print("1 = " + fatoracao );

		scan.close();
	}

}
