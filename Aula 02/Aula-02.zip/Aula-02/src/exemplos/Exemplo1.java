package exemplos;

import javax.swing.JOptionPane;

public class Exemplo1 {

	public static void main(String[] args) {
		
		// aqui vai coment�rio de 1 linha
		
		/*
		 * aqui vai coment�rios de mais de uma linha 
		 */
		
		/**
		 *  Javadoc
		 *  <p> dsdsdasdasdasdas </p>
		 *  @param args Argumentos ssasas
		 */
		
		String s = JOptionPane.showInputDialog("Informe o seu nome: ");
		
		
		JOptionPane.showMessageDialog(null, "Ol� " + s);
		
		//DADOS INTEIROS
		byte bt1 = 5;
		short s1 = 10;
		int i = 10;
		long l = 10000L;
		
		//DADOS PONTO FLUTUANTE
		double d1 = 3.1415;
		float f1 = 3.1415f;
		
		//
		char c = 'A';
		boolean b = true;
		
		if (s1 == i) {
			System.out.println("Iguais");
		}
		
		if (s1 > i) {
			System.out.println("s1 � maior do que i");
		} else if (s1 < i) {
			System.out.println("i � maior do que s1 ");
		} else if (s1 == i) {
			System.out.println("Iguais");
		}
		
		
		
		if ((l < i) && (b)){   //b (b == true)
			System.out.println("l � maior que i");
		}

		
	}
	
	

}
