package exemplos;

import java.util.Scanner;

public class Exemplo2 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.print("Informe um n�mero: ");
		int v = leitor.nextInt();
		
		System.out.print("Informe um double: ");
		double d = leitor.nextDouble();
		
		System.out.println(v);
		System.out.println(d);
		
		
		leitor.close();

	}

}
