package exemplos;

import java.util.Scanner;

public class Exemplo3 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.print("Informe uma frase: ");
		String frase1 = leitor.nextLine(); // NEXTLINE pega a frase inteira
		
		System.out.print("Informe uma palavra: ");
		String palavra1 = leitor.next();  // NEXT pega somente a 1� palavra
		
		System.out.println("Frase = " + frase1);
		
		System.out.println("Palavra = " + palavra1);
		
		leitor.close();

	}

}
