package exemplos;

import java.util.Scanner;

public class Exemplo4 {

	public static void main(String[] args) {

		Scanner leitor = new Scanner(System.in);


		//DECRESCENTE
		for (int i = 9; i >= 0; i--) {
			System.out.println(i);
		}


		//DECRESCENTE
		int x = 10;	
		while(x > 0) {

			System.out.println(x);
			x--;
		}

		//SWITCH      ->  ' ' CHAR     ->  " " STRING  
		char letra = 'A';

		switch (letra) {
		case 'A':
			System.out.println("Digitou A");
			break;
		case 'B':
			System.out.println("Digitou B");
			break;
		default:
			System.out.println("Digitou outra...");
			break;
		}

		leitor.close();
		
	
	}

}
