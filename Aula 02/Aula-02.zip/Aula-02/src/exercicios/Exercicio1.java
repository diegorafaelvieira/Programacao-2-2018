package exercicios;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o valor do raio: ");
		double raio = scan.nextDouble();
		
		double area = Math.pow(raio, 2) * 3.14159;
		
		
		System.out.println("�rea c�rculo = " + area);
		
		
		scan.close();

	}

}
