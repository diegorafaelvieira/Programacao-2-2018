package exercicios;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a km inicial: ");
		double kmInicial = scan.nextDouble();
		
		System.out.print("Informe a km final: ");
		double kmFinal = scan.nextDouble();
		
		System.out.print("Informe a quantidade de litros de combust�vel: ");
		double qtdLitros = scan.nextDouble();
		
		double media = (kmFinal - kmInicial) / qtdLitros;
		
		System.out.println("A m�dia de km por litro: " + media );
		
		scan.close();

	}

}
