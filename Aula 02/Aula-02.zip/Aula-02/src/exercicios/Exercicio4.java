package exercicios;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o sal�rio R$ ");
		double sal = scan.nextDouble();
		
		
		double salNovo = 0;
		if (sal <= 1000) {
			salNovo = sal + (sal * 20) / 100;
			 
		} else if (sal > 1000 && sal <= 2000){
			salNovo = sal + (sal * 15) / 100;
		
		} else if (sal > 2000) {
			salNovo = sal + (sal * 10) / 100;
		}
		
		System.out.println(" Novo sal�rio R$" + salNovo);
	
		scan.close();
	}
		

}
