package exercicios;

import java.util.Scanner;

public class Exercicio5 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o n�mero de turmas: ");
		int turma = scan.nextInt();

		int aluno;
		int soma = 0;
		boolean invalido = true;

		for (int i = 1; i <= turma; i++) {
			
			invalido = true;
			do {
				System.out.print("Informe a quantidade de alunos da "+ i +" turma: ");
				aluno = scan.nextInt();
				
				if (aluno <= 32) {
					invalido = false;
					
				} else {
					System.out.println("N�mero de alunos inv�lidos. Digite novamente");
				}
			}while(invalido); 

			soma += aluno;		
				
			} 
		
			double media = soma / turma;
			
			System.out.println("Turmas: " + turma);
			System.out.println("Total de alunos: " + soma);
			System.out.println("M�dia de alunos por turma: " + media);
		
		scan.close();
		

	}

}
