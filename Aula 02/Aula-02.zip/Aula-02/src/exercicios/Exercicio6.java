package exercicios;

import java.util.Scanner;

public class Exercicio6 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a idade em dias: ");
		int idadeDias = scan.nextInt();
		
		int anos = idadeDias / 365;
		
		int meses = (idadeDias % 365) / 30;
		
		int dias = (idadeDias % 365) % 30;
	
		
		System.out.println(anos + " ano(s)");
		System.out.println(meses + " mese(s)");
		System.out.println(dias + " dia(s)");
		
		scan.close();

	}

}
