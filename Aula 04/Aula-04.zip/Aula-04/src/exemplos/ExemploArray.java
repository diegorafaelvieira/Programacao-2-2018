package exemplos;

public class ExemploArray {

	public static void main(String[] args) {
		
		//listas -> array
		
		int[] valores = new int[4];
		
		//preencher as posi��es
		valores[0] = 3;
		valores[1] = 7;
		valores[2] = 9;
		valores[3] = 2;
		
		//array com os valores j� definidos
		int[] valores2 = {3,7,9,2};
		
		for (int i = 0; i < valores.length; i++) {
			System.out.println(valores[i]);
		}
		
		for (int i = 0; i < valores2.length; i++) {
			System.out.println(valores2[i]);
		}
		
		//array String
		String[] nomes = new String[2];
		nomes[0] = "Mike";
		nomes[1] = "Mary";
		System.out.println(nomes[0] + " and " + nomes[1]);

		int i = 0;
		while(i < nomes.length) {
			System.out.println(nomes[i]);
			i++;
		}
		
	}

}
