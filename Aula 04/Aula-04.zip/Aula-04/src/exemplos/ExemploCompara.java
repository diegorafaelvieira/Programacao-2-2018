package exemplos;

public class ExemploCompara {

	public static void main(String[] args) {
		
		String c1 = "Feliz";
		String c2 = "Feliz";
		
		if (c1.charAt(0) == c2.charAt(0)) {
			System.out.println("Iguais");
		}
		
		//compara String
		if (c1.equals(c2)) {
			System.out.println("Iguais");
		}
		
		//comapara ignora maiusculas e minusculas
		if (c1.equalsIgnoreCase(c2)) {
			System.out.println("Iguais");
		}

	}

}
