package exemplos;

import javax.swing.JOptionPane;

public class ExemploTypecast {

	public static void main(String[] args) {
		
		String t = JOptionPane.showInputDialog("Informe um n�mero: ");
		
		if (t == null) {
			System.out.println("N�mero n�o informado");
		} else {
			// converte o string para int
			int i = Integer.parseInt(t);
			// aqui soma o valor + 10
			i += 10;
			System.out.println(i);
		}
		
		

		
	}

}
