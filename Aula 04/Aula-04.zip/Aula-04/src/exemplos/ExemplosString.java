package exemplos;

public class ExemplosString {

	public static void main(String[] args) {
		
		String banda = "Deep Purple";
		String banda2 = new String("Led");
		System.out.println(banda);
		System.out.println(banda2);

		char c1 = banda.charAt(0);
		System.out.println(c1);
		
		
		for (int i = 0; i < banda.length(); i++) {
			
			System.out.println(banda.charAt(i));
		}
		
		System.out.println(banda.toUpperCase()); //toda String em letra maiuscula
		System.out.println(banda.toLowerCase()); //toda String em letra minuscula
		
		int v1 = 100;
		int v2 = 200;
		//String + numero = converte o numero para String
		// tem que colocar os n�meros entre () para realizar a soma
		System.out.println("Soma = " + (v1 + v2));
		
		
	}

}
