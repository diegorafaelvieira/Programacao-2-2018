package exercicios;

import javax.swing.JOptionPane;

public class Exer01 {

	public static void main(String[] args) {
		
		String palavra = JOptionPane.showInputDialog("Informe uma palavra: ");

		if((palavra != null) && (palavra.length() > 0)) {
			boolean palindromo = true;
			
			for (int i = 0; i < palavra.length(); i++) {
				
				if (palavra.charAt(i) != palavra.charAt(palavra.length() - 1 -i)) {
					palindromo = false;
					break;
				}
					
			}
			
			if(palindromo) {
				System.out.println("� pal�ndromo");
			} else {
				System.out.println("N�o � palindromo");
			}
			
		}
	}

}
