package exercicios;


import javax.swing.JOptionPane;

public class Exer02 {

	public static void main(String[] args) {
		
		
		String[] palavras = new String[10];

		double media = 0;
		double soma = 0;
		for (int i = 0; i < palavras.length; i++) {
			
			String palavra = JOptionPane.showInputDialog("Informe uma palavra: ");
			System.out.println(palavra);
			//System.out.println(palavra.length()); imprimi o tamanho da palavra
			soma += palavra.length();
			
		}

		media = soma / palavras.length;
		
		System.out.println("TOTAL LETRAS = " + soma);
		System.out.println("A m�dia de caracteres � = " + media);

	}

}
