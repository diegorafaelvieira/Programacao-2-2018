package exercicios;

import java.util.Scanner;

public class Exer03 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a distancia a ser percorrida:");
        double distancia = scan.nextDouble();
        System.out.print("Informe a quantidade de litros de combustivel:");
        double litros = scan.nextDouble();
        System.out.print("Informe o valor do litro de gasolina:");
        double valorLitro = scan.nextDouble();
        System.out.print("Informe o valor do ped�gio:");
        double pedagio = scan.nextDouble();
		
		 
		double media = (distancia/litros);
		double custoViagem = (valorLitro * litros) + pedagio;
		
		
		System.out.println("A m�dia de consumo � de " + media +" km");
		System.out.println("O total de gastos na viagem foi de R$ " + custoViagem);
		scan.close();

	}

}
