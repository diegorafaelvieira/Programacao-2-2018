package exercicios;

import javax.swing.JOptionPane;

public class Exer04 {

	public static void main(String[] args) {

		String string1 = JOptionPane.showInputDialog("Digite a 1� palavra com 10 caracteres:");


		String string2 = JOptionPane.showInputDialog("Digite a 2� palavra com 10 caracteres:");

		//verifica o tamanho das strings
		if(string1.length() == 10 && string2.length() == 10) {
			int igual = 0;

			//verifica todos os caracteres e contamos todos os que s�o iguais
			for (int i = 0; i < 10; i++) {
				if(string1.charAt(i) == string2.charAt(i)) {
					igual++;
				}
			}

			//calcula percentual
			int percentual = igual * 10;
			System.out.println("String s�o "+ percentual + "% similares!");

		} else {
			System.out.println("Strings informadas n�o tem 10 caracteres!");
		}

	}

}
