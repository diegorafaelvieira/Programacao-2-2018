package exercicios;

import java.util.Scanner;

public class Exer05 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int[] valores = new int[5];
		
		
		int contNegativo = 0;
		for (int i = 0; i < valores.length; i++) {
			System.out.print("Digite o "+(i+1)+"� valor: ");
			valores[i] = scan.nextInt();
			
			
			if (valores[i] < 0) {
				contNegativo++;		
			} 
		}
		
		System.out.print("POSITIVOS = ");
		for (int i = 0; i < valores.length; i++) {
			if (valores[i] > 0) {
				System.out.print(valores[i]+" ");
			}		
		}
		System.out.println();
		
		System.out.println("Total de valores NEGATIVOS = "+ contNegativo);
		
		scan.close();

	}

}
