package exercicios;

import java.util.Scanner;

public class Exer06 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite a quantidade de elementos do array: ");
		int n = scan.nextInt();
		
		int[] elementos = new int[n];
		
		double media = 0;
		double soma = 0;
		for (int i = 0; i < elementos.length; i++) {
			
			System.out.print("Digite o valor: ");
			elementos[i] = scan.nextInt();
			System.out.println(elementos[i]+ " ["+i+"]");
			
			soma += elementos[i];
		
			
		}
		
		media = soma / n;
		
		System.out.println("SOMA dos valores contidos no array = " + soma);
		System.out.println("M�DIA dos valores contidos no array = " + media);
		
		scan.close();

	}

}
