package exercicios;

import javax.swing.JOptionPane;

public class testeMedia {

	public static void main(String[] args) {
		
				
				String numPalavras = JOptionPane.showInputDialog("Informe o n� de palavras: ");
				int npal = Integer.parseInt(numPalavras);
				
				String[] palavras = new String[npal];
		        double media = 0;
		        double soma = 0;
		        
		        for (int i = 0; i < palavras.length; i++) {    
		            String palavra = JOptionPane.showInputDialog("Informe uma palavra: ");
		            System.out.println(palavra);
		            soma += palavra.length();
		            
		        }
		        media = soma / npal;
		        
		        System.out.println("TOTAL = " + soma);
		        System.out.println("A m�dia de caracteres � = " + media);
				
			}

}
