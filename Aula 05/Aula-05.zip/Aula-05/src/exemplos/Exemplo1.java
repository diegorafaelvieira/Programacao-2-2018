package exemplos;

public class Exemplo1 {

	public static void main(String[] args) {
		
		int[] lista = new int[3];
		lista[0] = 5;
		lista[1] = 7;
		lista[2] = 3;

		int[] mesmaLista = {5,7,2};
		
		
		int[][] matriz = new int [2][3];
		matriz[0][0] = 10;
		matriz[0][1] = 20;
		matriz[0][2] = 30;
		
		matriz[1][0] = 40;
		matriz[1][1] = 50;
		matriz[1][2] = 60;
		
		//vai at� o 2 -- valor da esquerda
		for (int i = 0; i < matriz.length; i++) {
			
			for (int j = 0; j < matriz[i].length; j++) {
				
				System.out.print(matriz[i][j] + " ");
			}
			
			System.out.println();
		}
		
	}

}
