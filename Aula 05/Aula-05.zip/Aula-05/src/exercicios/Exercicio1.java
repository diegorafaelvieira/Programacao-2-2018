package exercicios;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		

		System.out.print("Informe a quantidade de alunos: ");
		int n = scan.nextInt();
		
		System.out.print("Informe a quantidade de notas: ");
		int m = scan.nextInt();
		
		double[][] notas = new double[n][m]; 
		String [] nomes = new String[n];
		
		//double soma = 0;
		double media = 0;
		double mediaTurma = 0;
		for (int i = 0; i < notas.length; i++) {
			
			System.out.print("Informe o nome do aluno: ");
			nomes[i] = scan.next();
			
			for (int j = 0; j < notas[i].length; j++) {
				
				System.out.print("Informe a "+(j+1)+"� nota do aluno "+nomes[i]+ ": ");
				notas[i][j] = scan.nextDouble();		
			
			}
	
		}
		
		System.out.println();
		
		//imprimir as notas
		double somaTotal = 0;
		for (int i = 0; i < notas.length; i++) {
			
			double soma = 0;
			for (int j = 0; j < notas[i].length; j++) {
				soma += notas[i][j]; // aqui vai somando as notas de um aluno espec�fico 
				somaTotal += notas[i][j]; // aqui vai somando todas as notas no geral
			}
		
			System.out.println("Total notas " + nomes[i] + " = " + soma);
			media = 0;
			media = soma / m; 
			
			System.out.println("M�dia aluno " + nomes[i] + " = " + media);				
			System.out.println();
		}
		System.out.println();
		
		mediaTurma = somaTotal / n; // faz a m�dia da turma
		System.out.println("M�dia da Turma = " + mediaTurma);

		scan.close();
	}

}
