package exemplos;

public class Carro {

	//Atributos
	public String cor;
	public int ano;
	public String modelo;
	public String marca;
	public int kmRevisao;
	
	// Metodos 
	public void imprimir() {
		
		System.out.println(this.marca);
		System.out.println(this.modelo);
		System.out.println(this.ano);
		System.out.println(this.cor);
		
	}
	
	//Metodo que retorna um dado(aqui int no caso)
	public int atualizaRevisao(int kmsAdicionais) {
		this.kmRevisao += kmsAdicionais;
		return this.kmRevisao;
	}
}
