package exemplos;

public class Cidade {

	//Atributos
	public String nome;
	public int nroHabitantes;
	public String estado;
	
	
}
