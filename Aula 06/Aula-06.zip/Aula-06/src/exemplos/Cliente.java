package exemplos;

public class Cliente {

	//Atributos
	public String nome;
	public String cpf;  //cpf se usa String
	public String dataNasc;
	
	
}
