package exemplos;

public class Computador {

	//Atributos
	public String processador;
	public String marca;
	public double pre�o;
	
	
}
