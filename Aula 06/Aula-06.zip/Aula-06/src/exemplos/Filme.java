package exemplos;

public class Filme {

	//Atributos
	public String t�tulo;
	public String diretor;
	public String g�nero;
	
	
}
