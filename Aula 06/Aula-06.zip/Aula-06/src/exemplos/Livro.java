package exemplos;

public class Livro {

	//Atributos
	public String t�tulo;
	public String autor;
	public String editora;
	
	
}
