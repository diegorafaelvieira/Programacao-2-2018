package exemplos;

public class Pessoa {

	//Atributos
	public String nome;
	public int idade;
	
	//M�todo   //void = n�o retorna nada ()=sem par�metro
	public void nascer(String nome) {
		this.idade = 0;
		this.nome = nome;
	}
	
	//Metodo
	public void aniversario() {
		this.idade ++;
		
	}
	
}
