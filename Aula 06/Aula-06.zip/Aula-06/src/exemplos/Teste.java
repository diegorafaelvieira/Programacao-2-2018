package exemplos;

public class Teste {

	public static void main(String[] args) {
		
		//Objeto
		Pessoa p1 = new Pessoa();
		p1.nascer("Luke");
		p1.nome = "Darth";
		p1.aniversario();
		p1.aniversario();
		System.out.println(p1.nome);
		System.out.println(p1.idade);
		
		System.out.println();
		
		//Objeto
		Pessoa p2 = new Pessoa();
		p2.nascer("Leia");
		p2.aniversario();
		System.out.println(p2.nome);
		System.out.println(p2.idade);
		
		System.out.println();
		
	}

}
