package exemplos;

public class Teste2 {

	public static void main(String[] args) {
		
		//Objeto
		Carro c1 = new Carro();
		c1.marca = "VW";
		c1.modelo = "Jetta";
		c1.ano = 2014;
		c1.cor = "Preto";
		c1.imprimir();
		//chama o m�todo e passa o par�metro
		int vr = c1.atualizaRevisao(10000);
		System.out.println(vr);
		
		System.out.println();
		
		//Objeto
		Carro c2 = new Carro();
		c2.marca = "VW";
		c2.modelo = "Jetta";
		c2.ano = 2014;
		c2.cor = "Preto";
		c2.imprimir();
		

	}

}
