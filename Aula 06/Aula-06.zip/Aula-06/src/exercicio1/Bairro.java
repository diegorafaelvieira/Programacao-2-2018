package exercicio1;

public class Bairro {

	//Atributos
	public String nome;
	public String cidade;
	public int nroHabitantes;
	
	//Metodo
	public void informacoes() {
		System.out.println("O bairro "+this.nome+" pertence a cidade " + this.cidade + " e possui "+ this.nroHabitantes + " habitantes");
	}
}
