package exercicio1;

public class Bebida {

	//Atributos
	public String marca;
	public double preco;
	public String conteudo;
	
	//Metodo
	public void imprimir() {
		System.out.println(this.marca);
		System.out.println(this.preco);
		System.out.println(this.conteudo);
	}
}
