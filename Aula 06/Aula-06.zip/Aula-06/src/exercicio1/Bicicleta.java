package exercicio1;

public class Bicicleta {

	//Atributos
	public String marca;
	public String modelo;
	public int marchas;
	
	
	//Metodo
	public void informacoes() {
		System.out.println("A bicicleta de modelo "+this.modelo+" da marca "+this.marca+" possui "+this.marchas+" marchas");
	}
}
