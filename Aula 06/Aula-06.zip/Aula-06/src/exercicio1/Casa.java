package exercicio1;

public class Casa {

	//Atributos
	public String cor;
	public int numero;
	public String bairro;
	
	//Metodo
	public void imprimir() {
		
		System.out.println(this.cor);
		System.out.println(this.numero);
		System.out.println(this.bairro);
		
	}
}
