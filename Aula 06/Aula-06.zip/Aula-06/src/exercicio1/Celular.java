package exercicio1;

public class Celular {

	//Atributos
	public String marca;
	public String modelo;
	public int ano;
	
	//Metodo
	public void informacoes() {
		System.out.println("O celular modelo "+this.modelo+" da marca "+this.marca+" foi lan�ado em "+this.ano);
	}
}
