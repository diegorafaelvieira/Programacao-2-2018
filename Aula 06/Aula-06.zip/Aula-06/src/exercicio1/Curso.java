package exercicio1;

public class Curso {

	//Atributos
	public String nome;
	public String institucao;
	public int qtdSemestre;
	
	//Metodo
	public void informacoes() {
		System.out.println("O curso "+this.nome+" da institui��o "+this.institucao+" possui "+
	this.qtdSemestre+" semestres");
	}
}
