package exercicio1;

public class Empresa {

	//Atributos
	public String nome;
	public String cnpj;
	public String cidade;
	
	//Metodo
	public void imprimir() {
		System.out.println(this.nome);
		System.out.println(this.cnpj);
		System.out.println(this.cidade);
	}
}
