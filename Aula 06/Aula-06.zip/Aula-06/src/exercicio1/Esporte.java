package exercicio1;

public class Esporte {

	//Atributos
	public String modalidade;
	public int qtdAtletas;
	public int tempo;

	//Metodos
	public void informacoes() {
		System.out.println("O esporte " + this.modalidade + " possui " + this.qtdAtletas + " atletas" + " e dura " + this.tempo + " minutos");
	}
}
