package exercicio1;

import java.util.Scanner;

public class TesteBairro {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//Captura dos dados
		System.out.print("Informe o nome do bairro: ");
		String nome = scan.next();
		
		System.out.print("Informe a cidade: ");
		String cidade = scan.next();
		
		System.out.print("Informe a quantidade de habitantes do bairro: ");
		int qtdHabitantes = scan.nextInt();
		
		//Objeto
		Bairro b1 = new Bairro();
		b1.nome = nome;
		b1.cidade = cidade;
		b1.nroHabitantes = qtdHabitantes;
		b1.informacoes();
		
		scan.close();
	}

}
