package exercicio1;

public class TesteBebida {

	public static void main(String[] args) {
		
		Bebida b1 = new Bebida();
		b1.marca = "Dolly";
		b1.preco = 1.99;
		b1.conteudo = "2 litros";
		b1.imprimir();
	}

}
