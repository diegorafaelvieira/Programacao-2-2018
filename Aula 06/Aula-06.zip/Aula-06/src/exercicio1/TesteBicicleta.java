package exercicio1;

import java.util.Scanner;

public class TesteBicicleta {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a marca da bicicleta: ");
		String marca = scan.next();
		System.out.print("Informe o modelo: ");
		String modelo = scan.next();
		System.out.print("Informe a quantidade de marchas: ");
		int marchas = scan.nextInt();
		
		//Objeto
		Bicicleta b1 = new Bicicleta();
		b1.marca = marca;
		b1.modelo = modelo;
		b1.marchas = marchas;
		b1.informacoes();
		
		
		
		scan.close();

	}

}
