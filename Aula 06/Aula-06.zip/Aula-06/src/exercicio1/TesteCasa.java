package exercicio1;

public class TesteCasa {

	public static void main(String[] args) {
		
		//Objeto
		Casa c1 = new Casa();
		c1.cor = "Amarela";
		c1.numero = 300;
		c1.bairro = "Vila do Chaves";
		c1.imprimir();

	}

}
