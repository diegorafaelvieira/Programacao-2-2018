package exercicio1;

import java.util.Scanner;

public class TesteCelular {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		
		System.out.print("Informe a marca do celular: ");
		String marca = scan.next();
		
		System.out.print("Informe o modelo da marca: ");
		String modelo = scan.next();
		
		System.out.print("Informe o ano de lan�amento do modelo :");
		int ano = scan.nextInt();
		

		scan.close();
		
		System.out.println();
		
		//Objeto
		Celular cel1 = new Celular();
		cel1.marca = marca;
		cel1.modelo = modelo;
		cel1.ano = ano;
		cel1.informacoes();

	}

}
