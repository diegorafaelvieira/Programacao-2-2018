package exercicio1;

import java.util.Scanner;

public class TesteCurso {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o nome do curso: ");
		String nomeCurso = scan.nextLine();
		System.out.print("Informe a quantidade de semestres: ");
		int qtd = scan.nextInt();
		System.out.print("Informe o nome da institui��o: ");
		String instituicao = scan.next();
		
		//Objeto
		Curso curso1 = new Curso();
		curso1.nome = nomeCurso;
		curso1.institucao = instituicao;
		curso1.qtdSemestre = qtd;
		curso1.informacoes();
		
		scan.close();

	}

}
