package exercicio1;

public class TesteEmpresa {

	public static void main(String[] args) {
		
		//Objeto
		Empresa e1 = new Empresa();
		e1.nome = "Tabajara";
		e1.cnpj = "12.345.678/0001";
		e1.cidade = "S�o Sebasti�o do Ca�";
		e1.imprimir();

	}

}
