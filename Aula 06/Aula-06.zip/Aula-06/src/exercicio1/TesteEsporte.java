package exercicio1;

import java.util.Scanner;

public class TesteEsporte {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//Coletando informa��es
		System.out.print("Infome a modalidade do esporte: ");
		String modalidade = scan.nextLine();
		
		System.out.print("Infome o n�mero de atletas: ");
		int atletas = scan.nextInt();
		
		System.out.print("Informe o tempo total da modalidade: ");
		int tempo = scan.nextInt();
		
		scan.close();
		//Quebra de linha
		System.out.println();
		
		//Objeto
		Esporte esporte1 = new Esporte();
		esporte1.modalidade = modalidade;
		esporte1.qtdAtletas = atletas;
		esporte1.tempo = tempo;
		esporte1.informacoes();


	}

}
