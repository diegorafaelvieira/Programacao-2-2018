package exercicio1;

import java.util.Scanner;

public class TesteViagem {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//Coletendo dados
		System.out.print("Informe a sa�da: ");
		String saida = scan.nextLine();
		
		System.out.print("Informe o destino: ");
		String destino = scan.nextLine();
		
		System.out.print("Informe o pre�o da viagem R$ ");
		double preco = scan.nextDouble();
		
		scan.close();
		
		//Objeto
		Viagem v1 = new Viagem();
		v1.saida = saida;
		v1.destino = destino;
		v1.preco = preco;
		v1.informacoes();

	}

}
