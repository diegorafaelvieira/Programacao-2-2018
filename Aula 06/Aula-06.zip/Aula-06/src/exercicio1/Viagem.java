package exercicio1;

public class Viagem {

	//Atributos
	public String saida;
	public String destino;
	public double preco;
	
	//Metodo
	public void informacoes() {
		System.out.println("A viagem tem sa�da de "+ this.saida + " com destino a " + this.destino + " custa R$ "+ this.preco);
	}
	
	
}
