package exercicio2;

public class Pais {

	//Atributos
	public String nome;
	public String capital;
	public int nroHabitantes;
	
	//Metodo
	public void informacoesPais() {
		System.out.println("O pa�s "+this.nome+" possui a capital "+this.capital+" e "+this.nroHabitantes+ " de habitantes");
	}
}
