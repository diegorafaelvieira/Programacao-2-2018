package exercicio2;

import java.util.Scanner;

public class TestePais {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite o nome do pa�s: ");
		String nomePais = scan.nextLine();
		System.out.print("Informe a capital de "+nomePais+" : ");
		String capital = scan.nextLine();
		System.out.print("Informe a quantidade de habitantes: ");
		int qtdHabitantes = scan.nextInt();
		
		//Objeto
		Pais p1 = new Pais();
		p1.nome = nomePais;
		p1.capital = capital;
		p1.nroHabitantes = qtdHabitantes;
		p1.informacoesPais();
		
		scan.close();

	}

}
