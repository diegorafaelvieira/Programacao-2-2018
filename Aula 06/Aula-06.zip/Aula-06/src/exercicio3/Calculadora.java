package exercicio3;

public class Calculadora {

	int resultado;
	double media;
	
	
	//Metodos
	public int soma(int valor1, int valor2) {
		resultado = valor1 + valor2;
		return this.resultado;
	}
	
	public int subtracao(int valor1, int valor2) {
		resultado = valor1 - valor2;
		return this.resultado;
	}
	
	public int multiplicacao(int valor1, int valor2) {
		resultado = valor1 * valor2;
		return this.resultado;
	}
	
	public int divisao(int valor1, int valor2) {
		resultado = valor1 / valor2;
		return this.resultado;
	}
	
	public double media(double valor1, double valor2) {
		media = (valor1 + valor2) / 2;
		return this.media;
	}
	
}
