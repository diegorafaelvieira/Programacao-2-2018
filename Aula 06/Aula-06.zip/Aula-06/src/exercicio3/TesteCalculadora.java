package exercicio3;

import java.util.Scanner;

public class TesteCalculadora {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		double mostrar;
		double[] media = new double[2];
		
		
		System.out.print("Informe o 1� valor: ");
		int val1 = scan.nextInt();
		System.out.print("Informe o 2� valor: ");
		int val2 = scan.nextInt();
		
		//Aqui pego os valores para a m�dia
		media[0] = val1;
		media[1] = val2;
		System.out.println();
		
		Calculadora c1 = new Calculadora();
		mostrar = c1.soma(val1, val2);
		System.out.println("SOMA = "+ mostrar);
		mostrar = c1.subtracao(val1, val2);
		System.out.println("SUBTRA��O = "+ mostrar);
		mostrar = c1.multiplicacao(val1, val2);
		System.out.println("MULTIPLICA��O = "+ mostrar);
		mostrar = c1.divisao(val1, val2);
		System.out.println("DIVIS�O = "+ mostrar);
		mostrar = c1.media(media[0], media[1]);
		System.out.println("M�DIA = "+ mostrar);
		
		scan.close();
	}

}
