package exercicio4;

public class Aluno {

	//Atributos
	public String nome;
	public String curso;
	public String dataAdmissao;
	public String matricula;
	
	//Metodo
	public void imprimir() {
		System.out.println("O aluno "+this.nome+" cursa "+this.curso+",foi admitido em "+this.dataAdmissao
				+ " e possu� a matr�cula "+this.matricula);
	}
	
}
