package exercicio4;

import java.util.Scanner;

public class TesteAluno {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite o nome do aluno: ");
		String nomeAluno = scan.nextLine();
		System.out.print("Informe o curso do aluno: ");
		String alunoCurso = scan.nextLine();
		System.out.print("Informe a data de admiss�o do aluno: ");
		String dataAdmissaoAluno = scan.nextLine();
		System.out.print("Digite o n�mero de matr�cula do aluno: ");
		String matriculaAluno = scan.nextLine();
		
		System.out.println();
		
		//Objeto
		Aluno a1 = new Aluno();
		a1.nome = nomeAluno;
		a1.curso = alunoCurso;
		a1.dataAdmissao = dataAdmissaoAluno;
		a1.matricula = matriculaAluno;
		a1.imprimir();
		
		scan.close();

	}

}
