package exemplos;

public class Cidade {

	//Atributos
	public int populacao;
	public String nome;
	
	
	//Metodos
	public void imprimir() {
		System.out.println(this.populacao);
		System.out.println(this.nome);
	}
	
	
	public String formatar() {
		
		String r = "A cidade de " + this.nome + " possui " + this.populacao + " habitantes";
		
		return r;
	}
	
	
}
