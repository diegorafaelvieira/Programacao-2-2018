package exemplos;

import java.util.Scanner;

public class Teste1 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		
		//Objeto
		Cidade c1 = new Cidade();
		System.out.print("Nome: ");
		c1.nome = leitor.next();
		System.out.print("Popula��o: ");
		c1.populacao = leitor.nextInt();
		c1.imprimir();
		
		//quando n�o � void precisa criar uma vari�vel antes
		String saida = c1.formatar();
		System.out.println(saida);
		
		
		leitor.close();
	}

}
