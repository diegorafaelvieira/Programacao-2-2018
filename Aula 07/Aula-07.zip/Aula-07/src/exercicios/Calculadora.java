package exercicios;

public class Calculadora {

	//Metodo
	public int soma(int a, int b) {
		return(a+b);
	}
	
	public double media(double[] valores) {
		double soma = 0;
		for (int i = 0; i < valores.length; i++) {
			soma += valores[i];
		}
		double media = soma / valores.length;
		return media;
	}
}
