package exercicios;

public class Celular {

	//Atributos
	public String modelo;
	public String marca;
	
	
	
}
