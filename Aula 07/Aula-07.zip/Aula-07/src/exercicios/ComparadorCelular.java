package exercicios;

public class ComparadorCelular {

	//Metodo
	//Compara os celulares
	public boolean comparar(Celular c1, Celular c2) {
		
		if(c1.marca.equalsIgnoreCase(c2.marca)) {
			System.out.println("Marcas iguais!");
		} else {
			System.out.println("Marcas diferentes!");
		}
		
		if(c1.modelo.equalsIgnoreCase(c2.modelo)) {
			System.out.println("Modelos iguais!");
		} else {
			System.out.println("Modelos diferentes!");
		}
		
		return true;
	}
	
}
