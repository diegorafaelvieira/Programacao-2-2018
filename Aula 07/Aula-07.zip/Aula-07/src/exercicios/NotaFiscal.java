package exercicios;

public class NotaFiscal {

	//Atributos
	public int codItem;
	public String descricao;
	public int quantidade;
	public double precoUnitario;
	
	//Metodo
	public String imprimir(int codItem, String descricao, int quantidade, double precoUnitario) {

		
		if(codItem <= 0 || descricao == " " || precoUnitario <= 0 || quantidade <= 0 ) {
			
			String resposta = "Nota inv�lida! Preencha os valores corretamente";
			
			return resposta;
		
		} else {
			
			double total = this.precoUnitario * this.quantidade;
			
			return "C�DIGO ITEM: " + codItem + " - DESCRI��O: " +  descricao + " - QUANTIDADE: "+ quantidade 
					+ " - PRE�O UNIT�RIO R$ " + precoUnitario + " - TOTAL R$ " + Double.toString(total);
		}
		
	
	}
	
}
