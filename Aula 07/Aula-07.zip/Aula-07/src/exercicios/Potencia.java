package exercicios;

public class Potencia {

	//Atributos
	public int valor;
	public int exponte;
	
	
	//Metodo
	int elevadoA(int valor, int exponte) {
		
		int potencia = 1, contador = 0;
		while(contador != exponte)
		{
				potencia *= valor;	
				contador++;		 
		}
		 
		return(potencia);
	}
	
	
	
}
