package exercicios;

public class TesteCalculador {

	public static void main(String[] args) {
		
		Calculadora c = new Calculadora();
		
		//soma 
		int s = c.soma(10,20);
		System.out.println(s);
		
		//media
		double[] v = {3.4, 5.6, 7.8, 10};
		double m = c.media(v);
		System.out.println(m);
	}

}
