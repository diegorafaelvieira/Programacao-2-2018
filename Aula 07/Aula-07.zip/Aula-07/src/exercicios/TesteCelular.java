package exercicios;

import java.util.Scanner;

public class TesteCelular {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//Objeto
		Celular cel1 = new Celular();
		System.out.print("Marca: ");
		cel1.marca = scan.next();
		System.out.print("Modelo: ");
		cel1.modelo = scan.next();
		
		System.out.println();
		
		Celular cel2 = new Celular();
		System.out.print("Marca: ");
		cel2.marca = scan.next();
		System.out.print("Modelo: ");
		cel2.modelo = scan.next();
		
		scan.close();
		
		//Objeto = atributo Classe
		Celular c1 = new Celular();
		c1.marca = cel1.marca;
		c1.modelo = cel1.modelo;
		
		Celular c2 = new Celular();
		c2.marca =  cel2.marca;
		c2.modelo = cel2.modelo;
		
		System.out.println("COMPARANDO");
		
		ComparadorCelular comparar = new ComparadorCelular();
		comparar.comparar(c1, c2);
		
	}

}
