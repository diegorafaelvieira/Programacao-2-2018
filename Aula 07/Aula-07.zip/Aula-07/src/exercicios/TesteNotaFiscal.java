package exercicios;

import java.util.Scanner;

public class TesteNotaFiscal {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite o c�digo do produto: ");
		int codItem = scan.nextInt();
		System.out.print("Digite a descri��o do produto: ");
		String descricao = scan.next();
		System.out.print("Digite a quantidade: ");
		int quantidade = scan.nextInt();
		System.out.print("Digite o pre�o unit�rio R$ ");
		double precoUnitario  = scan.nextDouble();

		scan.close();
		
		//Objeto
		NotaFiscal nf = new NotaFiscal();
		nf.codItem = codItem;
		nf.descricao = descricao;
		nf.quantidade = quantidade;
		nf.precoUnitario = precoUnitario;
		String resultado = nf.imprimir(codItem, descricao, quantidade, precoUnitario);
		System.out.println(resultado);
	}

}
