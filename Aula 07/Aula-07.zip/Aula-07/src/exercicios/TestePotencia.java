package exercicios;

import java.util.Scanner;

public class TestePotencia {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		
		System.out.print("Informe o valor: ");
		int valor = scan.nextInt();
		System.out.print("Informe a pot�ncia: ");
		int exponte = scan.nextInt();
		
		
		scan.close();
		
		
		Potencia p1 = new Potencia();
		p1.valor = valor;
		p1.exponte = exponte;
		int resultado = p1.elevadoA(valor, exponte);
		System.out.println("RESULTADO = "+resultado);
	}

}
