package exemplos;

public class Pessoa {

	//Atributos PRIVADOS
	private String nome;
	private int idade;
	
	//Construtor
	public Pessoa() {
		this.nome = "Jane Doe";
		this.idade = 20;
	}
	
	//Construtor
	public Pessoa(String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
	}
	
	//Metodo
	/*
	private void nascer() {
		this.nome = "Maria";
		this.idade = 0;
	}
	*/
	//Metodo
	/*
	public void imprimir() {
		//this.nascer();
		System.out.println(this.nome);
		System.out.println(this.idade);
	}
	*/
	
	//GET NOME
	public String getNome() {
		return this.nome;
	}
	
	//SET NOME
	public void setNome (String nome) {
		this.nome = nome;
	}
	
	//GET IDADE
	public int getIdade() {
		return this.idade;
	}
	
	//SET IDADE
	public void setIdade (int idade) {
		// aqui pode ser feita as verifica��es IF se necess�rio
		this.idade = idade;
	}
}
