package exemplos;

public class TestePessoa {

	public static void main(String[] args) {
		
		
		//Objeto
		Pessoa p1 = new Pessoa("Jane", 30);
		//p1.nome = "Mike";
		//p1.idade = 30;
		//p1.nascer();
		//p1.imprimir();
		
		//GET ler valor
		System.out.println(p1.getNome());
		System.out.println(p1.getIdade());
		
		//SET Modificar o valor
		p1.setIdade(40);
		
	}

}
