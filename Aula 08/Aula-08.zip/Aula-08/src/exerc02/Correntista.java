package exerc02;

public class Correntista {

	//Atributos
	private String nome;
	private double saldo;
	private double credito;
	private double debito;
	
	//Construtor
	public Correntista(String nome, double saldo, double credito, double debito) {
		
		this.nome = nome;
		this.saldo = saldo;
		this.credito = credito;
		this.debito = debito;

	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getCredito() {
		return credito;
	}

	public void setCredito(double credito) {
		this.credito = credito;
	}

	public double getDebito() {
		return debito;
	}

	public void setDebito(double debito) {
		this.debito = debito;
	}
	
	//METODO
	public void informacoes() {
		System.out.println("O correntista de nome "+this.getNome()+" possu� saldo de R$"+this.getSaldo());
	}
	
}
