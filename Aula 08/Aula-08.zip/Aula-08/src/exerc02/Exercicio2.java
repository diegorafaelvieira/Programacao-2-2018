package exerc02;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {


		Scanner scan = new Scanner(System.in);

		double credito = 0;
		double debito = 0;
		int opc = 0;


		System.out.print("Digite o nome: ");
		String nome = scan.nextLine();
		System.out.print("Digite o saldo R$ ");
		double saldo = scan.nextDouble();

		//CRIAR VERS�o COM OBJETO AQUI
		//Correntista c1 = new Correntista(nome, saldo, credito, debito);

		while (opc != 3) {

			System.out.println("SELECIONE A OP��O DESEJADA");
			System.out.println(" 1 - CR�DITO | 2 - D�BITO | 3 - SAIR ");
			opc = scan.nextInt();

			switch (opc) {
			case 1:
				System.out.print("Informe o valor a ser creditado R$ ");
				credito = scan.nextDouble();
				saldo = saldo + credito;
				//c1.setSaldo(c1.getSaldo() + credito)
				break;

			case 2:
				System.out.print("Informe o valor a ser debitado R$ ");
				debito = scan.nextDouble();
				saldo = saldo - debito;
				//c1.setSaldo(c1.getSaldo() - debito);
				break;

			case 3:
				System.out.println("Opera��es encerradas!");
				break;

			default:
				System.out.println("Op��o inv�lida!");
				break;
			}

		}


		scan.close();


		//Objeto
		Correntista c1 = new Correntista(nome, saldo, credito, debito);
		c1.informacoes();



	}

}
