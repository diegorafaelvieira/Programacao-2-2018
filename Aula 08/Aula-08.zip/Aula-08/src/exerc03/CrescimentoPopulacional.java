package exerc03;

public class CrescimentoPopulacional {

	//Atributos
	private double populacaoA;
	private double populacaoB;
	private double taxaA;
	private double taxaB;



	//Construtor
	public CrescimentoPopulacional(double populacaoA, double populacaoB, double taxaA, double taxaB) {
		
		this.populacaoA = populacaoA;
		this.populacaoB = populacaoB;
		this.taxaA = taxaA;
		this.taxaB = taxaB;

		
	}


	//Metodos
	public int calculaAnos() {
		if (populacaoA >= populacaoB) {
			return 0;
		}

		if (taxaA <= taxaB) {
			return 0;
		
		} else {
			int anos = 0;
			while (populacaoA < populacaoB) {
				populacaoB = populacaoB * taxaB;
				populacaoA = populacaoA * taxaA;
				anos++;
			}

			return anos;
		}
	}
	
}
