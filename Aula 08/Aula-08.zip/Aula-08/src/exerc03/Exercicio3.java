package exerc03;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a quantidade de habitante da cidade A: ");
		double populacaoA = scan.nextInt();
		System.out.print("Informe a taxa de crescimento da cidade A: ");
		double taxaA = scan.nextDouble();
		System.out.println();
		System.out.print("Informe a quantidade de habitante da cidade B: ");
		double populacaoB = scan.nextInt();
		System.out.print("Informe a taxa de crescimento da cidade B: ");
		double taxaB = scan.nextDouble();
		System.out.println();
		
		scan.close();
		
		CrescimentoPopulacional cp1 = new CrescimentoPopulacional(populacaoA, populacaoB, taxaA, taxaB);
		System.out.println(cp1.calculaAnos() + " anos");
	}

}
