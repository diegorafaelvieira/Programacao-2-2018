package jogo;

import jogo.pessoas.Jogador;
import jogo.pessoas.Treinador;

public class Equipe {

	//Atributos   IMPORTANDO CLASSES
	private Treinador treinador;
	private Jogador goleiro;
	private Jogador zagueiro;
	
	//Construtor
	public Equipe(Treinador treinador, Jogador goleiro, Jogador zagueiro) {
		this.treinador = treinador;
		this.goleiro = goleiro;
		this.zagueiro = zagueiro;
	
	}

	//GET e SET
	public Treinador getTreinador() {
		return treinador;
	}

	public void setTreinador(Treinador treinador) {
		this.treinador = treinador;
	}

	public Jogador getGoleiro() {
		return goleiro;
	}

	public void setGoleiro(Jogador goleiro) {
		this.goleiro = goleiro;
	}

	public Jogador getZagueiro() {
		return zagueiro;
	}

	public void setZagueiro(Jogador zagueiro) {
		this.zagueiro = zagueiro;
	}
	
	
	
}
