package jogo;

import jogo.equipamentos.Bola;
import jogo.equipamentos.Campo;
import jogo.pessoas.Jogador;
import jogo.pessoas.Juiz;
import jogo.pessoas.Treinador;

public class Exemplo {

	public static void main(String[] args) {
		
		//Objetos EQUIPE 1
		Treinador t1 = new Treinador("Odair");
		Jogador j11 = new Jogador("Dalessandro");
		Jogador j12 = new Jogador("Patrick");
		//
		Equipe e1 = new Equipe(t1, j11, j12);
		
		// Objetos EQUIPE 2
		Treinador t2 = new Treinador("Renato");
		Jogador j21 = new Jogador("Geromel");
		Jogador j22 = new Jogador("Caonemann");
		//
		Equipe e2 = new Equipe(t2, j21, j22);

		// Objeto Juiz , Bola e Campo
		Juiz j = new Juiz("Arnaldo");
		Bola b = new Bola("Adidas");
		Campo c = new Campo(80, 120);
		
		// Objeto Futebol   //clicar na janela de ajuda   
		Futebol f = new Futebol(e1, e2, j, c, b);
		System.out.println(f.getJuiz().getNome());  // 1 get juiz e assim temos acesso ao nome dele
		System.out.println(f.getEquipe2().getTreinador().getNome()); //treinador e2= entra na equipe 2 -> treinador -> nome treinador
		f.getCampo().setLargura(110);  //aqui acessamos a largura do campo e depois a alteramos 
		
	}

}
