package jogo.equipamentos;

public class Campo {

	//Atributos
	private int largura;
	private int comprimento;
	
	//Construtor
	public Campo(int largura, int comprimento) {
		this.largura = largura;
		this.comprimento = comprimento;
	}

	//GET e SET
	public int getLargura() {
		return largura;
	}

	public void setLargura(int largura) {
		this.largura = largura;
	}

	public int getComprimento() {
		return comprimento;
	}

	public void setComprimento(int comprimento) {
		this.comprimento = comprimento;
	}
	
	
}
