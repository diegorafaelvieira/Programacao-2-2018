package jogo.pessoas;

public class Jogador {
	
	//Atributos
	private String nome;

	//Construtor
	public Jogador(String nome) {
		super();
		this.nome = nome;
	}

	
	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
	
	
	
}
