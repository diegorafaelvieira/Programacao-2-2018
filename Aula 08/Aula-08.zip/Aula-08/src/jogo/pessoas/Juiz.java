package jogo.pessoas;

public class Juiz {

	//Atributos
	private String nome;
	
	//Construtor
	public Juiz (String nome) {
		this.nome =  nome;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
