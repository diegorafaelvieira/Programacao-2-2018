package jogo.pessoas;

public class Treinador {

	//Atributos
	private String nome;
	
	//Construtor
	public Treinador (String nome) {
		this.nome = nome;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
