package bairro;

public class Bairro {

	//Atributos
	private String nome;
	private int nroHabitantes;
	private String cidade;
	
	//Construtor
	public Bairro(String nome, int nroHabitantes, String cidade) {
		super();
		this.nome = nome;
		this.nroHabitantes = nroHabitantes;
		this.cidade = cidade;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getNroHabitantes() {
		return nroHabitantes;
	}

	public void setNroHabitantes(int nroHabitantes) {
		this.nroHabitantes = nroHabitantes;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	
	
	
	
}
