package bairro;

import java.util.Scanner;

public class TesteBairro {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite o nome do bairro: ");
		String nome = scan.nextLine();
		
		System.out.print("Informe a quantidade de habitantes do bairro: ");
		int nroHabitantes = scan.nextInt();
		
		scan.nextLine(); // limpar
		System.out.print("Informe a cidade � qual pertence o bairro: ");
		String cidade = scan.nextLine();
		
		scan.close();
		
		Bairro b1 = new Bairro(nome, nroHabitantes, cidade);
		System.out.println("NOME BAIRRO: " + b1.getNome());
		System.out.println("NRO HABITANTES: "+b1.getNroHabitantes());
		System.out.println("CIDADE BAIRRO: "+ b1.getCidade());

	}

}
