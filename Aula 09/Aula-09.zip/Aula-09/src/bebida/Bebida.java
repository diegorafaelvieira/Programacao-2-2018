package bebida;

public class Bebida {

	//Atributos
	private String marca;
	private double conteudo;
	private double preco;
	
	//Construtor
	public Bebida(String marca, double conteudo, double preco) {
		
		this.marca = marca;
		this.conteudo = conteudo;
		this.preco = preco;
	}

	
	//GET e SET
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public double getConteudo() {
		return conteudo;
	}

	public void setConteudo(double conteudo) {
		this.conteudo = conteudo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
	
	
}
