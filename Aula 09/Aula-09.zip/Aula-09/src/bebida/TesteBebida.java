package bebida;

import java.util.Scanner;

public class TesteBebida {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a marca: ");
		String marca = scan.nextLine();
		System.out.print("Qual a conte�do da embalagem: ");
		double conteudo =  scan.nextDouble();
		System.out.print("Qual o valor da bebida R$ ");
		double preco = scan.nextDouble();
		
		scan.close();
		
		Bebida b1 = new Bebida(marca, conteudo, preco);
		System.out.println("MARCA: "+b1.getMarca());
		System.out.println("CONTE�DO EMBALAGEM: "+b1.getConteudo()+ " LT");
		System.out.println("PRE�O R$ "+b1.getPreco());

	}

}
