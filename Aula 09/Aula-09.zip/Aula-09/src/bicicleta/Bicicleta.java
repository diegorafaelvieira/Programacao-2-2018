package bicicleta;

public class Bicicleta {

	
	//Atributos
	private String marca;
	private String modelo;
	private int qtdMarchas;
	
	//
	public Bicicleta(String marca, String modelo, int qtdMarchas) {
		
		this.marca = marca;
		this.modelo = modelo;
		this.qtdMarchas = qtdMarchas;
	}

	//GET e SET
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getQtdMarchas() {
		return qtdMarchas;
	}

	public void setQtdMarchas(int qtdMarchas) {
		this.qtdMarchas = qtdMarchas;
	}
	
	
}
