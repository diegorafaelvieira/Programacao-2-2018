package bicicleta;

import java.util.Scanner;

public class TesteBicicleta {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe a marca da bicicleta: ");
		String marca = scan.nextLine();
		System.out.print("Informe o modelo da bicicleta: ");
		String modelo = scan.nextLine();
		System.out.print("Informe a quantidade de marchas: ");
		int qtdMarchas = scan.nextInt();
		
		scan.close();
		
		Bicicleta bike = new Bicicleta(marca, modelo, qtdMarchas);
		System.out.println("MARCA BICICLETA: " + bike.getMarca());
		System.out.println("MODELO BICICLETA: " + bike.getModelo());
		System.out.println("QUANTIDADE MARCHAS: " + bike.getQtdMarchas());
		

	}

}
