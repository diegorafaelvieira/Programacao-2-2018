package casa;

public class Casa {

	//Atributos
	private String cor; 
	private String rua;
	private String numero;
	
	//Cosntrutor
	public Casa(String cor, String rua, String numero) {

		this.cor = cor;
		this.rua = rua;
		this.numero = numero;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	

	
}
