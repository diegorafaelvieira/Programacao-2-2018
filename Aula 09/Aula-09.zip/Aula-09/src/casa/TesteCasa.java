package casa;

import java.util.Scanner;

public class TesteCasa {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		
		System.out.print("Informe a cor da casa: ");
		String cor = scan.next();
		
		
		
		System.out.print("Informe o n�mero da casa: ");
		String numero = scan.next();
		
		scan.nextLine(); // aqui esvazio o nextLine antes
		System.out.print("Informe o nome da rua: ");
		String rua = scan.nextLine();
		

		scan.close();
		
		Casa c1 = new Casa(cor, rua, numero);
		System.out.println("COR DA CASA: "+c1.getCor());
		System.out.println("RUA: "+c1.getRua());
		System.out.println("N�MERO: "+c1.getNumero());
	}

}
