package celular;

import java.util.Scanner;

public class TesteCelular {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Informe a marca do celular: ");
		String marca = scan.nextLine();
		System.out.print("Informe o modelo do celular: ");
		String modelo = scan.nextLine();
		System.out.print("Pre�o do celular R$ ");
		double preco = scan.nextDouble();
		
		
		scan.close();
		
		//objeto
		Celular cel = new Celular(marca, modelo, preco);
		System.out.println("MARCA: "+ cel.getMarca());
		System.out.println("MODELO: " + cel.getModelo());
		System.out.println("PRE�O R$ "+ cel.getPreco());

	}

}
