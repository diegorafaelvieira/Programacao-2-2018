package curso;

public class Curso {

	
	//Atributos
	private String nome;
	private int qtdSemestre;
	private int qtdCadeira;
	
	//Construtor
	public Curso(String nome, int qtdSemestre, int qtdCadeira) {
		
		this.nome = nome;
		this.qtdSemestre = qtdSemestre;
		this.qtdCadeira = qtdCadeira;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQtdSemestre() {
		return qtdSemestre;
	}

	public void setQtdSemestre(int qtdSemestre) {
		this.qtdSemestre = qtdSemestre;
	}

	public int getQtdCadeira() {
		return qtdCadeira;
	}

	public void setQtdCadeira(int qtdCadeira) {
		this.qtdCadeira = qtdCadeira;
	}
	
	
}
