package curso;

import java.util.Scanner;

public class TesteCurso {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite o nome do curso: ");
		String nome = scan.nextLine();
		System.out.print("Digite a quantidade de semestres do curso: ");
		int qtdSemestre = scan.nextInt();
		System.out.print("Digite o n�mero de cadeiras do curso: ");
		int qtdCadeira = scan.nextInt();
		
		
		scan.close();

		Curso c = new Curso(nome, qtdSemestre, qtdCadeira);
		System.out.println("NOME CURSO: " + c.getNome());
		System.out.println("NRO SEMESTRES: " + c.getQtdSemestre());
		System.out.println("NRO CADEIRAS: " + c.getQtdCadeira());
		
	}

}
