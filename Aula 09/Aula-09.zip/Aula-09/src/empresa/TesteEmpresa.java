package empresa;

import java.util.Scanner;

public class TesteEmpresa {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		System.out.print("Informe a raz�o social: ");
		String razaoSocial = scan.nextLine();
		System.out.print("Informe o CNPJ: ");
		String cnpj = scan.next();
		scan.nextLine();
		System.out.print("Informe a cidade da empresa: ");
		String cidade = scan.nextLine();
		
		scan.close();
		
		Empresa e1 = new Empresa(razaoSocial, cnpj, cidade);
		System.out.println("RAZ�O SOCIAL: "+e1.getRazaoSocial());
		System.out.println("CNPJ: " + e1.getCnpj());
		System.out.println("CIDADE: " + e1.getCidade());
	}

}
