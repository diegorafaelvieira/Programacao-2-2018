package esporte;

public class Esporte {

	//Atributos
	private String nome;
	private int qtdAtletas;
	private int qtdTempo;
	
	//Construtor
	public Esporte(String nome, int qtdAtletas, int qtdTempo) {
		
		this.nome = nome;
		this.qtdAtletas = qtdAtletas;
		this.qtdTempo = qtdTempo;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQtdAtletas() {
		return qtdAtletas;
	}

	public void setQtdAtletas(int qtdAtletas) {
		this.qtdAtletas = qtdAtletas;
	}

	public int getQtdTempo() {
		return qtdTempo;
	}

	public void setQtdTempo(int qtdTempo) {
		this.qtdTempo = qtdTempo;
	}
	
	
	
	
}
