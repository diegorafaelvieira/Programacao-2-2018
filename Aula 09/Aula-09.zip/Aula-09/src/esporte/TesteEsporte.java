package esporte;

import java.util.Scanner;

public class TesteEsporte {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Informe o nome do esporte: ");
		String nome = scan.nextLine();
		System.out.print("Informe a quantidade de atletas da modalidade: ");
		int qtdAtletas = scan.nextInt();
		System.out.print("Informe a quantidade de tempos da modalidade: ");
		int qtdTempo = scan.nextInt();
		
		scan.close();
		
		Esporte esp1 = new Esporte(nome, qtdAtletas, qtdTempo);
		System.out.println("NOME MODALIDADE: "+esp1.getNome());
		System.out.println("QUANTIDADE DE ATLETAS: "+esp1.getQtdAtletas());
		System.out.println("QUANTIDADE DE TEMPO MODALIDADE: "+ esp1.getQtdTempo());

	}

}
