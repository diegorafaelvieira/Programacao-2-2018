package viagem;

import java.util.Scanner;

public class TesteViagem {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		//scan.nextLine();
		System.out.print("Informe a sa�da da viagem: ");
		String saida = scan.nextLine();
		//scan.nextLine();
		System.out.print("Informe o destino da viagem: ");
		String destino = scan.nextLine();
		System.out.print("Informe o pre�o da viagem R$ ");
		double custo = scan.nextDouble();
		
		
		scan.close();
		
		Viagem v1 = new Viagem(saida, destino, custo);
		System.out.println("SA�DA: " + v1.getSaida());
		System.out.println("DESTINO: "+ v1.getDestino());
		System.out.println("PRE�O R$ " + v1.getCusto());

	}

}
