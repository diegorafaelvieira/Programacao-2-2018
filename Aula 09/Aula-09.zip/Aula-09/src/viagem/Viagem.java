package viagem;

public class Viagem {

	//Atributos
	private String saida;
	private String destino;
	private double custo;
	
	//Construtor
	public Viagem(String saida, String destino, double custo) {
		super();
		this.saida = saida;
		this.destino = destino;
		this.custo = custo;
	}

	//GET e SET
	public String getSaida() {
		return saida;
	}

	public void setSaida(String saida) {
		this.saida = saida;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public double getCusto() {
		return custo;
	}

	public void setCusto(double custo) {
		this.custo = custo;
	}
	
	
	
	
}
