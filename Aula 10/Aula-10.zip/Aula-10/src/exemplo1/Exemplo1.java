package exemplo1;


public class Exemplo1 {

	public static void main(String[] args) {

		Viagem[] lista = new Viagem[2];
		lista[0] = new Viagem("A","B",1000);
		lista[1] = new Viagem("C","D",400);
		lista[0].setDestino("abc");  //novo destino para o lista[0]

		//percorrer o array
		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i].getOrigem());
			System.out.println(lista[i].getDestino());
			System.out.println(lista[i].getGasto());
			System.out.println();
		}
		
		
	}

}
