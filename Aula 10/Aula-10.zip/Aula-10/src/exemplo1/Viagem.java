package exemplo1;

public class Viagem {

	//Atributos
	private String origem;
	private String destino;
	private double gasto;
	
	//Construtor
	public Viagem(String origem, String destino, double gasto) {
		
		this.origem = origem;
		this.destino = destino;
		this.gasto = gasto;
	}

	
	//GET e SET
	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public double getGasto() {
		return gasto;
	}

	public void setGasto(double gasto) {
		this.gasto = gasto;
	}
	
	
	
}
