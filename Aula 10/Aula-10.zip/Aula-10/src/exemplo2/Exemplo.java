package exemplo2;

public class Exemplo {

	public static void main(String[] args) {
		
		//Objetos classe MATEMATICA
		int s = Matematica.soma(2, 3);
		System.out.println(s);
		
		
		
		//OBJETOS CLASSE PESSOA
		Pessoa p1 = new Pessoa(33);
		Pessoa p2 = new Pessoa(44);
		
		//OBS: n�o usar variavel para static   
		System.out.println(Pessoa.contador);
		
		
		System.out.println(p1.getIdade());
		System.out.println(p2.getIdade());
		
		
	}

}
