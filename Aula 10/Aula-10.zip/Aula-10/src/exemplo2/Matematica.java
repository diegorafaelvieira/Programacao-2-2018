package exemplo2;

public class Matematica {

	//METODO STATIC
	public static int soma(int a, int b) {
		return(a+b);
	}
}
