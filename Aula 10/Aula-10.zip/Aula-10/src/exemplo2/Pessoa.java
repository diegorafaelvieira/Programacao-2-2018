package exemplo2;

public class Pessoa {

	//Atributos
	private int idade;
	
	//variaveis de classe static
	public static int contador = 0;

	
	
	//Construtor
	public Pessoa(int idade) {
		
		this.idade = idade;
		this.contador++;
	}

	//GET e SET
	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
	
	
	
}
