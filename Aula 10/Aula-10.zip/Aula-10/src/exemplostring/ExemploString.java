package exemplostring;

public class ExemploString {

	public static void main(String[] args) {
		
		
		String cidade = new String ("Feliz"); 
		String cidade2 = "Feliz";
		
		// comparando tanto faz MAISC ou minus
		if (cidade.equalsIgnoreCase(cidade2)) {  //equals teria que ser exatamente iguais
			System.out.println("Iguais");
		} 
 
		// verifica se a String cidade come�a com "Fe"   //retorna boolean
		if (cidade.startsWith("Fe")) {
			System.out.println("Inicial com Fe");
		}
		
		// verifica se a String cidade termina com "liz"  // retorna boolean
		if (cidade.endsWith("liz")) {
			System.out.println("Termina com liz");
		}
		
		// SPLIT - faz a separa��o
		String c = "IFRS-Campus-Feliz";    			//obs: espa�o em branco = " "
		String[] palavras = c.split("-");
		for (int i = 0; i < palavras.length; i++) {
			System.out.println(palavras[i]);
		}
		
		
		//SUBSTRING
		String teste = "Programacao em Java";
		System.out.println(teste.substring(0, 5)); // entra o 0 e o 5 n�o
		
		
		//
		String cidade3 = "IFRS-Campus-Feliz";
		System.out.println(cidade3);
		System.out.println(cidade3.toLowerCase()); // retorna a String em minusculo
		System.out.println(cidade3.toUpperCase()); // retorna a String em MAIUSCULO
		
		
		
		
		
		
		
		
		
		
	}

}
