package exemplostring;

public class ExemploStringFormat {

	public static void main(String[] args) {
		
		//slide p�g 15
		//format m�todo classe String que faz a formata��o
		//format String // s = String
								// %15s ->cada 1 � 1 coluna com 15 posi��es / espa�os para 15 caracteres // alinhamento a direita
		String t1 = String.format("%15s %15s %15s","Coluna 1","Coluna 2","Coluna 3");
		String t2 = String.format("%15s %15s %15s","Hello","World","Again");
		System.out.println(t1);
		System.out.println(t2);
								// %15s ->cada 1 � 1 coluna com 15 posi��es / espa�os para 15 caracteres // alinhamento a esquerda
		String t3 = String.format("%-15s %-15s %-15s","Coluna 1","Coluna 2","Coluna 3");
		String t4 = String.format("%-15s %-15s %-15s","Hello","World","Again");
		System.out.println(t3);
		System.out.println(t4);
		
		System.out.println();
		
		//format n�meros //f = ponto flutuante
		String t5 = String.format("%-15s %-15s","Coluna 1","Coluna 2");
		String t6 = String.format("%-15.3f %-15.8f", 666.23429837482,9.99);
		System.out.println(t5);
		System.out.println(t6);
	
	}

}
