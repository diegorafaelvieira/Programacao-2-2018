package exer01;

import java.util.Scanner;


public class TesteCarro {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Carro[] frota = new Carro[3];

		
		for (int i = 0; i < frota.length; i++) {
			
			System.out.print("Digite a marca do "+(i+1)+"� carro: ");
			String marca = scan.nextLine();
			
			System.out.print("Digite o modelo do "+(i+1)+"� carro: ");
			String modelo = scan.nextLine();
			
			System.out.print("Digite a placa do "+(i+1)+"� carro: ");
			String placa = scan.nextLine();
			//criando o objeto no array
			frota[i] = new Carro(marca, modelo, placa);
		}
		
		System.out.println();
		
		//impress�o ve�culos
		System.out.print("CARROS: ");
		for (int i = 0; i < frota.length; i++) {
			System.out.println("MARCA: "+ frota[i].getMarca() + " ");
			System.out.println("MODELO: "+ frota[i].getModelo() + " ");
			System.out.println("PLACA: "+ frota[i].getPlaca());
			
		}
		
		scan.close();

	}

}
