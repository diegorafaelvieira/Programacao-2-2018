package exer02;

import java.util.Random;

public class Exercicio2 {

	public static void main(String[] args) {
		
		// gera randomico
		Random r = new Random();
		
		Carta[][] c = new Carta[4][13];
		
		
		//String c = String.format("%15s %15s %15s %15","Coluna 1","Coluna 2","Coluna 3","Coluna 4");
		
		
		//Criando o baralho
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
			c[naipe][numero] = new Carta(naipe, numero);	
			}	
		}
		
		//impressao baralho
		System.out.println("ANTES");
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
				System.out.println(c[naipe][numero].getNaipe() + c[naipe][numero].getNumero());
				
			}
			
		}
		
		//embaralhar as cartas
		for (int emb = 0; emb < c.length; emb++) {
		
			int naipe1 = r.nextInt(4);
			int naipe2 = r.nextInt(4);
			int numero1 = r.nextInt(13);
			int numero2 = r.nextInt(13);
			
			Carta temp = c[naipe1][numero1];
			c[naipe2][numero2] = temp;
			
		}
		
		// imprimir o baralho ap�s embaralhar
		System.out.println();
		System.out.println("DEPOIS");
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
				System.out.println(c[naipe][numero].getNaipe() + " : " + c[naipe][numero].getNumero());
			}
		}
		
	}

}
