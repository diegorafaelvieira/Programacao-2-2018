package exer04;

public class Casa {

	//Atributos
	private String cor;
	private String rua;
	private int numero;
	
	
	//Construtor
	public Casa(String cor, int numero, String rua) {
		super();
		this.cor = cor;
		this.numero = numero;
		this.rua = rua;
		
	}
	
	
	
	//GET e SET
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	
	

	

	
	
}
