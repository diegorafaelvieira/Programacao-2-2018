package exer04;

import java.util.Scanner;


public class Exercicio4 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		Casa[] condominio = new Casa[3];

		int ponteiro = 0;


		while(true) {

			System.out.println("Digite C para cadastrar uma casa.");
			System.out.println("Digite L para mostrar as casas cadastradas");
			System.out.println("Digite S para sair.");
			System.out.println();
			System.out.print("OP��O: ");
			String op = scan.nextLine();


			if(op.equalsIgnoreCase("c")) {

				if(ponteiro == condominio.length) {
					System.out.println("O condom�nio j� foi preenchido!");
				} else if (condominio[ponteiro] == null) {

					//cadastro casa
					System.out.print("Cor da casa: ");
					String cor = scan.nextLine();
					System.out.print("N�mero da casa: ");
					int numero = scan.nextInt();
					scan.nextLine();
					System.out.print("Rua da casa: ");
					String rua = scan.nextLine();
					//objeto
					Casa casa = new Casa(cor, numero, rua);
					condominio[ponteiro] = casa;
					ponteiro++;
				}

			}

			else if(op.equalsIgnoreCase("l")) {
				//lista
				for (int i = 0; i < condominio.length; i++) {
					if (condominio[i] != null) {
						System.out.println("COR: "+condominio[i].getCor());
						System.out.println("N�MERO: "+condominio[i].getNumero());
						System.out.println("RUA: "+condominio[i].getRua());
						System.out.println();
					}
				}
			}

			else if (op.equalsIgnoreCase("s")) {
				System.out.println("SAINDO...");
				break;
			}
		}

		scan.close();
	}
}
