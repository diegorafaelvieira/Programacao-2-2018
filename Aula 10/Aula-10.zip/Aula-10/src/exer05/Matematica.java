package exer05;

public class Matematica {

		
	//METODO STATIC
	public static int soma(int a, int b) {
		return(a+b);
	}
	
	
	public static int subtracao(int a, int b) {
		int calculo = 0;
		
		if (a >= b) {
			
			calculo = a-b;
		} else {
	
			calculo = b-a;
		}
		
		return calculo;
	}
	
	public static double mediaAritmetica(double[] numeros) {
		
		double soma = 0;
		
		for (int i = 0; i < numeros.length; i++) {
			soma += numeros[i];
		}
		double media = soma / numeros.length;
		return media;
	}
	
	public static int progressaoAritmetica(int p, int r, int n) {
		
		int an = p + (n-1)*r;
		
		return an;
	}

}
