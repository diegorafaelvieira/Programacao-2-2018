package exer05;


public class TesteExercicio5 {

	public static void main(String[] args) {

		//Objetos classe MATEMATICA
		int som = Matematica.soma(2, 3);
		System.out.println("SOMA: "+som);
		
		System.out.println();
		
		int sub1 = Matematica.subtracao(5, 3);
		System.out.println("SUBTRA��O:" +sub1);

		System.out.println();
		
		int sub2 = Matematica.subtracao(5, 5);
		System.out.println("SUBTRA��O:" +sub2);
		
		System.out.println();
		
		int sub3 = Matematica.subtracao(3, 5);
		System.out.println("SUBTRA��O:" +sub3);
		
		System.out.println();
		
		
		double []numeros = {10,20,30};
		double med = Matematica.mediaAritmetica(numeros);
		System.out.println("M�DIA: "+med);
		
		System.out.println();
		
		//1� termo (a1) =  5
		// raz�o (r) = 2
		// quantidade de termos (n) na PA = 4
		int pa = Matematica.progressaoAritmetica(5, 2, 4);
		System.out.print("PROGRESS�O ARITM�TICA: "+pa);
	}

}
