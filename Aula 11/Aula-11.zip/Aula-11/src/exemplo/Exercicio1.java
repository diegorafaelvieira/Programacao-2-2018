package exemplo;

import java.util.Scanner;


public class Exercicio1 {

	public static void main(String[] args) {
		
		Cidade[] cidades = new Cidade[2];
		
		Scanner scan = new Scanner(System.in);
		
		for (int i = 0; i < cidades.length; i++) {
			
			//Prefeito
			System.out.print("Prefeito: ");
			String np = scan.nextLine();
			System.out.print("Partido: ");
			String pp = scan.nextLine();
			Prefeito p = new Prefeito(np, pp);
			
			//Estado
			System.out.print("Estado: ");
			String ne = scan.nextLine();
			System.out.print("Sigla: ");
			String se = scan.nextLine();
			Estado e = new Estado(ne, se);
			
			//Aqui inserir hospital
			System.out.print("Informe o n�mero de hospitais da cidade: ");
			int nroh = scan.nextInt();
								//ler o n�mero de int para String
			//OBJETO HOSPITAL
			Hospital[] hospitais = new Hospital[nroh];
			
			for (int j = 0; j < hospitais.length; j++) {
				//scan.nextLine();
				System.out.print("Hospital: ");
				String nh = scan.next();
				//scan.nextLine();
				System.out.print("Endere�o: ");
				String eh = scan.next();
				scan.nextLine();
				//criando o objeto no array
				hospitais[j] = new Hospital(nh, eh);
				
			}
			
			//Cidade
			System.out.print("Cidade: ");
			String nc = scan.nextLine();
			//cidades[i] = new Cidade(nc, np, ne, hospitais[j]);
			cidades[i] = new Cidade(nc, p, e, hospitais);
		}

		
		//imprimir  cidades
		System.out.println("IMPRESS�O");
		for (int i = 0; i < cidades.length; i++) {
			System.out.println("CIDADE: "+cidades[i].getNome() + " ");
			System.out.println("PREFEITO: "+cidades[i].getPrefeito().getNome() + " ");
			System.out.println("PARTIDO: "+cidades[i].getPrefeito().getPartido() + " ");
			System.out.println("ESTADO: "+cidades[i].getEstado().getNome() + " ");
			System.out.println("SIGLA: "+cidades[i].getEstado().getSigla() + " ");
			
			//imprimir hospitais
			for (int j = 0; j < cidades[i].getHospitais().length; j++) {
				System.out.println("HOSPITAL NOME: "+cidades[i].getHospitais()[j].getNome());
				System.out.println("HOSPITAL ENDERE�O: "+cidades[i].getHospitais()[j].getEndereco());
			}
			
			
			System.out.println();
		}
		
		scan.close();
	}

}
