package exemplo1;

public class Cliente extends Pessoa {

	//Atributos
	private String cpf;

	//GET e SET
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	
	
}
