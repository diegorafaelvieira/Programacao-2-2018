package exemplo1;

public class Exemplo {

	public static void main(String[] args) {
		
		//Objeto Cliente
		Cliente c = new Cliente();
		c.setNome("Mike"); ;
		c.setCpf("000.111.222-77");

		//Objeto Guitarra
		Guitarra g = new Guitarra();
		g.setPreco(500.50);
		g.setNumCordas(6); 
		g.imprimir();
		
	}

}
