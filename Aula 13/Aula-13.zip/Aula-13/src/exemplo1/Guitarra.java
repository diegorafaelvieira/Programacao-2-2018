package exemplo1;

public class Guitarra extends Instrumento {

	//Atributos
	private int numCordas;

	//GET e SET
	public int getNumCordas() {
		return numCordas;
	}


	public void setNumCordas(int numCordas) {
		this.numCordas = numCordas;
	}

	//METODO
	public void imprimir() {
		//classe que herda(INSTRUMENTO) tem que utilizar o GET
		System.out.println(this.getPreco());
		System.out.println(this.numCordas);
	}
}
