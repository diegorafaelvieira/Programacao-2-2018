package exemplo1;

public class Instrumento {

	//Atributos
	private double preco;

	//GET e SET
	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
}
