package exemplo1;

public class Pessoa {

	//Atributos
	private String nome;

	
	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}
