package exemplos2;

public class Conta {

	//atributos
	private String correntista;
	private double saldo;

	///+retirar(Quantia)
	public void retirar(double quantia) {
		this.saldo-=quantia;
	}

	//+depositar(Quantria)
	public void depositar(double quantia) {
		this.saldo+=quantia;
	}
	///obter saldo()==getSaldo()
	public double obterSaldo() {
		return saldo;
	}
}
