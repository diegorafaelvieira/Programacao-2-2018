package exemplos2;

public class ContaCorrente extends Conta{

	//atributos
	private double limite;

	public void cancelarLimite() {
		this.limite = 0;

	}
	public double getLimite() {
		return this.limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
}
