package exemplos2;

public class ContaPoupan�a extends Conta{

	//atributos
	private double taxaJuros;


	//+atualizarSaldo()
	public void atualizarSaldo() {
		double juros = this.obterSaldo()* this.taxaJuros;
		this.depositar(juros);
		
	}


	public double getTaxaJuros() {
		return taxaJuros;
	}


	public void setTaxaJuros(double taxaJuros) {
		this.taxaJuros = taxaJuros;
	}
}
