package exercicio1;

public class Caminhao extends Veiculo {
	
	//Atributos
	private String modelo;
	private double qtdLitrosTanque;
	
	//GET e SET
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public double getQtdLitrosTanque() {
		return qtdLitrosTanque;
	}
	public void setQtdLitrosTanque(double qtdLitrosTanque) {
		this.qtdLitrosTanque = qtdLitrosTanque;
	}
	
	public void informacoesCaminhao() {
		System.out.println("MODELO CAMINH�O: " + this.modelo);
		System.out.println("QUANTIDADE LITROS TANQUE: " + this.qtdLitrosTanque);
	}
}
