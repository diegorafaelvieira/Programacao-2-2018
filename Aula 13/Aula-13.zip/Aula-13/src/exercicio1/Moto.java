package exercicio1;

public class Moto extends Veiculo {

	//Atributos
	private String cor;
	private int numPassageiros;
	
	//GET e SET
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getNumPassageiros() {
		return numPassageiros;
	}
	public void setNumPassageiros(int numPassageiros) {
		this.numPassageiros = numPassageiros;
	}
	
	//Metodos
	public void informacoesMoto() {
		System.out.println("COR MOTO: " + this.cor);
		System.out.println("N�MERO PASSAGEIROS: " + this.numPassageiros);
	}
}
