package exercicio1;

public class TesteExercicio1 {

	public static void main(String[] args) {
		
		Moto m1 = new Moto();
		m1.setPlaca("IHJ-1234");
		m1.setKm(100.001);
		m1.setCor("Verde");
		m1.setNumPassageiros(2);
		m1.informacoesVeiculo();
		m1.informacoesMoto();
		
		System.out.println();
		
		
		Caminhao cm1 = new Caminhao();
		cm1.setPlaca("IJH-4321");
		cm1.setKm(225075);
		cm1.setModelo("1113");
		cm1.setQtdLitrosTanque(200);
		cm1.informacoesVeiculo();
		cm1.informacoesCaminhao();

	}

}
