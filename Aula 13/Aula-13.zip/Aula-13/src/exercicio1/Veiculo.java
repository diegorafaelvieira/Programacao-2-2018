package exercicio1;

public class Veiculo {

	//Atributos
	private String placa;
	private double km;
	
	//GET e SET
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public double getKm() {
		return km;
	}
	public void setKm(double km) {
		this.km = km;
	}
	
	//Metodo
	public void informacoesVeiculo() {
		System.out.println("PLACA: " + this.placa);
		System.out.println("KM: " + this.km);
	}
	
}
