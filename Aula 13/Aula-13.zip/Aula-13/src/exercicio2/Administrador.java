package exercicio2;

public class Administrador extends Empregado{

	//Atributos
	private double ajudaDeCusto;

	//GET e SET
	public double getAjudaDeCusto() {
		return ajudaDeCusto;
	}

	public void setAjudaDeCusto(double ajudaDeCusto) {
		this.ajudaDeCusto = ajudaDeCusto;
	}
	
	//Metodo
	public void informacoesAdministrador() {
		System.out.println("NOME EMPREGADO: " + this.getNome());
		System.out.println("EMAIL: " + this.getEmail());
		System.out.println("TELEFONE: " + this.getTelefone());
		System.out.println("C�DIGO SETOR: " + this.getCodSetor());
		System.out.println("SALARIO BASE R$ " + this.getSalarioBase());
		System.out.println("PORCENTAGEM DE DESCONTO DO IMPOSTO:" + this.getImposto() + " %");
		System.out.println("AJUDA DE CUSTO R$ "+this.ajudaDeCusto);
		System.out.println("SALARIO LIQUIDO R$ " + this.calcularSalario());
		System.out.println("SALARIO FINAL R$ " + salarioFinalAdministrador(calcularSalario(), ajudaDeCusto));
	}
	
	public double salarioFinalAdministrador(double salLiquido, double ajudaDeCusto) {
		
		return calcularSalario() + ajudaDeCusto;
	}
}
