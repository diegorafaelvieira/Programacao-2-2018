package exercicio2;



public class Empregado extends Pessoa {

	//Atributos
	private int codSetor;
	private double salarioBase;
	private double imposto;
	
	//GET e SET
	public int getCodSetor() {
		return codSetor;
	}
	public void setCodSetor(int codSetor) {
		this.codSetor = codSetor;
	}
	public double getSalarioBase() {
		return salarioBase;
	}
	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}
	public double getImposto() {
		return imposto;
	}
	public void setImposto(double imposto) {
		this.imposto = imposto;
	}
	
	//METODO
	public double calcularSalario() {
		
		return salarioBase - (imposto * (salarioBase/100)) ;
		
	}
	
	public void informacoesFuncionario() {
		System.out.println("NOME EMPREGADO: " + this.getNome());
		System.out.println("EMAIL: " + this.getEmail());
		System.out.println("TELEFONE: " + this.getTelefone());
		System.out.println("C�DIGO SETOR: " + this.codSetor);
		System.out.println("SALARIO BASE R$ " + this.salarioBase);
		System.out.println("PORCENTAGEM DE DESCONTO DO IMPOSTO:" + this.imposto);
		System.out.println("SALARIO LIQUIDO R$ " + calcularSalario());
	}
}
