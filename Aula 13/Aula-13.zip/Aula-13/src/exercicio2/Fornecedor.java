package exercicio2;

public class Fornecedor extends Pessoa {

	//Atributos
	private double valorCredito;
	private double valorDivida;
	
	//GET e SET
	public double getValorCredito() {
		return valorCredito;
	}
	public void setValorCredito(double valorCredito) {
		this.valorCredito = valorCredito;
	}
	public double getValorDivida() {
		return valorDivida;
	}
	public void setValorDivida(double valorDivida) {
		this.valorDivida = valorDivida;
	}
	
	//METODO
	public double obterSaldo(double valorCredito, double valorDivida) {
		return valorCredito - valorDivida;
		
	}
	
	public void imprimirFornecedor() {
		System.out.println("NOME EMPRESA: " + this.getNome());
		System.out.println("EMAIL: " + this.getEmail());
		System.out.println("TELEFONE: " + this.getTelefone());
		System.out.println("VALOR CREDITO R$ " + this.getValorCredito());
		System.out.println("VALOR DIVIDA R$ " + this.getValorDivida());
		System.out.println("SALDO ATUAl R$ "+this.obterSaldo(valorCredito, valorDivida));
	}
}
