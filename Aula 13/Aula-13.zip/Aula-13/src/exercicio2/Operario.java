package exercicio2;

public class Operario extends Empregado {

	//Atributos
	private double valorProducao;
	private double comissao;

	//GET e SET
	public double getValorProducao() {
		return valorProducao;
	}
	public void setValorProducao(double valorProducao) {
		this.valorProducao = valorProducao;
	}
	public double getComissao() {
		return comissao;
	}
	public void setComissao(double comissao) {
		this.comissao = comissao;
	}


	//Metodo
	public void informacoesOperador() {
		System.out.println("NOME EMPREGADO: " + this.getNome());
		System.out.println("EMAIL: " + this.getEmail());
		System.out.println("TELEFONE: " + this.getTelefone());
		System.out.println("C�DIGO SETOR: " + this.getCodSetor());
		System.out.println("SALARIO BASE R$ " + this.getSalarioBase());
		System.out.println("PORCENTAGEM DE DESCONTO DO IMPOSTO:" + this.getImposto());
		System.out.println("VALOR PRODU��O R$ " + this.valorProducao);
		System.out.println("VALOR COMISS�O " + this.comissao + " %");
		System.out.println("SALARIO LIQUIDO R$ " + this.calcularSalario());
		System.out.println("SALARIO FINAL R$ " + salarioFinalOperador(calcularSalario(), valorProducao, comissao));
	}
	
	public double salarioFinalOperador(double salLiquido, double valorProducao , double comissao) {
		
		return calcularSalario() + (comissao * (valorProducao / 100));
	}
}
