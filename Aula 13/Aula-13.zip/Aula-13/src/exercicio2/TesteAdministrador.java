package exercicio2;

public class TesteAdministrador {

	public static void main(String[] args) {
	
		Administrador adm = new Administrador();
		adm.setNome("Nome Administrador");
		adm.setEmail("admistrador@gmail.com");
		adm.setTelefone("3635-0000");
		adm.setSalarioBase(2000);
		adm.setImposto(10);
		adm.setCodSetor(11);
		adm.setAjudaDeCusto(500);
		adm.informacoesAdministrador();
		

	}

}
