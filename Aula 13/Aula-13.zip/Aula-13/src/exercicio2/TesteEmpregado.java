package exercicio2;

public class TesteEmpregado {

	public static void main(String[] args) {
		
		
		//OBJETO EMPREGADO
		Empregado emp = new Empregado();
		emp.setNome("Nome Empregado");
		emp.setEmail("empregado@gmail.com");
		emp.setTelefone("3635-1111");
		emp.setCodSetor(22);
		emp.setSalarioBase(1000);
		emp.setImposto(10);
		emp.informacoesFuncionario();
	}

}
