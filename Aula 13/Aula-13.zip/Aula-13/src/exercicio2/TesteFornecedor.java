package exercicio2;



public class TesteFornecedor {

	public static void main(String[] args) {
		

		Fornecedor f = new Fornecedor();
		f.setNome("Tabajara");
		f.setEmail("tabajara@tabajara.com.br");
		f.setTelefone("9999-8888");
		f.setValorCredito(10000.50);
		f.setValorDivida(5000);
		f.imprimirFornecedor();
		
	}

}
