package exercicio2;

public class TesteOperario {

	public static void main(String[] args) {
		
		Operario op = new Operario();
		op.setNome("Nome Operador");
		op.setEmail("operador@gmail.com");
		op.setTelefone("9999-9999");
		op.setSalarioBase(1100);
		op.setImposto(10);
		op.setCodSetor(13);
		op.setValorProducao(50);
		op.setComissao(10);
		op.informacoesOperador();


	}

}
