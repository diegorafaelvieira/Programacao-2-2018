package exercicio2;

public class TesteVendedor {

	public static void main(String[] args) {
		
		Vendedor v = new Vendedor();
		v.setNome("nome Vendedor");
		v.setEmail("vendedor@gmail.com");
		v.setTelefone("8888-8888");
		v.setSalarioBase(1500);
		v.setImposto(10);
		v.setCodSetor(12);
		v.setValorVendas(10000);
		v.setComissao(10);
		v.informacoesVendedor();
		

	}

}
