package exercicio2;

public class Vendedor extends Empregado {

	//Atributos
	private double valorVendas;
	private double comissao;

	//GET e SET
	public double getValorVendas() {
		return valorVendas;
	}
	public void setValorVendas(double valorVendas) {
		this.valorVendas = valorVendas;
	}
	public double getComissao() {
		return comissao;
	}
	public void setComissao(double comissao) {
		this.comissao = comissao;
	}

	//Metodo
	public void informacoesVendedor() {
		System.out.println("NOME EMPREGADO: " + this.getNome());
		System.out.println("EMAIL: " + this.getEmail());
		System.out.println("TELEFONE: " + this.getTelefone());
		System.out.println("C�DIGO SETOR: " + this.getCodSetor());
		System.out.println("SALARIO BASE R$ " + this.getSalarioBase());
		System.out.println("PORCENTAGEM DE DESCONTO DO IMPOSTO:" + this.getImposto());
		System.out.println("VALOR PRODU��O R$ " + this.valorVendas);
		System.out.println(" % COMISS�O " + this.comissao);
		System.out.println("SALARIO LIQUIDO R$ " + this.calcularSalario());
		System.out.println("VALOR COMISS�O R$ " + calculaComissaoVendas(getValorVendas(), getComissao()));
		
	}
	
	public double calculaComissaoVendas(double valorVendas, double comissao) {
		
		return comissao * (valorVendas / 100);
	}
}
