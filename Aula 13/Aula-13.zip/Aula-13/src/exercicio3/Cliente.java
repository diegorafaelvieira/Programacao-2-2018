package exercicio3;



public class Cliente {

	//atributos
	private String pais;
	private String dataCadastro;
	
	
	//GET e SET
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getDataCadastro() {
		return dataCadastro;
	}
	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	

	
	
	
}
