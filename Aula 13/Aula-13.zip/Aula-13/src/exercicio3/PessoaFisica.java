package exercicio3;

public class PessoaFisica  extends Cliente{

	//atributos
	private String nome;
	private String sobreNome;
	private String cpf;
	
	//GET e SET
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobreNome() {
		return sobreNome;
	}
	public void setSobreNome(String sobreNome) {
		this.sobreNome = sobreNome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	//Metodo
	public void informacoesPessoaFisica() {
		System.out.println("PA�S: " + getPais());
		System.out.println("DATA CADASTRO: " + getDataCadastro());
		System.out.println("NOME: " + this.nome);
		System.out.println("SOBRENOME: " + this.sobreNome);
		System.out.println("CPF: " + this.cpf);
	}
}
