package exercicio3;

public class PessoaJuridica extends Cliente {

	//atributos
	private String razaoSocial;
	private String nomeFantasia;
	private String sigla;
	private String cnpj;

	//GET e SET
	public String getRazaoSocial() {
		return razaoSocial;
	}
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	//Metodo
	public void informacoesPessoaJuridica() {
		System.out.println("PA�S: " + getPais());
		System.out.println("DATA CADASTRO: " + getDataCadastro());
		System.out.println("RAZAO SOCIAL: " + this.razaoSocial);
		System.out.println("NOME FANTASIA: " + this.nomeFantasia);
		System.out.println("SIGLA: " + this.sigla);
		System.out.println("CNPJ: " + this.cnpj);
	}

}
