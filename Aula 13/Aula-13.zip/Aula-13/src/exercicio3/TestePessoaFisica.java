package exercicio3;



public class TestePessoaFisica {

	public static void main(String[] args) {


		PessoaFisica pf = new PessoaFisica();
		pf.setPais("Brasil");
		pf.setDataCadastro("10-09-2018");
		pf.setNome("Diego");
		pf.setSobreNome("Vieira");
		pf.setCpf("009-0170-050-47");
		pf.informacoesPessoaFisica();

	}

}
