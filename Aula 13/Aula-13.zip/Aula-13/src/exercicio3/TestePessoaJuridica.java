package exercicio3;

public class TestePessoaJuridica {

	public static void main(String[] args) {
		
		PessoaJuridica pj = new PessoaJuridica();
		pj.setPais("Brasil");
		pj.setDataCadastro("11-09-2018");
		pj.setRazaoSocial("Organiza��es Tabajara LTDA");
		pj.setNomeFantasia("TABAJARA SA");
		pj.setSigla("OT");
		pj.setCnpj("78.425.986/0036-15");
		pj.informacoesPessoaJuridica();

	}

}
