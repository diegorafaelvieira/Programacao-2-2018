package exercicio4;

public class TesteCachorro {

	public static void main(String[] args) {
		
		cachorro cao = new cachorro();
		cao.setNome("Bob");
		cao.setAmbiente("terra");
		cao.setSexo("Macho");
		cao.setAlimento("Ra��o");
		cao.setNroPatas(4);
		cao.setRaca("Vira-lata");
		cao.setTamanho("M�dio");
		cao.dadosMamifero();
		cao.dadosCachorro();

	}

}
