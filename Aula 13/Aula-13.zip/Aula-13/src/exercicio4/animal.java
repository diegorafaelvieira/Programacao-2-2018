package exercicio4;

public class animal {

	//atributos
	private String nome;
	private String sexo;
	private int nroPatas;
	private String ambiente;
	
	//GET e SET
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public int getNroPatas() {
		return nroPatas;
	}
	public void setNroPatas(int nroPatas) {
		this.nroPatas = nroPatas;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}
