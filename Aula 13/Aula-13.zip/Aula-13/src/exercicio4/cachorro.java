package exercicio4;

public class cachorro extends mamifero{

	//atributos
	private String tamanho;
	private String raca;

	
	//GET e SET
	public String getTamanho() {
		return tamanho;
	}
	public void setTamanho(String tamanho) {
		this.tamanho = tamanho;
	}
	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	

	
	//Metodo
	public void dadosCachorro() {
		System.out.println("TAMANHO: " + this.tamanho);
		System.out.println("RA�A: " + this.raca);

	}

}
