package exercicio4;

public class mamifero extends animal {

	//atributos
	private String alimento;

	//GET e SET
	public String getAlimento() {
		return alimento;
	}

	public void setAlimento(String alimento) {
		this.alimento = alimento;
	}
	
	//METODO
	public void dadosMamifero() {
		System.out.println("NOME: " + getNome());
		System.out.println("SEXO: " + getSexo());
		System.out.println("QUANTIDADE DE PATAS: " + getNroPatas());
		System.out.println("AMBIENTE: " + getAmbiente());
		System.out.println("ALIMENTO: " + this.alimento);
	}
	
}
