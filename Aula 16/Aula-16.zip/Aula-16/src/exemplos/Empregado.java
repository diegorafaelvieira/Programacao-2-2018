package exemplos;

public class Empregado  extends Pessoa {

	
	//atributos
	private String empresa;
	
	
	public Empregado(String nome, String empresa) {
		super(nome);
		this.empresa = empresa;
		
	}

	//GET e SET
	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

		
}
