package exemplos;

public class Instrumento extends Produto {

	//atributos
	private String marca;

	//construtor
	public Instrumento(int codigo, double preco, String marca) {
		super(codigo, preco);
		this.marca = marca;
		System.out.println("Construtor Instrumento");
	}

	//GET e SET
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir();
		System.out.println("MARCA: " + this.marca);
	}
	
	
	
}
