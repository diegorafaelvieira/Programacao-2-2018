package exemplos;

public class Livro extends Produto {

	//atributos
	private String titulo;
	
	//construtor
	public Livro(int codigo, double preco, String titulo) {
		super(codigo,preco); //chama construtor do Produto
		this.titulo = titulo;
		System.out.println("Construtor Livro");
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir(); //aqui subescreve o m�todo imprimir
		System.out.println("TITULO: "+this.titulo);
	}
	//GET e SET
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
	
}
