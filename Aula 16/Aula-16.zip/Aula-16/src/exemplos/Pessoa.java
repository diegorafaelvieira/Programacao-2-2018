package exemplos;

public class Pessoa {

	//atributos
	private String nome;

	//contrutor
	public Pessoa(String nome) {
		super();
		this.nome = nome;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
	
}
