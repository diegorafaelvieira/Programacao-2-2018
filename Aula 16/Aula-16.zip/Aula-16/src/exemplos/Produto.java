package exemplos;

public class Produto {

	//atributos
	private int codigo;
	private double preco;
	
	//construtor
	public Produto(int codigo, double preco) {
		super();
		this.codigo = codigo;
		this.setPreco(preco);
		System.out.println("Construtor Produto");
	}
	
	//Metodo
	public void imprimir() {
		System.out.println("CODIGO: "+this.codigo);
		System.out.println("PRE�O: "+this.preco);
	}

	//GET e SET
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
	
	
}
