package exemplos;

public class Programador extends Empregado {


	//atributos
	private String linguagem;
	
	public Programador(String nome,String empresa ,String linguagem) {
		super(nome, empresa);
		this.linguagem = linguagem;
	}	

	public String getLinguagem() {
		return linguagem;
	}

	public void setLinguagem(String linguagem) {
		this.linguagem = linguagem;
	}
	
	
}
