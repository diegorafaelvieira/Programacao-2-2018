package exemplos;

public class Teste2 {

	public static void main(String[] args) {
		
		//array
		Produto[] produtos = new Produto[2];
		
		produtos[0] = new Livro(123, 100, "Java Doido");
		produtos[1] = new Instrumento(12, 150.50, "Gibson");
		
		produtos[0].imprimir();
		produtos[1].imprimir();

	}

}
