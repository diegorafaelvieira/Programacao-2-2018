package exemplos;

public class TesteLivro {

	public static void main(String[] args) {
		
		//Objeto
		Livro l1 = new Livro(01, 99.90, "Titulo do Livro");
		
		l1.imprimir();
	
		
		Instrumento i1 = new Instrumento(2, 250.99, "FENDER");
	}
}
