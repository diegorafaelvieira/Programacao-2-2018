package exer01;

public class Componente {

	//atributos
	private String fabricante;
	private String modelo;
	
	//Construtor
	public Componente(String fabricante, String modelo) {
		super();
		this.fabricante = fabricante;
		this.modelo = modelo;
	}

	//GET e SET
	public String getFabricante() {
		return fabricante;
	}

	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}

	public String getModelo() {
		return modelo;
	}
	

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	//Metodo
	public void imprimir() {
		System.out.println("FABRICANTE: " + this.fabricante);
		System.out.println("MODELO: " + this.modelo);
	}
	
}
