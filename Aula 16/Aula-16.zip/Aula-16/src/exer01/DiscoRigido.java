package exer01;

public class DiscoRigido extends Componente {


	//atributo
	private int capacidade;

	public DiscoRigido(String fabricante, String modelo, int capacidade) {
		super(fabricante, modelo);
		this.capacidade = capacidade;
	}

	//GET e SET
	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir();
		System.out.println("CAPACIDADE: " + this.capacidade);
	}
	
}
