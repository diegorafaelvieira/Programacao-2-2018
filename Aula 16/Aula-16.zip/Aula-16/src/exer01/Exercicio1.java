package exer01;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//Monitor
		System.out.print("Informe a resolu��o do monitor: ");
		String resolucaoMonitor = scan.nextLine();
		System.out.print("Informe o fabricante do monitor: ");
		String fabricanteMonitor = scan.nextLine();
		System.out.print("Informe o modelo do monitor: ");
		String modeloMonitor = scan.nextLine();
		
		
		System.out.println();
		
		//Disco Rigido
		System.out.print("Informe a capacidade do disco rigido: ");
		int capacidadeDiscoRigido = scan.nextInt();
		scan.nextLine();
		System.out.print("Informe o fabricante do Disco Rigido: ");
		String fabricanteDiscoRigido = scan.nextLine();
		System.out.print("Informe o modelo do Disco Rigido: ");
		String modeloDiscoRigido = scan.nextLine();
		
		System.out.println();
		
		//Objeto Monitor
		Monitor mon1 = new Monitor(fabricanteMonitor, modeloMonitor, resolucaoMonitor);
		mon1.imprimir();
		
		System.out.println();
		
		//Objeto Disco Rigido
		DiscoRigido dr1 = new DiscoRigido(fabricanteDiscoRigido, modeloDiscoRigido, capacidadeDiscoRigido);
		dr1.imprimir();
		
		
		scan.close();

	}

}
