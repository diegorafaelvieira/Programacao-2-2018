package exer01;

public class Monitor extends Componente {

	//atributos
	private String resolucao;

	//construtor
	public Monitor(String fabricante, String modelo, String resolucao) {
		super(fabricante, modelo);
		this.setResolucao(resolucao);
	}

	//GET e SET
	public String getResolucao() {
		return resolucao;
	}

	public void setResolucao(String resolucao) {
		this.resolucao = resolucao;
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir();
		System.out.println("RESOLU��O: " + this.resolucao);
	}
	
	
	
}
