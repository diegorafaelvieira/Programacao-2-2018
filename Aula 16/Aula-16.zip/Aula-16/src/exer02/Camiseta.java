package exer02;

public class Camiseta extends Produto {

	//atributos
	private String cor;

	//contrutor
	public Camiseta(String nome, double valor, String cor) {
		super(nome, valor);
		this.setCor(cor);
	}

	//GET e SET
	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir();
		System.out.println("COR: " + this.cor);
	}
	
	
	
	
}
