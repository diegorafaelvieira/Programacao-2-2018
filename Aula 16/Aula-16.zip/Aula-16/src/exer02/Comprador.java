package exer02;

public class Comprador {


	//Metodo
	public void consultar(Produto p) {   //se retornar algo usaria o Produto no lugar de void
		
		p.imprimir();
		
	}
}
