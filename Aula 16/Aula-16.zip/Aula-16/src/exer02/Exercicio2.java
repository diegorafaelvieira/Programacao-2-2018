package exer02;


import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		//Camiseta
		System.out.print("Informe o nome do produto: ");
		String nomeProdutoCamiseta = scan.nextLine();
		System.out.print("Informe o valor da camiseta: ");
		double valorCamiseta = scan.nextDouble();
		scan.nextLine();
		System.out.print("Informe a cor da camiseta: ");
		String corCamiseta = scan.nextLine();
		
		System.out.println();
		
		//Sapato
		System.out.print("Informe o nome do produto: ");
		String nomeProdutoSapato = scan.nextLine();
		System.out.print("Informe o valor do sapato: ");
		double valorSapato = scan.nextDouble();
		System.out.print("Informe o tamanho do sapato: ");
		int tamanhoSapato = scan.nextInt();
		
		//Objeto Camiseta
		Camiseta c1 = new Camiseta(nomeProdutoCamiseta, valorCamiseta, corCamiseta);
		
		//Objeto Sapato
		Sapato s1 = new Sapato(nomeProdutoSapato, valorSapato, tamanhoSapato);
		
		
		
		//Objeto Comprador 
		Comprador comprador1 = new Comprador();	
		
		//Comprador realizando a consulta 
		comprador1.consultar(c1);
		//c1.imprimir();
		comprador1.consultar(s1);
		//s1.imprimir();
		
		
		scan.close();

	}

}
