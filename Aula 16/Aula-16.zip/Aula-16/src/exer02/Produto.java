package exer02;


public class Produto {

	//atributos
	private String nome;
	private double valor;
	
	//Construtor
	public Produto(String nome, double valor) {
		this.nome = nome;
		this.valor = valor;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	//Metodo
	public void imprimir() {
		System.out.println("NOME: " + this.nome);
		System.out.println("VALOR: " + this.valor);
	}
	
	
	
}
