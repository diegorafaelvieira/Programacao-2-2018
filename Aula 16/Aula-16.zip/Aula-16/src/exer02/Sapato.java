package exer02;

public class Sapato extends Produto{

	//atributo
	private int tamanho;

	//Construtor
	public Sapato(String nome, double valor, int tamanho) {
		super(nome, valor);
		this.setTamanho(tamanho);
	}

	//GET e SET
	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	//Metodo
	public void imprimir() {
		super.imprimir();
		System.out.println("TAMANHO: " + this.tamanho);
	}
	
	
}
