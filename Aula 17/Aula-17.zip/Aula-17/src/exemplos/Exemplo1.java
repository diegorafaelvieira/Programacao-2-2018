package exemplos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exemplo1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Digite um n�mero: ");
		
		int n = 0;
		try {
		n = scan.nextInt();
		System.out.println(n);  //n�o precisa estar aqui SOUT
		
		} catch(InputMismatchException e) {   //erro letra
			System.out.println("Erro");
		}
		
		int[] numeros = {100,200};
		try {
		System.out.println(numeros[n]);
		} catch (ArrayIndexOutOfBoundsException e) { //AQUI EXERCICIO ERRO ARRAY
			System.err.println("Indice fora do limite ");  //estouro do array  //err imprime em vermelho a msg do erro
			//e.printStackTrace();  //mostra msg do erro 
			
		}
		
		scan.close();

	}

}
