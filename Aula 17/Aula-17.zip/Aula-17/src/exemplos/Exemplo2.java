package exemplos;

public class Exemplo2 {

	public static void main(String[] args) {

		System.out.println("Inicio Main");
		try {
			calculo1();
		} catch (Exception e) {
			System.out.println("Opa..");
			e.printStackTrace();
		}
		System.out.println("Fim Main");

	}
	
	public static void calculo1() {
		System.out.println("Inicio Calculo1");
		calculo2();
		System.out.println("Fim Calculo1");
	}
   

	public static void calculo2() {
		System.out.println("Inicio Calculo2");
		String palavra = "teste ";
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println(palavra.toUpperCase());
			} catch (Exception e) {
				System.out.println("ERRO");
				//e.printStackTrace();
			}
			if (i == 2) {
				palavra = null;
			}
		}
		System.out.println("Fim Calculo2");
	}
}
