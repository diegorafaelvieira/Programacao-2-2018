package exemplos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MoserExemplo1 {

	public static void main(String[] args) {


		Scanner leitor = new Scanner(System.in);

		System.out.print("Numero: ");

		int n = 0;
		try {
			n = leitor.nextInt();
			System.out.println(n);
		} catch(InputMismatchException e) {
			System.out.println("Erro");
		}

		int[] numeros = {100,200};
		try {
			System.out.println(numeros[n]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Indice fora do limite.");
			e.printStackTrace();
		}




		System.out.println("Programa segue..");

		leitor.close();
	}
}
