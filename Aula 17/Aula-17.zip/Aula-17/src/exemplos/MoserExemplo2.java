package exemplos;

public class MoserExemplo2 {

	public static void main(String[] args) {
		
		System.out.println("Inicio Main");
		calculo1();
		System.out.println("Fim Main");
	}
	
	public static void calculo1() {
		System.out.println("Inicio calculo1");
		calculo2();
		System.out.println("Fim calculo1");
	}
	
	public static void calculo2() {
		System.out.println("Inicio calculo2");
		String palavra = "teste ";
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println(palavra.toUpperCase());
			} catch (Exception e) {
				System.out.println("Opa");
				//e.printStackTrace();
			}
			if(i == 2) {
				palavra = null;
			}
		}
		System.out.println("Fim calculo2");

	}

}
