package exemploprotected;

public class Carro extends Veiculo{

	public void teste() {
		System.out.println(this.placa);
	}
}
