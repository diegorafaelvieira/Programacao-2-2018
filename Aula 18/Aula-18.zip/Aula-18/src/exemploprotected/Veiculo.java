package exemploprotected;

public class Veiculo {

	//atributo
	protected String placa;
}
