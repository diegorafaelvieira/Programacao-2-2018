package exemplos;

public class Carro {
	private String modelo;
	
	public Carro(String modelo) {
		this.modelo = modelo;
	}
	
	public String getCarroUpcase() throws RuntimeException {
		return this.modelo.toUpperCase();
	}
	
}