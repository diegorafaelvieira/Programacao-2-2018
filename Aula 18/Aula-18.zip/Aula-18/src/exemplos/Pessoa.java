package exemplos;

public class Pessoa {
	private int idade;
	
	public Pessoa(int idade) {
		super();
		this.idade = idade;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) throws Exception {
		if(idade >=0) {
			this.idade = idade;
		} else {
			throw new Exception("Erro.");
		}
	}
	
	
}
