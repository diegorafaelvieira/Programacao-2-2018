package exemplos;

public class TesteCarro {

	public static void main(String[] args) {

		Carro c = new Carro(null);

		String m;
		try {
			m = c.getCarroUpcase();
			System.out.println(m);
		} catch (RuntimeException e) {   //antes tava sem Runtime
			System.out.println("Erro 1.");
		}
		
		// A linha abaixo apresenta um erro devido
		// a falta de tratamento com try / catch
		//String m2 = c.getCarroUpcase();
		//System.out.println(m2);
		
		
		
	}

}
