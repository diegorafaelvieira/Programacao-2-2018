package exemplos;

public class TestePessoa {

	public static void main(String[] args) {
		
		Pessoa p = new Pessoa(0);
		try {
			p.setIdade(-10);
		} catch (Exception e) {
			
			e.printStackTrace();
			//System.out.println(e.getMessage()); // � usado  
			 
		}
		

	}

}
