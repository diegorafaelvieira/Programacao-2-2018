package exemplosabstracao;

public abstract class Animal {   //classe abstrata

	//atributos
	protected String nome;  

	
	
	//construtor
	public Animal(String nome) {
		super();
		this.nome = nome;
	}


	//GET e SET
	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	//metodo
	abstract public void alimentar(); // n�o tem corpo //todos os que herdam tem que implementar da sua maneira
	
}
