package exemplosabstracao;

public class Cavalo extends Animal {

	//atributos
	private String cor;
	
	//Construtor
	public Cavalo(String nome, String cor) {
		super(nome);
		this.setCor(cor);
		
	}

	//GET e SET
	public String getCor() {
		return cor;
	}


	public void setCor(String cor) {
		this.cor = cor;
	}

	@Override   //primeira op��o quando clico sobre o nome da classe
	public void alimentar() {
		System.out.println("Pastando...");
		
	}

	
	
	
}
