package exemplosabstracao;

public class Exemplo {

	public static void main(String[] args) {
		
		//Animal a = new Animal("Cavalo"); n�o da pra usar assim
		//Cavalo c = new Cavalo("P� de pano ", "Branco");  //s� da pela subclasse
		
		
		Animal[] zoo = new Animal[2];
		zoo[0] = new Cavalo("P� de pano ", "Branco"); //todo cavalo � um animal
		zoo[1] = new Lobo("Wolf"); //todo lobo � um animal
		for (int i = 0; i < zoo.length; i++) {
			zoo[i].alimentar();
		}
		
		
		((Lobo) zoo[1]).uivar();  // s� assim para o Lobo "uivar"
		//((Cavalo) zoo[1]).alimentar(); //esse da erro
		
		//ex1 estrutural
		//ex2 estrutural com arrays
	}

}
