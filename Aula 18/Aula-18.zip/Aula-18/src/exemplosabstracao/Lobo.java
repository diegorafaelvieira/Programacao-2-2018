package exemplosabstracao;

public class Lobo extends Animal {

	//atributos
	
	
	
	//construtor
	public Lobo(String nome) {
		super(nome);
		
	}

	//metodo
	public void uivar() {
		System.out.println("Uuuuu");
	}
	
	@Override
	public void alimentar() {
		System.out.println("Comendo carne...");
		
	}

	
	
}
