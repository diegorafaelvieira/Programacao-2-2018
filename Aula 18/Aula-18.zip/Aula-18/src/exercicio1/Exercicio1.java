package exercicio1;

import java.util.InputMismatchException;
import java.util.Scanner;



public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		
		int opc = 0;
		
		do {
			System.out.println("MENU");
			System.out.println("[1] - Calcular C�rculo");
			System.out.println("[2] - Calcular Quadrado");
			System.out.println("[3] - SAIR");
			System.out.print("OP��O: ");
			try {
				opc = scan.nextInt();
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.err.print("ERRO NO MENU! DIGITE APENAS N�MEROS: ");
				opc = scan.nextInt();
				//e.printStackTrace();
			}
			
			System.out.println();
			
			switch (opc) {
			case 1:
				System.out.print("Nome c�rculo: ");
				String nomeCirculo  = scan.next();
				System.out.print("Digite o raio: ");
				double raio = 0;
				try {
					raio = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine(); // Descarta quebra de linha
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					raio = scan.nextDouble();
					//e.printStackTrace();
				}
				//objeto
				FiguraGeometrica c = new Circulo(nomeCirculo, raio); 
				System.out.println("NOME: " + c.getNome());
				System.out.println("�REA CIRCULO: "+c.calculaArea());
				System.out.println("PER�METRO CIRCULO: "+c.calculaPerimetro());
				System.out.println();
				break;
				
			case 2:
				System.out.print("Nome do ret�ngulo: ");
				String nomeRet = scan.next();
				System.out.print("Digite o lado1: ");
				double lado1 = 0;
				try {
					lado1 = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					lado1 = scan.nextDouble();
					//e.printStackTrace();
				}
				System.out.print("Digite o lado2: ");
				double lado2;
				try {
					lado2 = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					lado2 = scan.nextDouble();
					//e.printStackTrace();
				}
				//objeto
				FiguraGeometrica r = new Retangulo(nomeRet, lado1, lado2);
				System.out.println("NOME: " + r.getNome());
				System.out.println("�REA RET�NGULO: "+r.calculaArea());
				System.out.println("PER�METRO RET�NGULO: " +r.calculaPerimetro());
				System.out.println();
				break;
				
			case 3:
				System.out.println("SAINDO...");
				break;

			default:
				System.out.println("OP��O INV�LIDA!");
				break;
			}
		
		} while (opc != 3);
		
		

		
		scan.close();

	}

}
