package exercicio2;

public class Circulo extends FiguraGeometrica{

	//atributos
	private double raio;

	//construtor
	public Circulo(String nome, double raio) {
		super(nome);
		this.raio = raio;
	}

	//GET e SET
	public double getRaio() {
		return raio;
	}

	
	public void setRaio(double raio) {
		this.raio = raio;
	}

	@Override
	public double calculaPerimetro() {
		// TODO Auto-generated method stub
		return (2 * Math.PI) * raio;
	}

	@Override
	public double calculaArea() {
		// TODO Auto-generated method stub
		
		return Math.pow(raio, 2) * Math.PI;
	}

}
