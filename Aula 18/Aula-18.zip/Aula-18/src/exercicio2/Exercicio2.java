package exercicio2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int op = 0;
		int num = 0;

		System.out.print("Digite o n�mero de figuras: ");
		try {
			num = scan.nextInt();
		} catch (InputMismatchException e) {
			scan.nextLine();
			System.err.print("ERRO CADASTRO DE POSI��ES! Somente n�meros!Digite novamente: ");
			num = scan.nextInt();
			//e.printStackTrace();
		}



		FiguraGeometrica[] figuras = new FiguraGeometrica[num];

		System.out.println();

		int posicao = 0;

		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar C�rculo em determinada posi��o do array");
			System.out.println("[2] - Cadastrar Ret�ngulo em determinada posi��o do array");
			System.out.println("[3] - Ler dados das figuras cadastradas em determinada posi��o do array");
			System.out.println("[4] - Sair");

			System.out.print("OPC�O: ");
			try {
				op = scan.nextInt();
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.err.print("ERRO ESCOLHA DE OP��ES! Somente n�meros!Digite novamente: ");
				op = scan.nextInt();
				//e.printStackTrace();
			}

			System.out.println();

			switch (op) {
			case 1:
				System.out.print("Selecione a posi��o do array: ");
				try {
					posicao = scan.nextInt();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO ESCOLHA DE POSI��ES! Somente n�meros!Digite novamente: ");
					posicao = scan.nextInt();
					//e.printStackTrace();
				}

				if(posicao >= figuras.length) {
					System.out.print("ATEN��O! Valor maior que o tamanho do array! Digite novamente: ");
					posicao = scan.nextInt();
					System.out.println();
				}if(posicao == figuras.length) {
					System.out.println("ATEN��O! Array de figuras j� preenchido!");
					System.out.println();

				} else {
					//cadastro circulo
					scan.nextLine();
					System.out.print("Digite o nome do c�rculo: ");
					String nomeCirculo = scan.nextLine();
					System.out.print("Digite o raio do c�rculo: ");
					double raioCirculo = scan.nextDouble();

					scan.nextLine(); // Descarta quebra de linha
					//objeto
					FiguraGeometrica circulo = new Circulo(nomeCirculo, raioCirculo);

					try {
						figuras[posicao] = circulo;
					} catch (ArrayIndexOutOfBoundsException e) {

						System.err.print("ERRO INDICE FORA DO LIMITE! Digite qualquer valor para continuar: ");
						try {
							posicao = scan.nextInt();
						} catch (InputMismatchException e1) {
							scan.nextLine();
							System.err.print("ERRO! Somente n�meros!Digite qualquer valor para continuar:");
							posicao = scan.nextInt();
							//e1.printStackTrace();
						}
						//e.printStackTrace();
					}
					posicao++;
					break;
				}

			case 2:
				System.out.print("Selecione a posi��o do array: ");
				try {
					posicao = scan.nextInt();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO ESCOLHA DE POSI��ES! Somente n�meros!Digite novamente: ");
					posicao = scan.nextInt();
					//e.printStackTrace();
				}

				if(posicao >= figuras.length) {
					System.out.print("ATEN��O! Valor maior que o tamanho do array! Digite novamente: ");
					posicao = scan.nextInt();
					System.out.println();
				}if(posicao == figuras.length) {
					System.out.println("ATEN��O! Array de figuras j� preenchido!");
					System.out.println();

				} else {
					//cadastro circulo
					scan.nextLine();
					System.out.print("Digite o nome do ret�ngulo: ");
					String nomeRet = scan.nextLine();
					System.out.print("Digite o lado 1: ");
					double ladoRet1 = scan.nextDouble();
					System.out.print("Digite o lado 2: ");
					double ladoRet2 = scan.nextDouble();

					scan.nextLine(); // Descarta quebra de linha
					//objeto
					FiguraGeometrica retangulo = new Retangulo(nomeRet, ladoRet1, ladoRet2);

					try {
						figuras[posicao] = retangulo;
					} catch (ArrayIndexOutOfBoundsException e) {

						System.err.print("ERRO INDICE FORA DO LIMITE! Digite qualquer valor para continuar: ");
						try {
							posicao = scan.nextInt();
						} catch (InputMismatchException e1) {
							scan.nextLine();
							System.err.print("ERRO! Somente n�meros!Digite qualquer valor para continuar:");
							posicao = scan.nextInt();
							//e1.printStackTrace();
						}
						//e.printStackTrace();
					}
					posicao++;
					break;
				}
			case 3:
				//listar figuras
				for (int i = 0; i < figuras.length; i++) {
					if (figuras[i] != null) {
						System.out.println(figuras[i].getNome());
						System.out.println("�REA: " + figuras[i].calculaArea());
						System.out.println("PER�METRO: " + figuras[i].calculaPerimetro());
						System.out.println();
					} 
				}
				break;
			
			case 4:
				System.out.println("SAINDO...");
				break;	
			default:
				System.out.println("OP��O INV�LIDA! Digite novamente...");
				break;
			}
			
		} while(op!=4);

		scan.close();

	}

}
