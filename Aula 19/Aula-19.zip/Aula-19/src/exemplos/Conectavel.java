package exemplos;

public interface Conectavel {

	public abstract void conectar();
	
	public abstract void consultar(String sql);
	
}
