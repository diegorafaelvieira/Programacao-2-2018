package exemplos;

public interface Imprimivel {

	public static final int POS_INICIAL_X = 200;   //final
	public static final int POS_INICIAL_Y = 300;   //final	
	
	public abstract void imprimir();
	
	
	public abstract void imprimir(String s);
	
}
