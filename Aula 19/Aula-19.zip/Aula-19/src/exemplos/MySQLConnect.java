package exemplos;

public class MySQLConnect implements Imprimivel,Conectavel { // 1� opcao //implementacao - pode ter mais de uma classe mae

	@Override
	public void imprimir() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void imprimir(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void conectar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void consultar(String sql) {
		// TODO Auto-generated method stub
		
	}

	
	
}
