package exemplos;

public class Pessoa implements Imprimivel {

	@Override
	public void imprimir() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void imprimir(String s) {
		// TODO Auto-generated method stub
		
	}

	
}
