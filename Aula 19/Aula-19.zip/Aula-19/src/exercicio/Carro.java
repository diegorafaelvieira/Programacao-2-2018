package exercicio;

public class Carro implements Tributavel {

	//atributos
	private double fipe;

	
	//constutor
	public Carro(double fipe) {
		super();
		this.fipe = fipe;
	}

	//GET e SET
	public double getFipe() {
		return fipe;
	}


	public void setFipe(double fipe) {
		this.fipe = fipe;
	}

	@Override
	public double calcularTributo() {
		
		return fipe * 0.04;
	}

	

}
