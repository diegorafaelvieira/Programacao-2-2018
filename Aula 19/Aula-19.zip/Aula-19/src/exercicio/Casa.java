package exercicio;

public class Casa implements Tributavel{

	//atributos
	private double areaTerreno;
	private double areaConstruida;
	
	
	public Casa(double areaTerreno, double areaConstruida) {
		super();
		this.areaTerreno = areaTerreno;
		this.areaConstruida = areaConstruida;
	}


	public double getAreaTerreno() {
		return areaTerreno;
	}


	public void setAreaTerreno(double areaTerreno) {
		this.areaTerreno = areaTerreno;
	}


	public double getAreaConstruida() {
		return areaConstruida;
	}


	public void setAreaConstruida(double areaConstruida) {
		this.areaConstruida = areaConstruida;
	}



	@Override
	public double calcularTributo() {
			
			double v1 = 1500 * this.areaTerreno;
			double v2 = 200 * this.areaConstruida;
			double venal = v1 + v2;
			return venal + (venal/100 * 0.05);
	}





	


	
	
}
