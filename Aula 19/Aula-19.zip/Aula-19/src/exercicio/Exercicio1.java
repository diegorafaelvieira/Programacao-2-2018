package exercicio;

public class Exercicio1 {

	public static void main(String[] args) {
		
		
		Tributavel[] t1 = new Tributavel[3];
		
		t1[0] = new Carro(40000);
		t1[1] = new Casa(360,100);
		t1[2] = new PropriedadeRural(5);
	
		for (Tributavel x: t1) {
			double v = x.calcularTributo();
			System.out.println(v);
		}
	
	
	
	
	}

}
