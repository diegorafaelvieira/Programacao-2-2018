package exercicio;

public class PropriedadeRural implements Tributavel {

	//atributos
	private double tamanhoPropriedadeRural;
	
	
	//construtor
	public PropriedadeRural(double tamanhoPropriedadeRural) {
		super();
		this.tamanhoPropriedadeRural = tamanhoPropriedadeRural;
	}

	//GET e SET
	public double getTamanhoPropriedadeRural() {
		return tamanhoPropriedadeRural;
	}

	public void setTamanhoPropriedadeRural(double tamanhoPropriedadeRural) {
		this.tamanhoPropriedadeRural = tamanhoPropriedadeRural;
	}


	@Override
	public double calcularTributo() {
		
		double v1 = 1000 * this.tamanhoPropriedadeRural;
		return v1 + (v1/100 * 0.05);
	}
	
}
