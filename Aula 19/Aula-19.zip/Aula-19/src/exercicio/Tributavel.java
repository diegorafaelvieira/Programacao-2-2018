package exercicio;

public interface Tributavel {

	
	public abstract double calcularTributo();

	
	
}
