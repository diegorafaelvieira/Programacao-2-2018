package exemplos;

import java.util.ArrayList;

public class Teste2 {

	public static void main(String[] args) {
		
		ArrayList<Integer> numeros = new ArrayList<>();
		
		numeros.add(1);
		numeros.add(2);
		numeros.add(3);
		numeros.add(4);
		numeros.add(5);

		ArrayList<Integer> numeros2 = new ArrayList<>();
		numeros2.add(6);
		numeros2.add(7);
		numeros2.add(8);
		
		
		numeros.addAll(numeros2); //aqui adiciona todos do numeros2 no numeros
		//numeros.removeAll(numeros2); //aqui remove todos os numeros contidos no numeros2 -> s� exibe o numeros2
		
		
		//FOR melhorado
		for (Integer i : numeros2) {   //FOR cl�ssico precisa usar o GET 
			System.out.println(i);
		}
		
	}

}
