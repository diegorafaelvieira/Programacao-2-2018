package exemplos;

import java.util.ArrayList;

public class TesteArrays {

	public static void main(String[] args) {
		
		//ArrayList
		ArrayList<String> itens = new ArrayList<String>();
		
		//inserir itens no ArrayList
		itens.add("RS");
		itens.add("SC");  // normalmente entra no final de lista
		//itens.clear(); // limpa os dados
		itens.remove(1); // remove o que estava na posi��o 1
		itens.add(0,"SP"); //add na 1� posi��o do ArrayList
		
		
		//listando ArrayList
		//FOR completo
		for (int i = 0; i < itens.size(); i++) {
			System.out.println(itens.get(i));
		}
		
		//FOR melhorado
		
		
	}

}
