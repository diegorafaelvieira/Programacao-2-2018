package exemplos;

import java.util.ArrayList;

public class testeCarro {

	public static void main(String[] args) {
		
		//criar arraylist de carro
		ArrayList<Carro> garagem =  new ArrayList<>();
		
		//add um Carro
		Carro c1 = new Carro("Ford", "Fusion");
		garagem.add(c1);
		// outra maneira de add um Carro
		garagem.add(new Carro("Ford", "Maverick"));
		//garagem.add(0, new Carro("Ford", "Maverick")); // caso deseje escolher a posi��o no ArrayList
		
		//imprimir
		for (int i = 0; i < garagem.size(); i++) {
			System.out.println("MODELO: "+garagem.get(i).getModelo());
			System.out.println("MARCA: "+garagem.get(i).getMarca());
			System.out.println();
		}

	}

}
