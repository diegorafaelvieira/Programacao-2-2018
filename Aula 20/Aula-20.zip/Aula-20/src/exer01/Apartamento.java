package exer01;

public class Apartamento {

	//atributos
	private int numero;
	private int qtdComodos;
	
	//construtor
	public Apartamento(int numero, int qtdComodos) {
		super();
		this.numero = numero;
		this.qtdComodos = qtdComodos;
	}

	//GET e SET
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getQtdComodos() {
		return qtdComodos;
	}

	public void setQtdComodos(int qtdComodos) {
		this.qtdComodos = qtdComodos;
	}

	
	
}
