package exer01;

import java.util.ArrayList;


public class Exercicio1 {

	public static void main(String[] args) {
		
		ArrayList<Apartamento> edificio = new ArrayList<>();
		
		//add 
		edificio.add(new Apartamento(301,5));
		edificio.add(new Apartamento(302,6));
		edificio.add(new Apartamento(303,5));
		
		//imprimindo
		for (int i = 0; i < edificio.size(); i++) {
			System.out.println("N�MERO APARTAMENTO: "+edificio.get(i).getNumero());
			System.out.println("QUANTIDADE DE C�MODOS: "+edificio.get(i).getQtdComodos());
			System.out.println();
		}

	}

}
