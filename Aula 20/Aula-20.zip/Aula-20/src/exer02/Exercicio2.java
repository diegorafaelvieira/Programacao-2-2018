package exer02;

import java.util.ArrayList;
import java.util.Scanner;


public class Exercicio2 {

	public static void main(String[] args) {

		Scanner scan =  new Scanner(System.in);

		ArrayList<Pessoa> p = new ArrayList<>();

		int opc = 0;

		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar Pessoa");
			System.out.println("[2] - Remover 1 Pessoa");
			System.out.println("[3] - Remover todas as Pessoas");
			System.out.println("[4] - Mostrar Dados das Pessoas cadastradas");
			System.out.println("[5] - Mostrar Dados de uma Pessoa");
			System.out.println("[6] - SAIR");
			System.out.print("OP��O: ");
			opc = scan.nextInt();

			switch (opc) {

			//add Pessoa
			case 1:
				scan.nextLine();
				System.out.print("Informe o CPF: ");
				String cpfPessoa = scan.nextLine();
				System.out.print("Informe o nome: ");
				String nomePessoa = scan.nextLine();
				System.out.print("Informe a idade: ");
				int idadePessoa = scan.nextInt();

				// Objeto Pessoa
				p.add(new Pessoa(cpfPessoa, nomePessoa, idadePessoa));
				break;

				// remover 1 Pessoa
			case 2:
				scan.nextLine();
				System.out.print("Digite o CPF a ser removido:");
				String cpfRemover = scan.nextLine();
				for (int i = 0; i < p.size(); i++) {
					if ((p.get(i).getCpf().equals(cpfRemover))) { //equals
						p.remove(i);
						System.out.println("Pessoa removida!");
					}
				}
				break;

				// remover todas as Pessoas
			case 3:
				p.removeAll(p);
				System.out.println("Todas as Pessoas foram removidas!");
				break;

				// mostrar todas as Pessoas inseridas
			case 4:
				for (int i = 0; i < p.size(); i++) {
					System.out.println("NOME: " + p.get(i).getNome());
					System.out.println("CPF: " + p.get(i).getCpf());
					System.out.println("IDADE: " + p.get(i).getIdade());
					System.out.println();
				}
				break;

				// mostrar 1 Pessoa
			case 5:
				scan.nextLine();
				System.out.print("Informe o CPF a ser exibido: ");
				String cpfExibir = scan.nextLine();
				for (int i = 0; i < p.size(); i++) {
					if (p.get(i).getCpf().equals(cpfExibir)) { //equals  
						System.out.println("NOME: " + p.get(i).getNome());
						System.out.println("CPF: " + p.get(i).getCpf());
						System.out.println("IDADE: " + p.get(i).getIdade());
						System.out.println();
					}
				}
				break;

				// sair do MENU
			case 6:
				System.out.println("SAINDO...");
				break;
				
				
			default:
				System.out.println("Op��o inv�lida! Escolha novamente");
				break;
			}


		} while (opc != 6);



		scan.close();

	}

}
