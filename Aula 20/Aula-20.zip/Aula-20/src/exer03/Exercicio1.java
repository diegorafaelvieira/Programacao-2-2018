package exer03;

import java.util.ArrayList;


public class Exercicio1 {

	public static void main(String[] args) {


		ArrayList<Tributavel> tributaveis = new ArrayList<>();
		//add
		tributaveis.add(new Carro(4000));
		tributaveis.add(new Casa(360,100));
		tributaveis.add(new PropriedadeRural(5));

		//imprimir
		//FOR MELHORADO
		for (Tributavel x : tributaveis) {
			double v = x.calcularTributo();
			System.out.println(v);
		}

		System.out.println();
		
		//FOR SIMPLES
		for (int i = 0; i < tributaveis.size(); i++) {
			double val = tributaveis.get(i).calcularTributo();
			System.out.println(val);
		}
		
	}

}
