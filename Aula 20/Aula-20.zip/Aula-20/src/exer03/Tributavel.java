package exer03;

public interface Tributavel {

	
	public abstract double calcularTributo();

	
	
}
