package exer04;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;





public class Exercicio1 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		ArrayList<FiguraGeometrica> figuras = new ArrayList<>();

		int opc = 0;

		do {
			System.out.println("MENU");
			System.out.println("[1] - Calcular C�rculo");
			System.out.println("[2] - Calcular Ret�ngulo");
			System.out.println("[3] - Exibir Figuras cadastradas");
			System.out.println("[4] - Remover 1 Figura");
			System.out.println("[5] - Remover todas Figuras");
			System.out.println("[6] - SAIR");
			System.out.print("OP��O: ");
			try {
				opc = scan.nextInt();
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.err.print("ERRO NO MENU! DIGITE APENAS N�MEROS: ");
				opc = scan.nextInt();
				//e.printStackTrace();
			}

			System.out.println();

			switch (opc) {
			//Cadastrar Circulo
			case 1:
				System.out.print("Nome c�rculo: ");
				String nomeCirculo  = scan.next();
				System.out.print("Digite o raio: ");
				double raio = 0;
				try {
					raio = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine(); // Descarta quebra de linha
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					raio = scan.nextDouble();
					//e.printStackTrace();
				}
				//objeto
				//FiguraGeometrica c = new Circulo(nomeCirculo, raio);
				figuras.add(new Circulo(nomeCirculo, raio));
				for (int i = 0; i < figuras.size(); i++) {
					System.out.println("NOME: " + figuras.get(i).getNome());
					System.out.println("�REA CIRCULO: "+figuras.get(i).calculaArea());
					System.out.println("PER�METRO CIRCULO: "+figuras.get(i).calculaPerimetro());
					System.out.println();			
				}

				break;
			
			//Cadastrar Ret�ngulo
			case 2:
				System.out.print("Nome do ret�ngulo: ");
				String nomeRet = scan.next();
				System.out.print("Digite o lado1: ");
				double lado1 = 0;
				try {
					lado1 = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					lado1 = scan.nextDouble();
					//e.printStackTrace();
				}
				System.out.print("Digite o lado2: ");
				double lado2;
				try {
					lado2 = scan.nextDouble();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("ERRO NO MENU! Digite somente n�meros: ");
					lado2 = scan.nextDouble();
					//e.printStackTrace();
				}
				//objeto
				//FiguraGeometrica r = new Retangulo(nomeRet, lado1, lado2);
				figuras.add(new Retangulo(nomeRet, lado1, lado2));
				for (int i = 0; i < figuras.size(); i++) {
					System.out.println("NOME: " + figuras.get(i).getNome());
					System.out.println("�REA RET�NGULO: "+figuras.get(i).calculaArea());
					System.out.println("PER�METRO RET�NGULO: " +figuras.get(i).calculaPerimetro());
					System.out.println();
				}
				
				break;
			
			// Imprimir todas as figuras
			case 3:
				for (int i = 0; i < figuras.size(); i++) {
					System.out.println("NOME: " + figuras.get(i).getNome());
					System.out.println("�REA RET�NGULO: "+figuras.get(i).calculaArea());
					System.out.println("PER�METRO RET�NGULO: " +figuras.get(i).calculaPerimetro());
					System.out.println();
				}
				
				break;
			
			//REMOVER 1 FIGURA
			case 4:
				scan.nextLine();
				System.out.print("Digite o nome da figura: ");
				String nomeRemover = scan.nextLine();
				for (int i = 0; i < figuras.size(); i++) {
					if (figuras.get(i).getNome().equals(nomeRemover)) {
						figuras.remove(i);
						System.out.println("FIGURA REMOVIDA!");
					}
				}
				break;
			
			//REMOVER TODAS FIGURAS
			case 5:
				figuras.removeAll(figuras);
				System.out.println("TODAS AS FIGURAS FORAM REMOVIDAS!");
				break;
			
			//SAIR
			case 6:
				System.out.println("SAINDO...");
				break;

			default:
				System.out.println("OP��O INV�LIDA!");
				break;
			}

		} while (opc != 6);




		scan.close();

	}

}
