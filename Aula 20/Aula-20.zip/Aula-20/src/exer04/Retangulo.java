package exer04;

public class Retangulo extends FiguraGeometrica {

	
	//atributos
	private double lado1;
	private double lado2;
	
	//construtor
	public Retangulo(String nome, double lado1, double lado2) {
		super(nome);
		this.lado1 = lado1;
		this.lado2 = lado2;
		
	}

	//GET e SET
	public double getLado1() {
		return lado1;
	}

	public void setLado1(double lado1) {
		this.lado1 = lado1;
	}

	public double getLado2() {
		return lado2;
	}

	public void setLado2(double lado2) {
		this.lado2 = lado2;
	}

	@Override
	public double calculaPerimetro() {
		
		return 2 * (lado1 + lado2);
	}

	@Override
	public double calculaArea() {
		
		return lado1 * lado2;
	}
	
	
	
	
}
