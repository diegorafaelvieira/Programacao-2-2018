package exemplos;

import java.util.Arrays;

public class Exemplo1 {

	public static void main(String[] args) {
	
		//ARRAY 
		int[] n = {3,46,121,4,2,32,70,400,7};
		//DEIXA EM ORDEM  //Pode ser feito com Strings tamb�m ver SLIDES
		Arrays.sort(n);
		//IMPRESS�O
		for (int i = 0; i < n.length; i++) {
			System.out.print(n[i] + " ");
		}
		
		System.out.println();
		
		///Para busca bin�ria � preciso fazer a ordena��o antes
		int p = Arrays.binarySearch(n, 121); // n�mero que existe no array
		System.out.println(p); //imprime a posi��o
		
		int p2 = Arrays.binarySearch(n, 90); // n�mero n�o que existe no array
		System.out.println(p2); //imprime a posi��o
		
		System.out.println();
		
		
	}

}
