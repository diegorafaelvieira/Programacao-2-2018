package exemplos;

import java.util.ArrayList;
import java.util.Collections;

public class Exemplo2 {

	public static void main(String[] args) {
				
		
		//ARRAYLIST
		ArrayList<Pessoa> lista = new ArrayList<Pessoa>();
		
		lista.add(new Pessoa(35,"Maria")); 
		lista.add(new Pessoa(18,"Jo�o"));
		lista.add(new Pessoa(23,"Lucas"));
		
		//ORDENA��O
		Collections.sort(lista);
		//� preciso informar o crit�rio da organiza��o
		//FOR MELHORADO
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa.getId() + " " + pessoa.getNome());
		}
		
		System.out.println();
		
		//BUSCA BIN�RIA
		int indice = Collections.binarySearch(lista, new Pessoa(35,"Maria"));
		System.out.println(indice);
	}
}
