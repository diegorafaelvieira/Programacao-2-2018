package exemplos;

public class Pessoa implements Comparable<Pessoa>{ //copiar isso para comparar

	//atributos
	private int id;
	private String nome;
	
	//construtor
	public Pessoa(int id, String nome) {
		super();
		this.id = id;
		this.nome = nome;
	}
	
	//GET e SET
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override  //FAZ A COMPARA��O
	public int compareTo(Pessoa p) {
		if (this.id < p.id) {    // compara��o de String � a mesma coisa -> � DIFERENTE na STRING
			return -1; // -1 menor    //SE trocarmos o 1 por -1 e vice-versa fazemas a ordena��o ao contr�rio
		} else if (this.id > p.id) {
			return 1; // 1 maior
		}
		return 0; // os 2 s�o iguais
	}
	
	
}
