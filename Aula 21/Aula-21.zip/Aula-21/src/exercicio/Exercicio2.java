package exercicio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Exercicio2 {

	public static void main(String[] args) {

		Scanner scan =  new Scanner(System.in);

		ArrayList<Pessoa> p = new ArrayList<>();

		int opc = 0;

		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar Pessoa");
			System.out.println("[2] - Remover 1 Pessoa");
			System.out.println("[3] - Remover todas as Pessoas");
			System.out.println("[4] - Mostrar Dados das Pessoas cadastradas");
			System.out.println("[5] - Mostrar Dados de uma Pessoa");
			System.out.println("[6] - Ordenar Pessoas pelo CPF");
			System.out.println("[7] - Busca Bin�ria CPF");
			System.out.println("[8] - SAIR");
			System.out.print("OP��O: ");
			try {
				opc = scan.nextInt();
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.err.print("Op��o inv�lida! Digite apenas n�meros: ");
				opc = scan.nextInt();
				//e.printStackTrace();
			}

			switch (opc) {

			//add Pessoa
			case 1:
				scan.nextLine();
				System.out.print("Informe o CPF: ");
				String cpfPessoa = scan.nextLine();
				System.out.print("Informe o nome: ");
				String nomePessoa = scan.nextLine();
				System.out.print("Informe a idade: ");
				int idadePessoa;
				try {
					idadePessoa = scan.nextInt();
				} catch (InputMismatchException e) {
					scan.nextLine();
					System.err.print("Idade inv�lida! Digite apenas n�meros: ");
					idadePessoa = scan.nextInt();
					//e.printStackTrace();
				}

				// Objeto Pessoa
				p.add(new Pessoa(cpfPessoa, nomePessoa, idadePessoa));
				break;

				// remover 1 Pessoa
			case 2:
				scan.nextLine();
				System.out.print("Digite o CPF a ser removido:");
				String cpfRemover = scan.nextLine();
				for (int i = 0; i < p.size(); i++) {
					if ((p.get(i).getCpf().equals(cpfRemover))) { //equals
						p.remove(i);
						System.out.println("Pessoa removida!");
					}
				}
				break;

				// remover todas as Pessoas
			case 3:
				p.removeAll(p);
				System.out.println("Todas as Pessoas foram removidas!");
				break;

				// mostrar todas as Pessoas inseridas
			case 4:
				for (int i = 0; i < p.size(); i++) {
					System.out.println("NOME: " + p.get(i).getNome());
					System.out.println("CPF: " + p.get(i).getCpf());
					System.out.println("IDADE: " + p.get(i).getIdade());
					System.out.println();
				}
				break;

				// mostrar 1 Pessoa
			case 5:
				scan.nextLine();
				System.out.print("Informe o CPF a ser exibido: ");
				String cpfExibir = scan.nextLine();
				for (int i = 0; i < p.size(); i++) {
					if (p.get(i).getCpf().equals(cpfExibir)) { //equals  
						System.out.println("NOME: " + p.get(i).getNome());
						System.out.println("CPF: " + p.get(i).getCpf());
						System.out.println("IDADE: " + p.get(i).getIdade());
						System.out.println();
					}
				}
				break;
				
				//Ordenar pelo CPF
			case 6:
				//ORDENA��O
				Collections.sort(p);
				//FOR MELHORADO
				System.out.println("ORDENANDO ARRAYLIST PELO CPF");
				for (Pessoa pes : p) {
					System.out.println(pes.getCpf() +" | " + pes.getNome() + " | " + pes.getIdade());
				}
				System.out.println();
				break;
				
				// BUSCA BIN�RIA 
			case 7:
				//BUSCA BIN�RIA
				scan.nextLine();
				System.out.print("Digite o CPF para a busca bin�ria: ");
				String cpfBusca = scan.nextLine();
				int indice = Collections.binarySearch(p, new Pessoa(cpfBusca)); //AQUI CRIEI UM NOVO CONSTRUTOR APENAS CPF
				System.out.println("Posi��o do CPF ap�s ordena��o do ArrayList: "+ indice);
				System.out.println();
				break;

				// sair do MENU
			case 8:
				System.out.println("SAINDO...");
				break;
				
				
			default:
				System.out.println("Op��o inv�lida! Escolha novamente");
				break;
			}


		} while (opc != 8);

		

		scan.close();

	}

}
