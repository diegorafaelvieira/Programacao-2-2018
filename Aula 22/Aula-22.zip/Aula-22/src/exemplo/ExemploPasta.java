package exemplo;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ExemploPasta {
	
	public static void main(String[] args) {
	
		//String -> Double.parseDouble  / Integer.parseInt
		
		//Cria PASTA
		File pasta = new File("Clientes");
		pasta.mkdir(); // cria a pasta
		//OBS: precisa executar o programa 1 vez //clicar com o direito em cima da pasta de dar REFRESH
		//pasta.delete(); // deleta a pasta
		
		File subpasta = new File("Clientes/Devedores");
		subpasta.mkdir(); //cria a subpasta
		//OBS: precisa executar o programa 1 vez //clicar com o direito em cima da pasta de dar REFRESH
		
		//Cria ARQUIVO
		File arquivo = new File("Clientes/nomes.txt");
		try {
			arquivo.createNewFile(); //surond try catch(ESCOLHER OP��O)   Aqui cria o arquivo
			
			//Escrever txt
			FileWriter escritor = new FileWriter(arquivo, false);  //TRUE anexa no final do arquivo || FALSE apaga
			BufferedWriter bw = new BufferedWriter(escritor);
			
			bw.write("Maria\n");  // \n quebra linha
			bw.write("Paulo\n");
			bw.write("Joana\n");
			
			for (int i = 0; i < 5; i++) {
				bw.write("Teste " + i + "\n");
			}
			
			//Fechar
			bw.close();
			escritor.close();
			
			//FileReader leitor = new FileReader(arquivo, true);
			//BufferedReader br = new BufferedReader(leitor);
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
}
