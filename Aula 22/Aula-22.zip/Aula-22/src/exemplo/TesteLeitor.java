package exemplo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class TesteLeitor {

	public static void main(String[] args) {
		
		//colei do exemplo anterior
		File arquivo = new File("Clientes/nomes.txt");
		
		FileReader leitor;
		try {
			leitor = new FileReader(arquivo); // AQUI op��o surrond try/catch
			BufferedReader br = new BufferedReader(leitor);
			
			
			String linha = null;
			
			while((linha = br.readLine()) != null) { //readline diferente de nulo
				System.out.println(linha);
				
				/*
				Pessoa p = new Pessoa();
				lista.add(p); */
			}
			
			//Fechar
			br.close();
			leitor.close();
			
		} catch (Exception e) { //AQUI trocar para Exception
			
			e.printStackTrace();
		}
		
		
		
	}

}
