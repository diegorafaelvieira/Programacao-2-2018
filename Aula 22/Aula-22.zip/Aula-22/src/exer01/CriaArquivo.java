package exer01;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CriaArquivo {

	public static void main(String[] args) {
		
		File arquivo = new File("Numeros/numeros1.txt");
		try {
			arquivo.createNewFile();
			//O true indica que o conteudo do arquivo deve ser mantido
			FileWriter escritor = new FileWriter(arquivo,true);     //false s� deixa o print 1x
			
			
			BufferedWriter buffer = new  BufferedWriter(escritor);
			
			
			
			//ATEN��O N�o esquecer de fechar
			buffer.close();
			escritor.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
