package exer01;

import java.io.File;

public class CriaDiretorio {

	public static void main(String[] args) {
		
		File dir = new File("Numeros");
		 
		dir.mkdir();

	}

}
