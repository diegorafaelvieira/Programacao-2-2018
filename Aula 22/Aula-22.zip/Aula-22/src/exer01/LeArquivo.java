package exer01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class LeArquivo {

	public static void main(String[] args) {
		
		File arquivo= new File("Numeros/numeros1.txt");

		int soma = 0;
		//Aqui n�o vai true ou false
		try {
			FileReader leitor = new FileReader(arquivo);
			BufferedReader buffer = new BufferedReader(leitor);

			String linha = null;


			while((linha = buffer.readLine()) !=null) {
				System.out.println(linha);

				int s = Integer.parseInt(linha);
				soma += s;
			
			}



			//N�o esquecer de fechar
			buffer.close();
			leitor.close();

			//Trocar para IOException
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		File arquivo2 = new File("Numeros/soma.txt"); 		


		try {
			
			FileWriter leitor2 = new FileWriter(arquivo2,false);
			BufferedWriter buffer2 = new BufferedWriter(leitor2);
			
			buffer2.write("A soma dos valores �: " + soma + "\n");
			
			buffer2.close();
			leitor2.close();

		} catch (IOException e2) {
			// TODO: handle exception
			e2.printStackTrace();
		}

	}

}
