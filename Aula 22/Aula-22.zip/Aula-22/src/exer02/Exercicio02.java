package exer02;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class Exercicio02 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		ArrayList<Pessoa> pes = new ArrayList<Pessoa>();
		
		int opc = 0;
		
		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar Pessoa");
			System.out.println("[2] - Sair");
			System.out.print("OP��O: ");
			opc = scan.nextInt();
			
			switch (opc) {
			case 1:
				scan.nextLine();
				System.out.print("Digite o nome: ");
				String nomePessoa = scan.nextLine();
				
				System.out.print("Digite o sobrenome: ");
				String sobrenomePessoa = scan.nextLine();
				
				
				//objeto PESSOA
				pes.add(new Pessoa(nomePessoa, sobrenomePessoa));
				break;

			case 2:
				System.out.println("SAINDO....CONFIRA O ARQUIVO pessoas.txt");
				
				//criar ARQUIVO
				File arquivo = new File("Pessoas/pessoas.txt");
				
				try {
					arquivo.createNewFile();
					
					//escreve ARQUIVO
					FileWriter escritor = new FileWriter(arquivo, false);
					
					BufferedWriter buffer = new BufferedWriter(escritor);
					
					for (int i = 0; i < pes.size(); i++) {
						
						buffer.write(pes.get(i).getNome() + " ");
						
						buffer.write(pes.get(i).getSobrenome() + "\n");
						System.out.println();
						
					}
					//FECHAR
					buffer.close();
					escritor.close();
					
					
				} catch (IOException e) {
					// TODO: handle exception
				}
				
				break;

			default:
				System.out.println("Valor inv�lido! Digite novamente");
				break;
			}
			
		} while (opc != 2);
		
	
		
		
		
		scan.close();

	}

}
