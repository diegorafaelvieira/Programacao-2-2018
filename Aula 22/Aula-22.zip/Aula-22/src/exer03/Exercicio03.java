package exer03;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class Exercicio03 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		ArrayList<Pessoa> pes = new ArrayList<Pessoa>();
		
		int opc = 0;
		
		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar Pessoa");
			System.out.println("[2] - Ordenar Pessoas pelo NOME");
			System.out.println("[3] - Sair");
			System.out.print("OP��O: ");
			opc = scan.nextInt();
			
			switch (opc) {
			case 1:
				scan.nextLine();
				System.out.print("Digite o nome: ");
				String nomePessoa = scan.nextLine();
				
				System.out.print("Digite o sobrenome: ");
				String sobrenomePessoa = scan.nextLine();
				
				
				//objeto PESSOA
				pes.add(new Pessoa(nomePessoa, sobrenomePessoa));
				break;

				
				//ORDENAR POR ORDEM ALFAB�TICA
			case 2:
				//Ordena��o
				Collections.sort(pes);
				
				System.out.println("ORDENANDO ARRAYLIST PESSOAS PELO NOME");
				
				//FOR MELHORADO
				for (Pessoa pessoa : pes) {
					System.out.println(pessoa.getNome() + " " + pessoa.getSobrenome());
				}
				

				
				//criar ARQUIVO
				File arquivo = new File("Pessoas/pessoas.txt");
				
				try {
					arquivo.createNewFile();
					
					//escreve ARQUIVO
					FileWriter escritor = new FileWriter(arquivo, false);
					
					BufferedWriter buffer = new BufferedWriter(escritor);
					
					for (int i = 0; i < pes.size(); i++) {
						
						buffer.write(pes.get(i).getNome() + " ");
						
						buffer.write(pes.get(i).getSobrenome() + "\n");
						System.out.println();
						
					}
					//FECHAR
					buffer.close();
					escritor.close();
					
					System.out.println("CONFIRA O ARQUIVO pessoas.txt");
					
				} catch (IOException e) {
					// TODO: handle exception
				}
				
				break;
				
			//SAIR	
			case 3:
				System.out.println("SAINDO....");

				
				break;

			//OP��O INV�LIDA
			default:
				System.out.println("Valor inv�lido! Digite novamente");
				break;
			}
			
		} while (opc != 3);
		
	
		
		
		
		scan.close();

	}

}
