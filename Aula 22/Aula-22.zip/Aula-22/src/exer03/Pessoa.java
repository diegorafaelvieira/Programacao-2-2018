package exer03;

public class Pessoa implements Comparable<Pessoa>{

	//atributos
	private String nome;
	private String sobrenome;
	
	//contrutor
	public Pessoa(String nome, String sobrenome) {
		super();
		this.nome = nome;
		this.sobrenome = sobrenome;
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	@Override
	public int compareTo(Pessoa p) {
		
		return this.nome.compareTo(p.nome); // ASSIM ORDENO STRING NOMES
		
	}
	
	
	
}
