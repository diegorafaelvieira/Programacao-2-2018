package exer04;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class Exercicio04 {

	public static void main(String[] args) {

		int soma = 0;
		/*
		//CRIA ARQUIVO
		File arquivo = new File("Valores/entrada");

		
		try {
			arquivo.createNewFile();

			FileWriter escritor = new FileWriter(arquivo, true);
			BufferedWriter bw = new BufferedWriter(escritor);

			//FECHAR
			bw.close();
			escritor.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		
		//LE ARQUIVO
		File arquivo2 = new File("Valores/entrada");

		try {

			FileReader leitor = new FileReader(arquivo2 );
			BufferedReader br = new BufferedReader(leitor);

			String linha = "";
			String [] x; 
			
			
			while ((linha = br.readLine()) != null) {
				x = linha.split(" ");
				for (int i = 0; i < x.length; i++) {
					soma +=Integer.parseInt(x[i]);
					
				}
			
				//System.out.println(soma);
				//soma = 0;
				

				//ESCREVER NA SA�DA
				File arquivo3 = new File("Valores/saida");

				try {

					FileWriter escritor2 = new FileWriter(arquivo3, true);
					BufferedWriter bw2 = new BufferedWriter(escritor2);

					bw2.write(soma + "\n");
					soma = 0;
					
					//FECHAR
					bw2.close();
					escritor2.close();


				} catch (IOException e) {
					e.printStackTrace();

				}
				
			}
			
			//FECHAR
			br.close();
			leitor.close();
			
			} catch (IOException e2) {
				e2.printStackTrace();
			}



	}

}
