package exer05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercicio05 {

	public static void main(String[] args) {
	
		int resultado = 0;
		
		//LER ARQUIVO
		File arquivo = new File("Eventos/entrada.txt");
		
		try {
			FileReader leitor = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(leitor);
			
			String linha = "";
			String [] x;
			
			while ((linha = br.readLine()) != null) {
				//c�digo aqui
				x = linha.split(" ");
				for (int i = 0; i < x.length; i++) {
					
					int hi = Integer.parseInt(x[0]);
					int hf = Integer.parseInt(x[1]);
					
					if (hi == hf) {
						 resultado = 24;
					} else if (hi > hf) {
						resultado = hf - hi + 24;
					} else {
						resultado = hf - hi;
					}
				}
				
					//ESCREVE NA SAIDA
					File arquivo2 = new File("Eventos/saida.txt");
					
					try {
						FileWriter escritor = new FileWriter(arquivo2, true);  
						BufferedWriter bw = new BufferedWriter(escritor);  
						
						
						bw.write("O EVENTO DUROU " + resultado + " HORA(S) \n");
						resultado = 0;
						
						//FECHAR
						bw.close();
						escritor.close();
					} catch (IOException e) {
						// TODO: handle exception
					}
							
			}
					
			//FECHAR
			br.close();
			leitor.close();
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		

	}

}
