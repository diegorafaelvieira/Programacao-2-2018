package exercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercicio1 {

	public static void main(String[] args) {
		
		int soma = 0;
		
		//LEITURA
		File arquivo = new File("Exercicio1/entrada.txt");
		
		try {
			
			FileReader leitor = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(leitor);
			
			String linha = null;
			
			
			while ((linha = br.readLine())!= null) {
				
				int s = Integer.parseInt(linha);
				soma += s;
				
			}
			
			//FECHAR
			br.close();
			leitor.close();
			
			
		} catch (IOException e) {
			// TODO: handle exception
		}

		//LEITURA
		File arquivo2 = new File("Exercicio1/saida.txt");
		
		try {
			
			FileWriter escritor = new FileWriter(arquivo2, false);
			BufferedWriter bw = new BufferedWriter(escritor);
			
			bw.write("SOMA: " + soma);
			
			//FECHAR
			bw.close();
			escritor.close();
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}

}
