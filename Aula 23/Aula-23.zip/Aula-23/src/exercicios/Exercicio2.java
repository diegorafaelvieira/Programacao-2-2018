package exercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercicio2 {

	public static void main(String[] args) {
		
		int soma = 0;
		
		//LE ARQUIVO
		File arquivo = new File("Exercicio2/entrada.txt");
		
		try {
			FileReader leitor = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(leitor);
			
			String linha = "";
			String [] x;
			
			while ((linha = br.readLine()) != null) {
				
				x = linha.split(" ");
				
				for (int i = 0; i < x.length; i++) {
					soma += Integer.parseInt(x[i]);
				}
			
			//ESCREVER
				File arquivo2 = new File("Exercicio2/saida.txt");
				
				try {
					FileWriter escritor = new FileWriter(arquivo2, true);
					BufferedWriter bw = new BufferedWriter(escritor);
				
					bw.write(soma + "\n");
					soma = 0;
					
					//FECHAR
					bw.close();
					escritor.close();
					
				} catch (IOException e) {
					// TODO: handle exception
				}
				
			}
				//FECHAR
				br.close();
				leitor.close();
				
			
		} catch (IOException e) {
			// TODO: handle exception
		}

		
		
	}

}
