package exercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercicio3 {

	public static void main(String[] args) {

		
		String comando = "N"; 
		String posicao = "N";
		
		//utizar char  N=0 L=1 S=2 O=3   n�o utilizar split
		
		//LER ARQUIVO
		File arquivo = new File("Exercicio3/entrada.txt");

		try {

			FileReader leitor = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(leitor);

			String linha;
			String[] comandos;

			while ((linha = br.readLine()) != null) {
				
				//comandos = linha.split("");
				
				for (int i = 0; i < comandos.length; i++) {
					
					int n = Integer.parseInt(linha);  ///
					
					
					for (int j = 1; j <= n; j++) {
						comandos = linha.split("");
						
					
						if(comando.equals("E")) {	
							if(posicao.equals("N")) {
								posicao = "O";
							} else if(posicao.equals("O")) {
								posicao = "S";
							} else if(posicao.equals("S")) {
								posicao = "L";
							} else if(posicao.equals("L")) {
								posicao = "N";
							}
							
						} else if(comando.equals("D")) {
							if(posicao.equals("N")) {
								posicao = "L";
							} else if(posicao.equals("L")) {
								posicao = "S";
							} else if(posicao.equals("S")) {
								posicao = "O";
							} else if(posicao.equals("O")) {
								posicao = "N";
							}
						}
					}
				}
				
				

				//ESCREVER
				File arquivo2 = new File("Exercicio3/saida.txt");

				try {

					FileWriter escritor = new FileWriter(arquivo2, true);
					BufferedWriter bw = new BufferedWriter(escritor);

					bw.write(posicao + "\n");
					//posicao = 'N';
					//comando = 'N';

					//FECHAR
					bw.close();
					escritor.close();

				} catch (IOException e) {
					// TODO: handle exception
				}

				//FECHAR
				br.close();
				leitor.close();

			}


		} catch (IOException e) {
			// TODO: handle exception
		}

	}

}
