package exercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercicio4 {

	public static void main(String[] args) {

		
		int time1,time2,c1,v1,c2,v2 = 0;
		String resultado = "";

		//LEITURA
		File arquivo = new File("Exercicio4/entrada.txt");

		try {

			FileReader leitor = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(leitor);

			String linha = "";
			String [] gols;

			while ((linha = br.readLine()) != null) {

				gols = linha.split(" x ");
				for (int i = 0; i < gols.length; i++) {

					int n = Integer.parseInt(linha);

					for (int j = 1; j <= n; j++) {
						gols = linha.split(" x ");

						c1 = Integer.parseInt(gols[0]);
						v1 = Integer.parseInt(gols[1]);

						gols = linha.split(" x ");

						v2 = Integer.parseInt(gols[1]);
						c2 = Integer.parseInt(gols[0]);

						time1 = c1 + v2;
						time2 = v1 + c2;


						if (time1 > time2) {
							resultado = "Time 1";
						}else if (time1 == time2 && c2 > c1) {
							resultado = "Time 1";
						} else if (time1 < time2) {
							resultado = "Time 2";
						} else if (time1 == time2 && c2 < c1) {
							resultado = "Time 2";
						} else {
							resultado = "Penaltis";
						}

					}
				}
			}




			//ESCREVER
			File arquivo2 = new File("Exercicio4/saida.txt");

			try {

				FileWriter escritor = new FileWriter(arquivo2, true);
				BufferedWriter bf = new BufferedWriter(escritor);

				bf.write(resultado + "\n"); //

				time1 = 0;
				time2 = 0;

				//FECHAR
				bf.close();
				escritor.close();

			} catch (IOException e) {
				// TODO: handle exception
			}


			//FECHAR
			br.close();
			leitor.close();

		} catch (IOException e) {
			// TODO: handle exception
		}

	}

}
