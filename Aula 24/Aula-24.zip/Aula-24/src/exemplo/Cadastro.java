package exemplo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Cadastro {

	public static void main(String[] args) {
		ArrayList<Carro> garagem = new ArrayList<Carro>();
		//Leitura TXT    1�EXECUTAR SEM ESSA PARTE -> APENAS C�DIGO PROGRAMA��O E ESCRITA(SALVAR NO TXT)
		try {
			FileReader fr = new FileReader("dados/carros.txt"); //fazer isso por �ltimo 1� fazer a escrita
			BufferedReader br = new BufferedReader(fr);
			
			
			String linha = null;
			while ((linha = br.readLine()) != null) {  //Leitura das linhas do arquivo txt   ???//SPLIT // PARSE INT String.split = (" ") SPLIT n�o funciona assim ->""
				garagem.add(new Carro(linha)); //leitura    //exercicios s� usar 1 arquivo TXT 
				
			}
			                 ///1 objetos   /// 2 mais de 1 objeto -> formato txt � livre
			//Fechar
			br.close();
			fr.close();
			
		} catch (IOException e1) {  //aqui trocar para IOException
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}    
		
		
		//Programa (come�ar pela parte l�gica)
		Scanner leitor = new Scanner(System.in);
		
		int opcao = 0;
		
		do {
			System.out.println("[1] Novo carro");
			System.out.println("[2] Listar");
			System.out.println("[3] Sair");
			System.out.print("> ");
			
			try {
				opcao = Integer.parseInt(leitor.nextLine());
			} catch (NumberFormatException e) {
				opcao = 0;
				System.out.println("Entrada inv�lida.");
				//e.printStackTrace();
			}
			
			switch (opcao) {
			case 1: //inserir
				System.out.print("Digite o modelo:");
				String m = leitor.nextLine();
				//objeto
				garagem.add(new Carro(m));
				System.out.println("Carro inserido.");
				System.out.println();
				break;
				
			case 2: //listar
				System.out.println();
				System.out.println("Lista de Carros: ");
				for (Carro carro : garagem) {

					System.out.println(carro.getModelo());
				}
				System.out.println();
				break;	
				
			case 3: //sair
				System.out.println("SAINDO...");
				break;

			default:
				System.out.println("OP��O INV�LIDA!DIGITE NOVAMENTE");
				break;
			}
			
			
		} while (opcao != 3);
		leitor.close();
			
		// Salvar no TXT
		File f = new File("dados/carros.txt");
		
		try {
			f.createNewFile();
			//Escreve
			FileWriter fw = new FileWriter(f, false);  //false sobreescreve o arquivo
			BufferedWriter bw = new BufferedWriter(fw);
			
			for (Carro carro : garagem) {
				bw.write(carro.getModelo() +"\n");
			}
			
			//Fechar
			bw.close();
			fw.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
