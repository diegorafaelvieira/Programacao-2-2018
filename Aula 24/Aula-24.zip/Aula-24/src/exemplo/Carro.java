package exemplo;

public class Carro {

	//atributos
	private String modelo;

	//construtor
	public Carro(String modelo) {
		super();
		this.modelo = modelo;
	}

	
	//GET e SET
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	

	
}
