package exercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;




public class Exercicio1 {

	public static void main(String[] args) {

		ArrayList<Imovel> condominio = new ArrayList<Imovel>();
		
		
		//LEITURA TXT
		try {
			FileReader fr = new FileReader("exercicio1/imoveis.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String linha = null;
			while ((linha = br.readLine()) != null) {
				String linha2 = br.readLine();
				double d = Double.parseDouble(linha2);
				condominio.add(new Imovel(linha,d)); //AQUI FOI DIFERENTE
				
			}
			
			//Fechar
			br.close();
			fr.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		
		//PROGRAMA
		int opc = 0 ;
		
		Scanner scan = new Scanner(System.in);
		
		do {
			System.out.println("MENU");
			System.out.println("(1) Cadastrar um novo im�vel");
			System.out.println("(2) Mostrar im�veis cadastrados");
			System.out.println("(3) Remover um im�vel");
			System.out.println("(4) Sair do sistema");
			System.out.print("> ");
			
			try {
				opc = Integer.parseInt(scan.nextLine());
				
			} catch (NumberFormatException e) {
				opc = 0;
				System.out.println("Entrada inv�lida.");
				//e.printStackTrace();
			}
			
			switch (opc) {
			case 1: //inserir
				System.out.print("Digite o endere�o: ");
				String enderecoI = scan.nextLine();
				System.out.print("Digite o valor R$ ");
				double valorI = scan.nextDouble();
				//objeto
				condominio.add(new Imovel(enderecoI, valorI));
				System.out.println("Im�vel inserido.");
				System.out.println();
				break;
				
			case 2: //listar
				System.out.println();
				System.out.println("Lista de Im�veis");
				for (Imovel imovel : condominio) {
					System.out.println(imovel.getEndereco() + "\n" + imovel.getValor());
					System.out.println();
				}
				System.out.println();
				break;
				
			case 3: //remover
				System.out.println();
				System.out.println("Removendo um Im�vel no array: ");
				System.out.print("Digite o endere�o a ser removido: ");
				String enderecoR = scan.nextLine();
				for (int i = 0; i < condominio.size(); i++) {
					if ((condominio.get(i).getEndereco().equals(enderecoR))) {
						condominio.remove(i);
						System.out.println("Im�vel removido.");
					}
				}
				
				break;
				
			case 4: // sair
				System.out.println("SAINDO...");
				break;
				
		  
			}
			
		} while (opc != 4);
		scan.close();
		
		
		//SALVAR TXT
		File arquivo = new File("exercicio1/imoveis.txt");
		
		try {
			arquivo.createNewFile();
			
			//Escrever
			FileWriter fw = new FileWriter(arquivo, false);
			BufferedWriter bw = new BufferedWriter(fw);
			
			for (Imovel imovel : condominio) {
				bw.write(imovel.getEndereco() + "\n" + imovel.getValor() + "\n");
			}
			
			//FECHAR
			bw.close();
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
