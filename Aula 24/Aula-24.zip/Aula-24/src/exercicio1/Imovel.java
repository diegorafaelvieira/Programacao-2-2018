package exercicio1;

public class Imovel {

	//atributos
	private String endereco;
	private double valor;
	
	//construtor
	public Imovel(String endereco, double valor) {
		super();
		this.endereco = endereco;
		this.valor = valor;
	}


	//GET e SET
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
	
	
}
