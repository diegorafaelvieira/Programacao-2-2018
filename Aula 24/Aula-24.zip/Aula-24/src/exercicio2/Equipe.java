package exercicio2;

import java.util.ArrayList;

public class Equipe {

	//atributos
	private String nome;
	private String cidade;
	private ArrayList<Jogador> jogadores;
	
	//construtor
	public Equipe(String nome, String cidade, ArrayList<Jogador> jogador) {
		
		this.nome = nome;
		this.cidade = cidade;
		this.jogadores = jogador;   //this.setJogadores(jogadores)
	}

	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public ArrayList<Jogador> getJogador() {
		return jogadores;
	}

	public void setJogador(ArrayList<Jogador> jogador) {
		this.jogadores = jogador;
	}
	

	
}
