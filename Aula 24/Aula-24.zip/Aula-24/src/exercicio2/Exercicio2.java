package exercicio2;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {

		ArrayList<Equipe> equipes = new ArrayList<Equipe>();
		

		//Leitura TXT         �LTIMA ETAPA A SER FEITA | � NECESS�RIO RODAR ANTES E GRAVAR ANTES DE FAZER ESSA
		try {     //n�o precisa fazer o FILE AQUI
			FileReader fr = new FileReader("exercicio2/equipes.txt");
			BufferedReader br = new BufferedReader(fr);

			String nomeEquipe = null;   //antes era linha
	
			while((nomeEquipe = br.readLine()) != null) {
				

				String cidadeE = br.readLine();
				
				ArrayList<Jogador> jogadores = new ArrayList<Jogador>();
				for (int i = 0; i < 5; i++) {
					String nomeJ = br.readLine();
					String sobrenomeJ = br.readLine();
					String posicao = br.readLine();
					jogadores.add(new Jogador(nomeJ, sobrenomeJ, posicao));
				}
				
				
				equipes.add(new Equipe(nomeEquipe, cidadeE, jogadores));
				
				
						
			}
			
			//FECHAR
			br.close();
			fr.close();

		} catch (IOException e) {
			e.printStackTrace();
		}


		//PROGRAMA  PRIMEIRA ETAPA
		Scanner scan = new Scanner(System.in);

		int opc = 0;

		do {
			System.out.println("MENU");
			System.out.println("[1] - Cadastrar Equipe");
			System.out.println("[2] - Listar Equipe");
			System.out.println("[3] - Remover Equipe");
			System.out.println("[4] - Sair");
			System.out.print("> ");
			try {
				opc = Integer.parseInt(scan.nextLine());
			} catch (NumberFormatException e) {
				opc = 0;
				System.out.println("Entrada inv�lida");
				//e.printStackTrace();
			}

			switch (opc) {
			case 1: //Cadastrar Equipe
				System.out.print("Digite o nome da Equipe: ");
				String nomeE = scan.nextLine();
				System.out.print("Digite a cidade da Equipe: ");
				String cidadeE = scan.nextLine();
				ArrayList<Jogador> jogadores = new ArrayList<Jogador>();
				for (int i = 0; i < 5; i++) {
					System.out.print("Nome Jogador "+(i+1)+" : ");
					String nomeJ = scan.nextLine();
					System.out.print("Sobrenome Jogador "+(i+1)+" : ");
					String sobrenomeJ = scan.nextLine();
					System.out.print("Posi��o Jogador "+(i+1)+" : ");
					String posicaoJ = scan.nextLine();
					//objeto
					jogadores.add(new Jogador(nomeJ, sobrenomeJ, posicaoJ));
				}
				//objeto
				equipes.add(new Equipe(nomeE, cidadeE, jogadores));
				System.out.println("Equipe inserida.");
				System.out.println();
				break;

			case 2: //Listar Equipe
				System.out.println();
				System.out.println("Listagem de Equipes");
				
				for (int i = 0; i < equipes.size(); i++) {
					System.out.println("EQUIPE: "+equipes.get(i).getNome());
					System.out.println("CIDADE: "+equipes.get(i).getCidade());
					System.out.println();
					
					for (int j = 0; j < equipes.get(i).getJogador().size(); j++) {  ///MUDAR AQUI FOR
						System.out.println("JOGADOR NOME: "+ equipes.get(i).getJogador().get(j).getNome());
						System.out.println("JOGADOR SOBRENOME: "+ equipes.get(i).getJogador().get(j).getSobrenome());
						System.out.println("JOGADOR POSI��O: "+ equipes.get(i).getJogador().get(j).getPosicao());	
						System.out.println();
					}

				} 
				/*
				for (Equipe equipe : equipes) { 
					System.out.println(equipe.getNome() + "\n" + equipe.getCidade() + "\n");
					for (Jogador jogador : equipe.getJogador()) { // : <-  equipe.getJogadores())
						System.out.println(jogador.getNome() + "\n" + jogador.getSobrenome() + "\n" + jogador.getPosicao() + "\n");
					}
				} */
				System.out.println();
				break;

			case 3: // Remover Equipe    //remo��o na prova ao nosso crit�rio
				System.out.println();
				System.out.println("Removendo uma equipe do array");
				System.out.print("Digite o nome da equipe a ser removida: ");
				String nomeR = scan.nextLine();
				for (int i = 0; i < equipes.size(); i++) {  //REMOVER S� COM O FOR NORMAL
					if (equipes.get(i).getNome().equals(nomeR)) {
						equipes.remove(i);
						System.out.println("Equipe removida.");
					}
				}
				break;

			case 4:
				System.out.println("SAINDO...");
				break;

			default:
				break;
			}



		} while (opc != 4);

		scan.close();



		//SALVAR TXT    SEGUNDA ETAPA - RODAR ANTES DE FAZER A LEITURA   //TEM QUE CRIAR O FOLDER(PASTA) o TXT � criado dentro do arquivo
		File arquivo = new File("exercicio2/equipes.txt");

		try {
			arquivo.createNewFile();   //AQUI TEM QUE CRIAR O TRY/CATCH

			//ESCREVE
			FileWriter fw = new FileWriter(arquivo, false);    //false s� salva 1 vez e depois sobreescre //professor colocou false
			BufferedWriter bw = new BufferedWriter(fw);
		
			for (int i = 0; i < equipes.size(); i++) {
				bw.write(equipes.get(i).getNome() + "\n");
				bw.write(equipes.get(i).getCidade() + "\n");
				
				for (int j = 0; j < equipes.get(i).getJogador().size(); j++) {
					bw.write(equipes.get(i).getJogador().get(j).getNome() + "\n");
					bw.write(equipes.get(i).getJogador().get(j).getSobrenome()+ "\n");
					bw.write(equipes.get(i).getJogador().get(j).getPosicao()+ "\n");
				}
				
			} 
			
			/*
			for (Equipe equipe : equipes) {   // � a mesma coisa que o listar CASE s� tirar o sout e coloca o bw.write
				bw.write(equipe.getNome() + "\n" + equipe.getCidade() + "\n");
				  
				for (Jogador jogador : equipe.getJogador()) {
					bw.write(jogador.getNome() + "\n" + jogador.getSobrenome() + "\n" + jogador.getPosicao() +"\n");				}
			}
			*/
			//FECHAR    fechar em ordem invertida
			bw.close();
			fw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
