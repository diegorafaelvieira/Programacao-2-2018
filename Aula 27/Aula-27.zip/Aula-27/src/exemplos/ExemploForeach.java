package exemplos;

import java.util.ArrayList;

public class ExemploForeach {

	public static void main(String[] args) {
		 
		ArrayList<Imovel> catalogo = new ArrayList<Imovel>();

		catalogo.add(new Imovel(10, "Rua abc" ));
		catalogo.add(new Imovel(28, "Rua xyz" ));
		catalogo.add(new Imovel(100, "Rua pqr" ));
		
		for (int i = 0; i < catalogo.size(); i++) {
			System.out.println(catalogo.get(i).getCodigo());
			System.out.println(catalogo.get(i).getEndereco());
		}

		
		for (Imovel imovel : catalogo) {
			System.out.println(imovel.getCodigo());
			System.out.println(imovel.getEndereco());
		}
	}

}
