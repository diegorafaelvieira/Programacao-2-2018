package exemplos;

public class Imovel {

	private int codigo;
	private String endereco;
	
	
	public Imovel(int codigo, String endereco) {
		
		this.codigo = codigo;
		this.endereco = endereco;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public String getEndereco() {
		return endereco;
	}


	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	
	
	
}
