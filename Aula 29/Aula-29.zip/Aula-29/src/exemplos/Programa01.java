package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Programa01 {

	private JFrame frmMeuApp;
	private JTextField tfNome;
	private JTextArea taSaida;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa01 window = new Programa01();
					window.frmMeuApp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Programa01() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMeuApp = new JFrame();
		frmMeuApp.setTitle("Meu app");
		frmMeuApp.setBounds(100, 100, 450, 300);
		frmMeuApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMeuApp.getContentPane().setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNome.setForeground(Color.RED);
		lblNome.setBounds(27, 29, 46, 14);
		frmMeuApp.getContentPane().add(lblNome);
		
		tfNome = new JTextField();
		tfNome.setBounds(27, 54, 115, 20);
		frmMeuApp.getContentPane().add(tfNome);
		tfNome.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) { // dei 2 cliques no bot�o
				
				
				taSaida.append(tfNome.getText() + "\n"); // joga dentro da caixa de texto
				//System.out.println("ol�, " + tfNome.getText()); //aqui pega o texto na caixa de texto
			}
		});
		btnOk.setBounds(37, 85, 89, 23);
		frmMeuApp.getContentPane().add(btnOk);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(193, 29, 231, 209);
		frmMeuApp.getContentPane().add(scrollPane);
		
		taSaida = new JTextArea();
		scrollPane.setViewportView(taSaida);
	}
}
