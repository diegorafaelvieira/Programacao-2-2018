package exercicios;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Exercicio1 {

	private JFrame frmExercicio;
	private JTextField tfNumeroA;
	private JTextField tfNumeroB;
	private JTextField tfSoma;
	private JTextField tfDiferenca;
	private JTextField tfMultiplicacao;
	private JTextField tfDivisao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exercicio1 window = new Exercicio1();
					window.frmExercicio.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Exercicio1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmExercicio = new JFrame();
		frmExercicio.setTitle("Exercicio 1");
		frmExercicio.setBounds(100, 100, 450, 300);
		frmExercicio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmExercicio.getContentPane().setLayout(null);
		
		JLabel lblNmeroA = new JLabel("N\u00FAmero A");
		lblNmeroA.setForeground(Color.RED);
		lblNmeroA.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNmeroA.setBounds(31, 32, 88, 14);
		frmExercicio.getContentPane().add(lblNmeroA);
		
		JLabel lblNmeroB = new JLabel("N\u00FAmero B");
		lblNmeroB.setForeground(Color.BLUE);
		lblNmeroB.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNmeroB.setBounds(252, 32, 88, 14);
		frmExercicio.getContentPane().add(lblNmeroB);
		
		tfNumeroA = new JTextField();
		tfNumeroA.setBounds(31, 57, 86, 20);
		frmExercicio.getContentPane().add(tfNumeroA);
		tfNumeroA.setColumns(10);
		
		tfNumeroB = new JTextField();
		tfNumeroB.setBounds(252, 57, 86, 20);
		frmExercicio.getContentPane().add(tfNumeroB);
		tfNumeroB.setColumns(10);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  //aqui � o bot�o

				
				//SOMA				
				int soma = Integer.parseInt(tfNumeroA.getText()) + Integer.parseInt(tfNumeroB.getText());
				tfSoma.setText(String.valueOf(soma));
				
				//DIFEREN�A				
				int diferenca = Integer.parseInt(tfNumeroA.getText()) - Integer.parseInt(tfNumeroB.getText());
				tfDiferenca.setText(String.valueOf(diferenca));
				
				//MULTIPLICA��O
				int multiplicacao = Integer.parseInt(tfNumeroA.getText()) * Integer.parseInt(tfNumeroB.getText());
				tfMultiplicacao.setText(String.valueOf(multiplicacao));
				
				//DIVIS�O				
				int divisao = Integer.parseInt(tfNumeroA.getText()) / Integer.parseInt(tfNumeroB.getText());
				tfDivisao.setText(String.valueOf(divisao));
				

			}
		});
		btnCalcular.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnCalcular.setForeground(Color.GREEN);
		btnCalcular.setBounds(31, 99, 88, 23);
		frmExercicio.getContentPane().add(btnCalcular);
		
		tfSoma = new JTextField();
		JTextField tfSoma2 = tfSoma;
		tfSoma2.setBounds(31, 174, 86, 20);
		frmExercicio.getContentPane().add(tfSoma2);
		tfSoma2.setColumns(10);
		
		JLabel lblSoma = new JLabel("Soma");
		lblSoma.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSoma.setBounds(31, 149, 46, 14);
		frmExercicio.getContentPane().add(lblSoma);
		
		JLabel lblDiferena = new JLabel("Diferen\u00E7a");
		lblDiferena.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblDiferena.setBounds(252, 149, 80, 14);
		frmExercicio.getContentPane().add(lblDiferena);
		
		tfDiferenca = new JTextField();
		JTextField tfDiferenca2 = tfDiferenca;
		tfDiferenca2.setBounds(254, 174, 86, 20);
		frmExercicio.getContentPane().add(tfDiferenca2);
		tfDiferenca2.setColumns(10);
		
		JLabel lblMultiplicao = new JLabel("Multiplica\u00E7\u00E3o");
		lblMultiplicao.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMultiplicao.setBounds(31, 205, 101, 14);
		frmExercicio.getContentPane().add(lblMultiplicao);
		
		JLabel lblDiviso = new JLabel("Divis\u00E3o");
		lblDiviso.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblDiviso.setBounds(252, 205, 88, 14);
		frmExercicio.getContentPane().add(lblDiviso);
		
		tfMultiplicacao = new JTextField();
		JTextField tfMultiplicacao2 = tfMultiplicacao;
		tfMultiplicacao2.setBounds(31, 230, 86, 20);
		frmExercicio.getContentPane().add(tfMultiplicacao2);
		tfMultiplicacao2.setColumns(10);
		
		tfDivisao = new JTextField();
		JTextField tfDivisao2 = tfDivisao;
		tfDivisao2.setBounds(252, 230, 86, 20);
		frmExercicio.getContentPane().add(tfDivisao2);
		tfDivisao2.setColumns(10);
	}

}
