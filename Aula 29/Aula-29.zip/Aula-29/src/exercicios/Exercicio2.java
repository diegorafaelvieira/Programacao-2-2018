package exercicios;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Exercicio2 {

	private JFrame frame;
	private JTextField tfFrase;
	private JTextField tfResultado;

	int numeroPalavras=0;
	int numeroCaracteres=0;
	String [] frase;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exercicio2 window = new Exercicio2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Exercicio2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblFrase = new JLabel("Frase");
		lblFrase.setBounds(41, 26, 46, 14);
		frame.getContentPane().add(lblFrase);

		tfFrase = new JTextField();
		tfFrase.setBounds(37, 51, 232, 20);
		frame.getContentPane().add(tfFrase);
		tfFrase.setColumns(10);

		JButton btnAnalisar = new JButton("Analisar");
		btnAnalisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//aqui vai o c�digo
				String texto = tfFrase.getText();
				
				numeroCaracteres = tfFrase.getText().replaceAll(" ", "").length();
				
				if (texto.length() > 0 && texto.contains(" ")) {
					
					String[] valor =  texto.split(" ");
					
					
					for (int i = 0; i < valor.length; i++) {
						numeroPalavras ++;
					}
						
				}
				
				tfResultado.setText(String.valueOf(numeroCaracteres) + " caracteres e "+ numeroPalavras + " palavras");
			}
		});
		btnAnalisar.setBounds(41, 106, 89, 23);
		frame.getContentPane().add(btnAnalisar);

		tfResultado = new JTextField();
		tfResultado.setBounds(41, 168, 228, 20);
		frame.getContentPane().add(tfResultado);
		tfResultado.setColumns(10);
	}
}
