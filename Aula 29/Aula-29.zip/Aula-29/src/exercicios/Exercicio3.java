package exercicios;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Color;

public class Exercicio3 {

	private JFrame frmExercicio;
	private JTextField tfCpf;
	private JTextField tfNome;
	private JTextField tfIdade;
	private JTextArea taSaida;
	ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exercicio3 window = new Exercicio3();
					window.frmExercicio.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Exercicio3() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmExercicio = new JFrame();
		frmExercicio.setTitle("Exercicio 3");
		frmExercicio.getContentPane().setBackground(Color.WHITE);
		frmExercicio.setBounds(100, 100, 482, 300);
		frmExercicio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmExercicio.getContentPane().setLayout(null);

		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(10, 21, 46, 14);
		frmExercicio.getContentPane().add(lblCpf);

		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(10, 46, 46, 14);
		frmExercicio.getContentPane().add(lblNome);

		JLabel lblIdade = new JLabel("Idade");
		lblIdade.setBounds(10, 71, 46, 14);
		frmExercicio.getContentPane().add(lblIdade);

		tfCpf = new JTextField();
		tfCpf.setBounds(59, 18, 151, 20);
		frmExercicio.getContentPane().add(tfCpf);
		tfCpf.setColumns(10);

		tfNome = new JTextField();
		tfNome.setColumns(10);
		tfNome.setBounds(59, 46, 151, 20);
		frmExercicio.getContentPane().add(tfNome);

		tfIdade = new JTextField();
		tfIdade.setColumns(10);
		tfIdade.setBounds(59, 71, 151, 20);
		frmExercicio.getContentPane().add(tfIdade);

		JButton btInserir = new JButton("Inserir");
		btInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//c�digo inserir dados

				String cpfP = tfCpf.getText();
				String nomeP = tfNome.getText();
				int idadeP = Integer.parseInt(tfIdade.getText());

				//Objeto Pessoa
				pessoas.add(new Pessoa(cpfP, nomeP, idadeP));

				//Exibe na mural
				taSaida.append(cpfP + "," + nomeP+ "," + idadeP + "\n");
				
			}
		});
		btInserir.setBounds(10, 128, 181, 23);
		frmExercicio.getContentPane().add(btInserir);

		JButton bt = new JButton("Limpar");
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//c�digo limpar campos
				tfCpf.setText("");
				tfNome.setText("");
				tfIdade.setText("");
				taSaida.setText("");  //ASSIM LIMPO O TF E TA

			}
		});
		bt.setBounds(10, 162, 181, 23);
		frmExercicio.getContentPane().add(bt);

		JButton btGravarEmArquivo = new JButton("Gravar em arquivo");
		btGravarEmArquivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// c�digo gravar txt
				File arquivo = new File("Pasta/dados.txt");

				try {
					arquivo.createNewFile();

					FileWriter escrever = new FileWriter(arquivo, false); //TRUE ou FALSE
					BufferedWriter bw = new BufferedWriter(escrever);


					bw.write(taSaida.getText());

					//}

					//fechar
					bw.close();
					escrever.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}

			}
		});
		btGravarEmArquivo.setBounds(10, 196, 181, 23);
		frmExercicio.getContentPane().add(btGravarEmArquivo);

		JButton btRecuperarDeArquivo = new JButton("Recuperar de arquivo");
		btRecuperarDeArquivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// c�digo leitura txt
				try {

					FileReader ler = new FileReader("Pasta/dados.txt");
					BufferedReader br = new BufferedReader(ler);

					String cpfP = null;
					String [] x;

					while ((cpfP = br.readLine()) != null) {

						x = cpfP.split(",");

						for (int i = 0; i < x.length; i++) {

							String nomeP = (x[1]);

							int idadeP = Integer.parseInt(x[2]);

							pessoas.add(new Pessoa(cpfP, nomeP, idadeP));

						}
						taSaida.append(cpfP + "\n");
						
					}

					//fechar
					br.close();
					ler.close();

					
					
				} catch (IOException e) {
					// TODO: handle exception
				}
			}
		});
		btRecuperarDeArquivo.setBounds(10, 230, 181, 23);
		frmExercicio.getContentPane().add(btRecuperarDeArquivo);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(220, 15, 236, 242);
		frmExercicio.getContentPane().add(scrollPane);

		taSaida = new JTextArea();
		scrollPane.setViewportView(taSaida);

		
	}
}
