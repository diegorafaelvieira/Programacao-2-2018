package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Exemplo1 {

	private JFrame frame;
	private JPanel panel2;
	private JPanel panel1;
	private JTextField mensagem;
	private JLabel lblNewLabel;
	private JButton btnProxima;
	private JPanel panel3;
	private JButton btnVoltarVerde;
	private JMenuBar menuBar;
	private JPanel panel4;
	private JButton btnAamrelo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exemplo1 window = new Exemplo1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Exemplo1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel principal = new JPanel();
		frame.getContentPane().add(principal, BorderLayout.CENTER);
		principal.setLayout(new CardLayout(0, 0));
		
		panel1 = new JPanel();
		panel1.setBackground(Color.RED);
		panel1.setForeground(Color.WHITE);
		principal.add(panel1, "name_42946459623119");
		panel1.setLayout(null);
		
		mensagem = new JTextField();
		mensagem.setBounds(38, 37, 86, 20);
		panel1.add(mensagem);
		mensagem.setColumns(10);
		
		JButton btnOk = new JButton("Ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//exibe palavra
				lblNewLabel.setText(mensagem.getText());
				//c�digo ir painel 2
				panel2.setVisible(true);
				panel1.setVisible(false);
				
				//amarelo
				panel4.setVisible(false);
				
				
			}
		});
		btnOk.setBounds(35, 81, 89, 23);
		panel1.add(btnOk);
		
		panel2 = new JPanel();
		panel2.setBackground(Color.BLUE);
		panel2.setForeground(Color.WHITE);
		principal.add(panel2, "name_42960666656936");
		panel2.setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(39, 22, 330, 23);
		panel2.add(lblNewLabel);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
				//c�digo voltar panel 1
				//c�digo ir painel 2
				panel2.setVisible(false);
				panel1.setVisible(true);
				
				//amarelo
				panel4.setVisible(false);
				
			
			}
		});
		btnVoltar.setBounds(103, 198, 89, 23);
		panel2.add(btnVoltar);
		
		btnProxima = new JButton("Pr\u00F3xima");
		btnProxima.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//Panel Azul para o Verde
				panel2.setVisible(false);
				panel3.setVisible(true);
				
				//amarelo
				panel4.setVisible(false);
			}
		});
		btnProxima.setBounds(244, 198, 89, 23);
		panel2.add(btnProxima);
		
		panel3 = new JPanel();
		panel3.setBackground(Color.GREEN);
		principal.add(panel3, "name_43917054412150");
		panel3.setLayout(null);
		
		btnVoltarVerde = new JButton("Voltar");
		btnVoltarVerde.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//volta Para a panel azul
				panel3.setVisible(false);
				panel2.setVisible(true);
				
				//amarelo
				panel4.setVisible(false);
			}
		});
		btnVoltarVerde.setBounds(173, 202, 89, 23);
		panel3.add(btnVoltarVerde);
		
		btnAamrelo = new JButton("Amarelo");
		btnAamrelo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//
				panel4.setVisible(true);
				panel3.setVisible(false);
			}
		});
		btnAamrelo.setBounds(173, 167, 89, 23);
		panel3.add(btnAamrelo);
		
		panel4 = new MeuPanel();   //aqui eu mudei Panel
		
		principal.add(panel4, "name_45167512430478");
		
		menuBar = new JMenuBar();
		frame.getContentPane().add(menuBar, BorderLayout.NORTH);
		
		JMenu mnArquivo = new JMenu("Arquivo");
		menuBar.add(mnArquivo);
		
		JMenuItem mntmVermelho = new JMenuItem("Vermelho");
		mntmVermelho.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel1.setVisible(true);
				panel2.setVisible(false);
				panel3.setVisible(false);
				
				//amarelo
				panel4.setVisible(false);
			}
		});
		mnArquivo.add(mntmVermelho);
		
		JMenuItem mntmAzul = new JMenuItem("Azul");
		mntmAzul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				panel1.setVisible(false);
				panel2.setVisible(true);
				panel3.setVisible(false);
				
				//amarelo
				panel4.setVisible(false);
			}
		});
		mnArquivo.add(mntmAzul);
		
		JMenuItem mntmVerde = new JMenuItem("Verde");
		mntmVerde.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel1.setVisible(false);
				panel2.setVisible(false);
				panel3.setVisible(true);
				
				//amarelo
				panel4.setVisible(false);
			}
		});
		mnArquivo.add(mntmVerde);
	}
}
