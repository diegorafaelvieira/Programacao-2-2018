package exemplos;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MeuPanel extends JPanel {
	private JTextField tfAmarelo1;
	private JTextField tfAmarelo2;
	private JButton btAmarelo;

	/**
	 * Create the panel.
	 */
	public MeuPanel() {
		setBackground(Color.YELLOW);
		setLayout(null);
		
		tfAmarelo1 = new JTextField();
		tfAmarelo1.setBounds(142, 38, 86, 20);
		add(tfAmarelo1);
		tfAmarelo1.setColumns(10);
		
		tfAmarelo2 = new JTextField();
		tfAmarelo2.setBounds(142, 110, 86, 20);
		add(tfAmarelo2);
		tfAmarelo2.setColumns(10);
		
		btAmarelo = new JButton("New button");
		btAmarelo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btAmarelo.setBounds(142, 180, 89, 23);
		add(btAmarelo);

	}

}
