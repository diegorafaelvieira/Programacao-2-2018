package exercicio1;

import java.awt.EventQueue;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;


public class Exercicio1 {

    private JFrame frmBandas;
    ArrayList<Banda> bandas = new ArrayList<Banda>();
    private JTextField tfPaisBanda;
    private JTextField tfNomeBanda;
    private JPanel panel2;
    private JPanel panel1;
    private JTextField tfNroIntegrantes;
    private JTextField tfNomeBandaRemover;
    private JPanel panel3;
    private JPanel panel4;
    private JTextArea taSaida;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Exercicio1 window = new Exercicio1();
                    window.frmBandas.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Exercicio1() {
        initialize();
    }
    
    
    
    

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	
    	//LER TXT
    	File arquivo = new File("Pasta/bandas.txt");
    	
    	try {
			arquivo.createNewFile();
			
			FileReader ler = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(ler);
			
			String linha = null;
			
			while ((linha = br.readLine()) != null) {
				
				String[] x = linha.split(",");
				
				bandas.add(new Banda(x[0], x[1], Integer.parseInt(x[2])));
			}
			
			//FECHAR
			br.close();
			ler.close();
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	
    	
        frmBandas = new JFrame();
        frmBandas.setTitle("BANDAS");
        frmBandas.setBounds(100, 100, 450, 312);
        frmBandas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmBandas.getContentPane().setLayout(new BorderLayout(0, 0));

        JPanel principal = new JPanel();
        frmBandas.getContentPane().add(principal);
        principal.setLayout(new CardLayout(0, 0));

        panel1 = new JPanel();
        principal.add(panel1, "name_47122994121324");
        panel1.setLayout(null);

        JLabel lblCadastroDeBandas = new JLabel("MENU BANDAS");
        lblCadastroDeBandas.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblCadastroDeBandas.setBounds(134, 27, 163, 22);
        panel1.add(lblCadastroDeBandas);

        JButton btnCadastrarBanda = new JButton("Cadastrar Banda");
        btnCadastrarBanda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //c�digo MENU -> Cadastrar Banda

                panel1.setVisible(false);
                panel2.setVisible(true);
            }
        });
        btnCadastrarBanda.setBounds(138, 78, 137, 23);
        panel1.add(btnCadastrarBanda);

        JButton btnRemoverBanda = new JButton("Remover Banda");
        btnRemoverBanda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //C�digo MENU -> Remover Banda
                panel1.setVisible(false);
                panel3.setVisible(true);
            }
        });
        btnRemoverBanda.setBounds(138, 112, 137, 23);
        panel1.add(btnRemoverBanda);

        JButton btnConsultarBandas = new JButton("Consultar Bandas");
        btnConsultarBandas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //C�digo MENU -> Consultar Bandas
                panel1.setVisible(false);
                panel4.setVisible(true);
                taSaida.setText("");  //ASSIM s� exibe o arquivo TXT uma �nica vez

                for (int i = 0; i < bandas.size(); i++) {
					taSaida.append("Nome: " + bandas.get(i).getNome() + " Pa�s: "+bandas.get(i).getPais()+ 
							" Nro Integrantes: "+bandas.get(i).getNroIntegrantes() + "\n");
				}
            }

        });
        btnConsultarBandas.setBounds(138, 146, 137, 23);
        panel1.add(btnConsultarBandas);

        JButton btnSair = new JButton("Sair");
        btnSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

            	//SALVAR TXT
            	File arquivo = new File("Pasta/bandas.txt");
            	
            	try {
					arquivo.createNewFile();
					
					FileWriter escrever = new FileWriter(arquivo, false);
					BufferedWriter bw = new BufferedWriter(escrever);
					
					for (int i = 0; i < bandas.size(); i++) {
						bw.write(bandas.get(i).getNome() + "," + bandas.get(i).getPais() + "," +
								String.valueOf(bandas.get(i).getNroIntegrantes()) + "\n");
					}
					
					//FECHAR
					bw.close();
					escrever.close();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	
                //SAIR
                System.exit(0);
            }
        });
        btnSair.setBounds(138, 180, 137, 23);
        panel1.add(btnSair);

        panel2 = new JPanel();
        principal.add(panel2, "name_47123033318588");
        panel2.setLayout(null);

        tfPaisBanda = new JTextField();
        tfPaisBanda.setColumns(10);
        tfPaisBanda.setBounds(219, 123, 128, 20);
        panel2.add(tfPaisBanda);

        tfNomeBanda = new JTextField();
        tfNomeBanda.setBounds(219, 84, 166, 20);
        panel2.add(tfNomeBanda);
        tfNomeBanda.setColumns(10);

        tfNroIntegrantes = new JTextField();
        tfNroIntegrantes.setColumns(10);
        tfNroIntegrantes.setBounds(219, 166, 128, 20);
        panel2.add(tfNroIntegrantes);

        JLabel lblCadastroDeBandas_1 = new JLabel("Cadastro de Bandas");
        lblCadastroDeBandas_1.setForeground(Color.RED);
        lblCadastroDeBandas_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblCadastroDeBandas_1.setBounds(129, 25, 195, 30);
        panel2.add(lblCadastroDeBandas_1);

        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.addActionListener(new ActionListener() {
            private String nomeB;
            private String paisB;
            private int nroIntegrantesB;

            public void actionPerformed(ActionEvent arg0) {

                nomeB = tfNomeBanda.getText();
                paisB = tfPaisBanda.getText();
                nroIntegrantesB = Integer.parseInt(tfNroIntegrantes.getText());

                //Objeto Banda
                bandas.add(new Banda(nomeB, paisB, nroIntegrantesB));

              
                //Aqui mostra msg de Cadastro Efetuado
                JOptionPane.showMessageDialog(null, "Banda Cadastrada com Sucesso!");
            }
        });
        btnCadastrar.setBounds(173, 211, 115, 23);
        panel2.add(btnCadastrar);

        JLabel lblNomeBanda = new JLabel("Nome Banda");
        lblNomeBanda.setFont(new Font("Tahoma", Font.BOLD, 15));
        lblNomeBanda.setBounds(90, 85, 109, 14);
        panel2.add(lblNomeBanda);

        JLabel lblPasBanda = new JLabel("Pa\u00EDs Banda");
        lblPasBanda.setFont(new Font("Tahoma", Font.BOLD, 15));
        lblPasBanda.setBounds(109, 124, 109, 14);
        panel2.add(lblPasBanda);

        JLabel lblNmerosIntegrantes = new JLabel("N\u00FAmeros Integrantes");
        lblNmerosIntegrantes.setFont(new Font("Tahoma", Font.BOLD, 15));
        lblNmerosIntegrantes.setBounds(39, 167, 208, 19);
        panel2.add(lblNmerosIntegrantes);

        JButton btnCadastroMenuVoltar = new JButton("Menu");
        btnCadastroMenuVoltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //C�digo Cadastro -> Menu
                panel2.setVisible(false);
                panel1.setVisible(true);
            }
        });
        btnCadastroMenuVoltar.setBounds(39, 211, 115, 23);
        panel2.add(btnCadastroMenuVoltar);

        JButton btnLimparCadastro = new JButton("Limpar");
        btnLimparCadastro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //C�digo Limpar dados
                tfNomeBanda.setText("");
                tfPaisBanda.setText("");
                tfNroIntegrantes.setText("");
            }
        });
        btnLimparCadastro.setBounds(298, 211, 115, 23);
        panel2.add(btnLimparCadastro);

        panel3 = new JPanel();
        principal.add(panel3, "name_3607965415174");
        panel3.setLayout(null);

        JLabel lblNewLabel = new JLabel("Nome Banda Remover");
        lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 15));
        lblNewLabel.setBounds(44, 97, 173, 14);
        panel3.add(lblNewLabel);

        tfNomeBandaRemover = new JTextField();
        tfNomeBandaRemover.setBounds(211, 96, 197, 20);
        panel3.add(tfNomeBandaRemover);
        tfNomeBandaRemover.setColumns(10);

        JLabel lblRemoverBanda = new JLabel("Remover Banda");
        lblRemoverBanda.setForeground(Color.RED);
        lblRemoverBanda.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblRemoverBanda.setBounds(131, 11, 195, 30);
        panel3.add(lblRemoverBanda);

        JButton btnRemoverMenuVoltar = new JButton("Menu");
        btnRemoverMenuVoltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //C�digo Remover -> Menu
                panel3.setVisible(false);
                panel1.setVisible(true);
            }
        });
        btnRemoverMenuVoltar.setBounds(29, 202, 115, 23);
        panel3.add(btnRemoverMenuVoltar);

        JButton btnRemover = new JButton("Remover");
        btnRemover.addActionListener(new ActionListener() {


            public void actionPerformed(ActionEvent arg0) {

            	//C�digo Remover Banda
            	for (int i = 0; i < bandas.size(); i++) {
					
            		if (bandas.get(i).getNome().equals(tfNomeBandaRemover.getText())) {
						bandas.remove(i);
						
						//Aqui mostra msg de Remo��o Efetuada
		                JOptionPane.showMessageDialog(null, "Banda Removida com Sucesso!");
					}
				}

                
            }
        });
        btnRemover.setBounds(169, 202, 115, 23);
        panel3.add(btnRemover);

        JButton btnLimparRemover = new JButton("Limpar");
        btnLimparRemover.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //c�digo LIMPAR
                tfNomeBandaRemover.setText("");
            }
        });
        btnLimparRemover.setBounds(294, 202, 115, 23);
        panel3.add(btnLimparRemover);

        panel4 = new JPanel();
        principal.add(panel4, "name_4277677604689");
        panel4.setLayout(null);

        JLabel lblConsultarBandas = new JLabel("Consultar Bandas");
        lblConsultarBandas.setBounds(146, 5, 142, 20);
        lblConsultarBandas.setForeground(Color.RED);
        lblConsultarBandas.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel4.add(lblConsultarBandas);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(32, 29, 379, 179);
        panel4.add(scrollPane);

        taSaida = new JTextArea();
        scrollPane.setViewportView(taSaida);

        JButton btnConsultaMenuVoltar = new JButton("Menu");
        btnConsultaMenuVoltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                //c�digo Consulta -> Menu
                panel4.setVisible(false);
                panel1.setVisible(true);
            }
        });
        btnConsultaMenuVoltar.setBounds(188, 219, 115, 23);
        panel4.add(btnConsultaMenuVoltar);
        
        JMenuBar menuBar = new JMenuBar();
        frmBandas.getContentPane().add(menuBar, BorderLayout.NORTH);
        
        JMenu mnNewMenu = new JMenu("Arquivo");
        menuBar.add(mnNewMenu);
        
        JMenuItem mntmCadastrar = new JMenuItem("Cadastrar");
        mntmCadastrar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		panel1.setVisible(false);
				panel2.setVisible(true);
				panel3.setVisible(false);
				panel4.setVisible(false);
        		
        	}
        });
        mnNewMenu.add(mntmCadastrar);
        
        JMenuItem mntmRemover = new JMenuItem("Remover");
        mntmRemover.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		panel1.setVisible(false);
				panel2.setVisible(false);
				panel3.setVisible(true);
				panel4.setVisible(false);
        		
        	}
        });
        mnNewMenu.add(mntmRemover);
        
        JMenuItem mntmConsultar = new JMenuItem("Consultar");
        mntmConsultar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		panel1.setVisible(false);
				panel2.setVisible(false);
				panel3.setVisible(false);
				panel4.setVisible(true);
				
				
				
				 //C�digo MENU -> Consultar Bandas
                panel1.setVisible(false);
                panel4.setVisible(true);
                taSaida.setText("");  //ASSIM s� exibe o arquivo TXT uma �nica vez

                for (int i = 0; i < bandas.size(); i++) {
					taSaida.append("Nome: " + bandas.get(i).getNome() + " Pa�s: "+bandas.get(i).getPais()+ 
							" Nro Integrantes: "+bandas.get(i).getNroIntegrantes() + "\n");
				}
        	}
        });
        mnNewMenu.add(mntmConsultar);
        
        JMenuItem mntmMenu = new JMenuItem("Menu");
        mntmMenu.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		panel1.setVisible(true); 
				panel2.setVisible(false);
				panel3.setVisible(false);
				panel4.setVisible(false);
				
				
				
				
        	}
        });
        mnNewMenu.add(mntmMenu);
        
        JMenuItem mntmSair = new JMenuItem("Sair");
        mntmSair.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		
        		//SALVAR TXT
            	File arquivo = new File("Pasta/bandas.txt");
            	
            	try {
					arquivo.createNewFile();
					
					FileWriter escrever = new FileWriter(arquivo, false);
					BufferedWriter bw = new BufferedWriter(escrever);
					
					for (int i = 0; i < bandas.size(); i++) {
						bw.write(bandas.get(i).getNome() + "," + bandas.get(i).getPais() + "," +
								String.valueOf(bandas.get(i).getNroIntegrantes()) + "\n");
					}
					
					//FECHAR
					bw.close();
					escrever.close();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		
        		//SAIR
                System.exit(0);
        	}
        });
        mnNewMenu.add(mntmSair);
    }
}