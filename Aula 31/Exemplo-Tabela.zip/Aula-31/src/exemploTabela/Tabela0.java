package exemploTabela;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Tabela0 {

	private JFrame frame;
	private JTable table;
	private JButton btnRemover;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tabela0 window = new Tabela0();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Tabela0() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 367);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 98, 375, 185);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Sobrenome"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DefaultTableModel dt = (DefaultTableModel) table.getModel();
				String nome = textField.getText();
				String sobrenome = textField_1.getText();
				if((nome.length() > 0) && (sobrenome.length() > 0)) {
					dt.addRow(new String[] {nome,sobrenome});
				}
			}
		});
		btnAdicionar.setBounds(256, 47, 89, 23);
		frame.getContentPane().add(btnAdicionar);
		
		btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DefaultTableModel dt = (DefaultTableModel) table.getModel();
				// Se o n�mero de linhas for maior que zero
				if((table.getRowCount() > 0) && (table.getSelectedRow() >= 0)) {
					// Remove a linha selecionada
					dt.removeRow(table.getSelectedRow());
				}
			}
		});
		btnRemover.setBounds(166, 294, 89, 23);
		frame.getContentPane().add(btnRemover);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(37, 25, 46, 14);
		frame.getContentPane().add(lblNome);
		
		textField = new JTextField();
		textField.setBounds(109, 22, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblSobrenome = new JLabel("Sobrenome");
		lblSobrenome.setBounds(37, 51, 77, 14);
		frame.getContentPane().add(lblSobrenome);
		
		textField_1 = new JTextField();
		textField_1.setBounds(109, 48, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
	}
}
