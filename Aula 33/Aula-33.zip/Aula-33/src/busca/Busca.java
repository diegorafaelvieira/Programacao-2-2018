package busca;

import java.util.Random;

public class Busca {

	public static void main(String[] args) {
		
		// Array de n�meros pares
		int [] valores = new int[1000000];
		for (int i = 0; i < valores.length; i++) {
			valores[i] = i*2;
		}
		
		Random r = new Random();
		int itemProcurado = r.nextInt(2000000);
		System.out.println("Vou buscar o " + itemProcurado);
		
		
		long t1 = System.nanoTime();
		int i1 = busca(valores, itemProcurado);
		long t2 = System.nanoTime();
		long t2t1 = t2 - t1;
		
		
		if (i1 >= 0) {
			System.out.println("Busca normal encontrou. T=" + t2+t1);
		} else {
			System.out.println("Busca normal n�o encontrou. T= " + t2+t1);
		}
		
		
		long t3 = System.nanoTime();
		int i2 = buscaBinaria(valores, itemProcurado);
		long t4 = System.nanoTime();
		long t4t3 = t4 - t3;
		
		if (i2 >= 0) {
			System.out.println("Busca Bin�ria encontrou. T=" + t4+t3);
		} else {
			System.out.println("Busca Bin�ria n�o encontrou. T= " + t4+t3);
		}
		
		/* Copiar isso depois em outro 
		int[] lista = {1,2,3,4,5,6,7,8,9,10};
		int itemProcurado = 5;
		int indice = buscaBinaria(lista,itemProcurado);

		if(indice >= 0) {
			System.out.println("Encontrou.");
		} else {
			System.out.println("N�o achou.");
		} */
	}




	private static int busca(int[] lista, int itemProcurado) {
		int i = 0;
		while(i < lista.length) {
			if(lista[i] == itemProcurado) {
				return i;	
			}
			i++;
		}
		return -1;
	}
	
	
	private static int buscaBinaria(int[] lista, int itemProcurado) {
		
		int inicio = 0;
		int fim = lista.length - 1;
		do {
			
			int meio = (inicio + fim) / 2;   //encontrar o meio
			
			if (lista[meio] == itemProcurado) { 
				return meio;
			}
			
			if (lista[meio] < itemProcurado) {
				inicio = meio + 1;
				
			} else {
				fim = meio - 1;
			}
			
		} while (inicio <= fim);
		return -1;
	}

}