package listas;

import java.util.ArrayList;
import java.util.LinkedList;

public class Teste {

	public static void main(String[] args) {
		
		
		int n = 100000;
		String s = "String";
		
		LinkedList<String> ll = new LinkedList<String>();
		ArrayList<String> al = new ArrayList<String>();
		
		//Inser��o
		long t1 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			//ll.addFirst(s); //add no come�o da lista
			ll.addLast(s); //add no final
		}
		long t2 = System.nanoTime();
		
		long t3 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			//al.add(0,s); //add no come�o da lista
			al.add(s);  //add no final
		}
		
		long t4 = System.nanoTime();
		
		System.out.println("----------Inser��o----------");
		System.out.println("LinkedList " + (t2-t1));
		System.out.println("ArrayList  " + (t4-t3));
		System.out.println();
		
		
		//leitura
		long t5 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			ll.getFirst();  //consulta o primeiro
			//ll.getLast();    //consulta o �ltimo
			//ll.get(n/2);  //consulta o meio PONTO FRACO DO LINKEDLIST
		}
		
		long t6 = System.nanoTime();
		
		long t7 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			al.get(0); //consulta o primeiro
			//al.get(al.size() - 1); //consulta o �ltimo
			//al.get(n/2);  //consulta o meio     
		}
		
		long t8 = System.nanoTime();
		
		System.out.println("----------Consulta----------");
		System.out.println("LinkedList " + (t6-t5));
		System.out.println("ArrayList  " + (t8-t7));
		System.out.println();

		
		//Remo��o
		
		long t9 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			//ll.removeFirst(); //Remove o Primeiro
			ll.removeLast(); //Remove o �ltimo
		}
		
		long t10 = System.nanoTime();
		
		long t11 = System.nanoTime();
		for (int i = 0; i < n; i++) {
			//al.remove(0); //Remove o Primeiro
			al.remove(al.size() - 1); //Remove o �ltimo
		}
		
		long t12 = System.nanoTime();
		
		System.out.println("----------Remo��o----------");
		System.out.println("LinkedList " + (t10-t9));
		System.out.println("ArrayList  " + (t12-t11));
		System.out.println();

	}

}
