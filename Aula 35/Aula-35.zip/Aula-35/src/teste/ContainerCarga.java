package teste;

public class ContainerCarga {

	
	private int codigo;
	private String conteudo;
	
	
	
	public ContainerCarga(int codigo, String conteudo) {
		super();
		this.codigo = codigo;
		this.conteudo = conteudo;
	}



	public int getCodigo() {
		return codigo;
	}



	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}



	public String getConteudo() {
		return conteudo;
	}



	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}
	
	
	
}
