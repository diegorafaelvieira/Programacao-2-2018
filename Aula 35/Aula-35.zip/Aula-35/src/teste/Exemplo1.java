package teste;

import java.util.Stack;

public class Exemplo1 {

	public static void main(String[] args) {
		
		
		ContainerCarga c1 = new ContainerCarga(1,"Bicicletas");
		ContainerCarga c2 = new ContainerCarga(2,"Carne");
		ContainerCarga c3 = new ContainerCarga(3,"DVDs");
		ContainerCarga c4 = new ContainerCarga(4,"Eletronicos");
		
		
		
		Stack<ContainerCarga> p1 = new Stack<ContainerCarga>();
		p1.push(c1);
		p1.push(c2);
		p1.push(c3);
		p1.push(c4);   //push -> coloca na pilha (empilha)
		
		//p1.pop(); //-> assim ele retira
		
		while(!p1.isEmpty()) {   //aqui desempilha (enquanto n�o estiver vazia)
			ContainerCarga temp = p1.pop(); //pop -> desempilha // pega e cai fora da pilha // pega o que ta no topo da pilha 
			System.out.println();
			System.out.println(temp.getCodigo());
			System.out.println(temp.getConteudo());
		}

	}

}
