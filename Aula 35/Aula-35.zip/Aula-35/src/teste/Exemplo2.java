package teste;

import java.util.LinkedList;
import java.util.Queue;

public class Exemplo2 {

	public static void main(String[] args) {
		
		Navio n1 = new Navio(123,"Abc");
		Navio n2 = new Navio(456,"Efg");
		Navio n3 = new Navio(789,"Hij");
		
		Queue<Navio> f1 = new LinkedList<Navio>();  //Queue -> fila / � uma interface / 1 a entrar � o 1 a sair
		Queue<Navio> f2 = new LinkedList<Navio>();
		
		f1.add(n1);
		f1.add(n2);
		f1.add(n3); // fila adicona no final
		
		//f1.poll(); // assim tiro o 1� da fila sai fora n1
		//f1.poll();// assim tiro o 1� da fila sai fora n2
		while (!f1.isEmpty()) {
			Navio temp = f1.poll();  //poll -> tira da fila
			System.out.println();
			System.out.println(temp.getMatricula());
			System.out.println(temp.getNome());
			f2.add(temp); //aqui tira de uma fila e coloco em outra fila
		}
		
		
		

	}

}
